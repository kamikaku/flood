﻿#ifndef ADAPTERWIDGET_H
#define ADAPTERWIDGET_H

#include <QWidget>
#include <QtOpenGL/QGLWidget>
#include <QApplication>

#include <osgViewer/Viewer>
#include <osgViewer/CompositeViewer>
#include <osgViewer/ViewerEventHandlers>
#include <osgGA/TrackballManipulator>
#include <osgDB/ReadFile>
#include <QtCore/QString>
#include <QtCore/QTimer>
#include <QtGui/QKeyEvent>
#include <QtOpenGL/QGLWidget>
#include <QMainWindow>
#include <QMdiSubWindow>
#include <QMdiArea>
#include <iostream>

using Qt::WindowFlags;

class AdapterWidget : public QGLWidget
{
    Q_OBJECT
    
public:
    AdapterWidget(QWidget *parent = 0);
//    AdapterWidget(QWidget *parent = 0,const char*name=0,const QGLWidget*shareWidget=0,Qt::WindowFlags f=0 );
    ~AdapterWidget();

    osgViewer::GraphicsWindow* getGraphicsWindow()
    {
        return _gw.get();
    }
    const osgViewer::GraphicsWindow* getGraphicsWindow() const
    {
        return _gw.get();
    }

protected:
    void init();
    void initializeGL();
    virtual void resizeGL(int width,int height);
    virtual void mousePressEvent(QMouseEvent* event);
    virtual void mouseReleaseEvent(QMouseEvent* event);//
    virtual void mouseMoveEvent(QMouseEvent* event);

    virtual void keyPressEvent(QKeyEvent* event);
    virtual void keyReleaseEvent(QKeyEvent* event);


    osg::ref_ptr<osgViewer::GraphicsWindowEmbedded> _gw;
};

#endif // ADAPTERWIDGET_H
