﻿#ifndef SHPCLASS_H
#define SHPCLASS_H
#include <iostream>
#include <osg/Node>

using namespace std;



class Point3D
{
public:
    double X; //X
    double Y; //Y
    double Z; //Z
    double height; //属性值
    std::string Name;
};


class Line3D{
public:
    vector<Point3D> line;
    std::string Name;
    osg::Vec4 color;

};

class Polygon3D{
public:
    vector<Point3D> ploygon;
    std::string Name;
    osg::Vec4 color;

};

#endif // SHPCLASS_H
