﻿#include "searchnode.h"

SearchNode::SearchNode()
{

}

int SearchNode::return_Nodeindex(osg::Group *group, std::string name)
{
    int index_num=-1;
    for(int i=0;i<group->getNumChildren();i++)
    {
        osg::Node* node = group->getChild(i);
        if(node->getName()==name){
            index_num=i;
        }
    }
    return index_num;

}
