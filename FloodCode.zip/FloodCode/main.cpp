﻿#include "mainwindow.h"
#include <QApplication>
#include "readshpdialog.h"

std::list<FileManage> fl;
extern std::list<FileManage> BindingFiles = fl; //对绑定文件的信息集进行初始化
extern QString NOW_NODENAME = "null"; //全局变量记录当前所在的节点名称
extern std::vector<float> coord(3);

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowTitle("Konwledge Visualization of Flood System");
    w.resize(1400, 900);
//    w.setWindowFlags(Qt::FramelessWindowHint | Qt::WindowMinimizeButtonHint);
    w.show();

    return a.exec();
}
