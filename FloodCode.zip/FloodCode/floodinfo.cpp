﻿#include "floodinfo.h"
#include <QTextCodec>
#include <QString>
#include <QObject>
#include "renderclass.h"

floodInfo::floodInfo()
{

}


void floodInfo::createText(osgText::Text &textObject, float size, const osg::Vec3 &pos, const osg::Vec4 &color)
{
    textObject.setFont("fonts/msyh.ttc");//设置字体格式
    textObject.setCharacterSize(size);//字体大小
//    textObject.setColor( osg::Vec4( 0, 0, 0, 1));  //字体颜色
    textObject.setColor(color);  //字体颜色
    textObject.setPosition(pos);
    textObject.setAlignment(osgText::Text::LEFT_CENTER);//文字显示方向
    textObject.setAutoRotateToScreen(true);//跟随视角不断变化，但离物体越远，文字越小，和现实当中像类似
}

//使整个场景下雨
osg::ref_ptr<osg::Node> floodInfo::rainEffect()
{
    //调用粒子系统，使整个场景下雨
//    osg::ref_ptr<osgParticle::PrecipitationEffect>pe=new osgParticle::PrecipitationEffect();
//    pe->rain(1.0f);
//    pe->setParticleSize(0.08);

    //指定场景位置下雨
    osg::Matrixd matrixEffect;
    matrixEffect.makeTranslate(osg::Vec3(971085.01f, 3.85601e+6f, 2500.00f));
    // 设置粒子位置
    osg::ref_ptr<osg::MatrixTransform> trans = new osg::MatrixTransform;
    // 对粒子范围进行了放大
    trans->setMatrix(matrixEffect );
    // 创建雨粒子
    osg::ref_ptr<osgParticle::PrecipitationEffect> pe = new osgParticle::PrecipitationEffect;
    pe->rain(2.0f);
//    pe->setUseFarLineSegments(true);
    // iLevel参数是一个int值，表示雨的级别，一般1-10就够用了
//    pe->setParticleSize(0.015);
    pe->setParticleSize(0.032);
    // 设置颜色
    pe->setParticleColor(osg::Vec4(1, 1, 1, 1));

    return pe;
}


osg::ref_ptr<osg::Geode> floodInfo::showText(std::string strt,osg::Vec3 pos,float size){

//    str ="Heavy rainfall in Shaanxi since August 30";
    osg::ref_ptr<osg::Geode> geode = new osg::Geode;  //节点
    //**文字
    osg::ref_ptr<osgText::Text>text=new osgText::Text;
    //设置字体

//    std::wstring str=string_To_wstring(strt);
    const char* tvolc = strt.c_str();
    QTextCodec* code1 = QTextCodec::codecForName("UTF-8");
    QString qstr1 = QObject::tr(tvolc);
    std::string str1 = code1->fromUnicode(qstr1).data();
    text->setText(str1, osgText::String::ENCODING_UTF8);

//    text->setText(str.c_str());
    createText(*text,size,pos,osg::Vec4(1.0f, 1.0f, 1.0f, 1));
    osg::ref_ptr<osgText::Font> font = osgText::readFontFile("fonts/msyh.ttc");
    text->setFont(font);

    text->setBackdropType(osgText::Text::OUTLINE);//对文字进行描边
//    text->setBackdropColor(osg::Vec4(0.3,0.6,0.7,1));//描边颜色
    text->setBackdropColor(osg::Vec4(0.0,0.0,0.0,1));//描边颜色
//    text->setLayout(osgText::Text::VERTICAL);   //设置格式为VERTICAL，垂直
    geode->addDrawable(text.get());


    return geode;

}

//分割字符串

std::vector<std::string>  split(const std::string& str,const std::string& delim) { //将分割后的子字符串存储在vector中
    std::vector<std::string> res;
    if("" == str) return  res;

    std::string strs = str + delim; //*****扩展字符串以方便检索最后一个分隔出的字符串
    size_t pos;
    size_t size = strs.size();

    for (int i = 0; i < size; ++i) {
        pos = strs.find(delim, i); //pos为分隔符第一次出现的位置，从i到pos之前的字符串是分隔出来的字符串
        if( pos < size) { //如果查找到，如果没有查找到分隔符，pos为string::npos
            std::string s = strs.substr(i, pos - i);//*****从i开始长度为pos-i的子字符串
            res.push_back(s);//两个连续空格之间切割出的字符串为空字符串，这里没有判断s是否为空，所以最后的结果中有空字符的输出，
            i = pos + delim.size() - 1;
        }

    }
    return res;
}



//创建HUD显示受损情况
osg::ref_ptr<osg::Camera> floodInfo::CreateInfoHUD(std::string strt){

int txType =1;
float strLen = strt.length();
float whg = 1.0f;
std::vector<std::string> res = split(strt,"\n");
if(res.size()>1){
    strLen = res[0].length();
    whg = res.size();
}

    //图例面板背景颜色
      osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
      osg::ref_ptr<osg::Vec4Array>colorArray=new osg::Vec4Array;
      geometry=osg::createTexturedQuadGeometry(osg::Vec3(130.0f,20.0f-(12.0f*(whg-1)),0.0f),
                                               osg::Vec3(strLen*10.0f,0.0f,0.0f),osg::Vec3(0.0f,20.0*whg,0.0f));

      colorArray->push_back(osg::Vec4(1.0,1.0,1.0,0.7f));
      geometry->setColorArray(colorArray.get());
      geometry->setColorBinding(osg::Geometry::BIND_OVERALL);

      //添加背景
      osg::Geode*geode=new osg::Geode();
      geode->addChild(geometry);

      //读取文字
          osgText::Text *text2=new osgText::Text;
          //设置字体
          text2->setFont("fonts/times.ttf");//("fonts/simhei.ttf");
          //设置文字显示的位置
          text2->setPosition(osg::Vec3(135.0f,25.0,0.0f));
//          text2->setColor(osg::Vec4( 0.2, 0.1, 0.9, 1));
          text2->setColor(osg::Vec4(255/255.0f,140/255.0f,0/255.0f,1));

//          std::wstring str=string_To_wstring(strt);
          const char* strc = strt.c_str();
          QTextCodec* code2 = QTextCodec::codecForName("UTF-8");
          QString qstr2 = QObject::tr(strc);
          std::string str2 = code2->fromUnicode(qstr2).data();
          text2->setText(str2, osgText::String::ENCODING_UTF8);

//          text2->setText(str.c_str());
          text2->setCharacterSize(18);  //设置字体大小
          geode->addChild(text2); //添加文字



      //设置状态
      osg::StateSet* stateset = geode->getOrCreateStateSet();
      stateset->setMode(GL_LIGHTING,osg::StateAttribute::OFF);//关闭灯光
      stateset->setMode(GL_DEPTH_TEST,osg::StateAttribute::OFF);//关闭深度测试
      //打开GL_BLEND混合模式（以保证Alpha纹理正确）
      stateset->setMode(GL_BLEND,osg::StateAttribute::ON);

      //相机
      osg::Camera* camera = new osg::Camera;
      //设置透视矩阵
      camera->setProjectionMatrix(osg::Matrix::ortho2D(0,800,0,600));//正交投影
      //设置绝对参考坐标系，确保视图矩阵不会被上级节点的变换矩阵影响
      camera->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
      //视图矩阵为默认的
      camera->setViewMatrix(osg::Matrix::identity());
      //设置背景为透明，否则的话可以设置ClearColor
      camera->setClearMask(GL_DEPTH_BUFFER_BIT);
      camera->setAllowEventFocus( false);//不响应事件，始终得不到焦点
      //设置渲染顺序，必须在最后渲染
      camera->setRenderOrder(osg::Camera::POST_RENDER);
      camera->addChild(geode);//将要显示的Geode节点加入到相机
      return camera;
}

//中文string转wstring
std::wstring floodInfo::string_To_wstring(std::string pStr)
{
    //不能识别转义字符(但是将xml中的换行符修改为&#x000A;即可识别换行符)
    unsigned len = pStr.size() * 2;// 预留字节数
    setlocale(LC_CTYPE, "");     //必须调用此函数
    wchar_t *p = new wchar_t[len];// 申请一段内存存放转换后的字符串
    mbstowcs(p,pStr.c_str(),len);// 转换
    std::wstring str1(p);
    delete[] p;// 释放申请的内存
    return str1;
}




osg::ref_ptr<osg::Node> floodInfo::drawImage(std::string path){

    osg::ref_ptr<osg::Image> image = osgDB::readImageFile(path);
         //创建四边形
         osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry();
         osg::ref_ptr<osg::Geode> geode = new osg::Geode();

         //设置顶点
         osg::ref_ptr<osg::Vec3Array> v = new osg::Vec3Array();
//            v->push_back(osg::Vec3(0.0f,-0.5f,-0.5f));
//            v->push_back(osg::Vec3(0.0f,0.5f,-0.5f));
//            v->push_back(osg::Vec3(0.0f,0.5f,0.5f));
//            v->push_back(osg::Vec3(0.0f,-0.5f,0.5f));
         v->push_back(osg::Vec3(0.0f,-0.25f,-0.5f));
         v->push_back(osg::Vec3(0.0f,0.25f,-0.5f));
         v->push_back(osg::Vec3(0.0f,0.25f,0.5f));
         v->push_back(osg::Vec3(0.0f,-0.25f,0.5f));

         geometry->setVertexArray(v.get());

         //设置法线
         osg::ref_ptr<osg::Vec3Array> normal = new osg::Vec3Array();
         normal->push_back(osg::Vec3(1.0f,0.0f,0.0f)^osg::Vec3(0.0f,0.0f,1.0f));
//            normal->push_back(osg::Vec3(0.0f,1.0f,0.0f)^osg::Vec3(0.0f,0.0f,1.0f));

         geometry->setNormalArray(normal.get());
         geometry->setNormalBinding(osg::Geometry::BIND_OVERALL);

         //设置纹理坐标
         osg::ref_ptr<osg::Vec2Array> vt = new osg::Vec2Array();
         vt->push_back(osg::Vec2(0.0f,0.0f));
         vt->push_back(osg::Vec2(1.0f,0.0f));
         vt->push_back(osg::Vec2(1.0f,1.0f));
         vt->push_back(osg::Vec2(0.0f,1.0f));


         geometry->setTexCoordArray(0,vt.get());
         geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS,0,4));

         if(image.get()){
             //属性对象
             osg::ref_ptr<osg::StateSet> stateset = new osg::StateSet();

             //创建一个Texture2D属性对象
             osg::ref_ptr<osg::Texture2D> texture = new osg::Texture2D();

             //关联image
             texture->setImage(image.get());


             //关联Texture2D纹理对象，第三个参数默认为ON
             stateset->setTextureAttributeAndModes(0,texture,osg::StateAttribute::ON);

             //启用混合
             stateset->setMode(GL_BLEND,osg::StateAttribute::ON);
             //关闭光照
             stateset->setMode(GL_LIGHTING,osg::StateAttribute::OFF);


             geometry->setStateSet(stateset.get());
         }
         osg::Material *material = new osg::Material;
         material->setDiffuse(osg::Material::FRONT, osg::Vec4(1.0, 1.0, 1.0, 1.0));
         material->setAmbient(osg::Material::FRONT, osg::Vec4(1.0, 1.0, 1.0, 1.0));
         material->setShininess(osg::Material::FRONT, 90.0);
         geode->getOrCreateStateSet()->setAttribute(material);

         geode->addDrawable(geometry.get());

         RenderClass *rc = new RenderClass;
         rc->setNodeRender(*geode,2);

         delete rc;
        return geode.get();
}

osg::ref_ptr<osg::Node> floodInfo::turn_Billboard(osg::Node* node,osg::Vec3 position,osg::Vec3 scale){

    osg::ref_ptr<osg::Group> g= new osg::Group();
    osg::ref_ptr<osg::Billboard> billboard = new osg::Billboard;
    billboard->setMode(osg::Billboard::POINT_ROT_EYE);
    billboard->addDrawable(node->asDrawable());

    g->addChild(billboard.get());
    osg::ref_ptr<osg::PositionAttitudeTransform> trans =new osg::PositionAttitudeTransform();
    trans->setPosition(position);
    trans->setScale(scale);
    trans->addChild(g.get());
//    osg::ref_ptr<osg::AutoTransform> at = new osg::AutoTransform();
//    at->setPosition(position);
//    at->setAutoRotateMode(osg::AutoTransform::ROTATE_TO_SCREEN);
//    at->addChild(g.get());
    return trans.get();

}
