﻿#include "landslideform.h"
#include "ui_landslideform.h"

LandslideForm::LandslideForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LandslideForm)
{
    ui->setupUi(this);
    lineEdit=ui->lineEdit;
    lineEdit2=ui->lineEdit_2;
    lineEdit3=ui->lineEdit_3;
    lineEdit4=ui->lineEdit_4;
    lineEdit5=ui->lineEdit_5;
    lineEdit6=ui->lineEdit_6;
    lineEdit7=ui->lineEdit_7;
    lineEdit8=ui->lineEdit_8;

    ui->comboBox->addItem(".ive");
    ui->comboBox->addItem(".3ds");
    ui->comboBox->addItem(".tif");
}

LandslideForm::~LandslideForm()
{
    delete ui;
}

//开始计算按钮
void LandslideForm::on_pushButton_clicked()
{
    if(ui->lineEdit->text()==""||ui->lineEdit_2->text()==""||ui->lineEdit_3->text()==""||ui->lineEdit_4->text()==""||ui->lineEdit_5->text()==""||ui->lineEdit_6->text()==""||ui->lineEdit_8->text()=="")
    {
        QMessageBox::information(NULL, "Warning", "未填写文件", QMessageBox::Yes );
        return;
    }
    QString format = ui->comboBox->currentText();
    string lformat = format.toStdString();
    urlStr.push_back(lformat);
    this->close();
    emit sendURL(urlStr);  //传送需要计算的信息,必须要先传数据才能计算
    emit sendLandSlide(true);

}

//===字符串分割函数
vector<string> LandslideForm::split(string *str, string *pattern)
{
    string::size_type pos;
    std::vector<std::string> result;
    *str += *pattern;//扩展字符串以方便操作
    int size = str->size();
    for (int i = 0; i<size; i++)
    {
        pos = str->find(*pattern, i);
        if (pos<size)
        {
            string s = str->substr(i, pos - i);
            result.push_back(s);
            i = pos + pattern->size() - 1;
        }
    }
    return result;
}

//****添加滑坡标注
osg::ref_ptr<osg::Geode> LandslideForm::addLabel()
{
    osg::ref_ptr<osg::Geode>geode=new osg::Geode;
    osg::ref_ptr<osgText::Font> font = osgText::readFontFile("fonts/simhei.ttf");  //文本使用字体
    //test文本节点,标注滑坡体长度信息
    osg::ref_ptr<osgText::Text>text1 = new osgText::Text;
    text1->setFont(font);
    text1->setPosition(osg::Vec3f(472256.3835f, 3438837.686f, 3200.00f)); //文本位置，缺点：坐标是手动输入的
    text1->setColor(osg::Vec4(1, 0, 0, 1));  //设置颜色
    text1->setCharacterSize(50);  //设置文字尺寸大小
//    text1->setAlignment(osgText::Text::CENTER_BOTTOM);//文字显示方向
    text1->setAxisAlignment(osgText::Text::SCREEN); //一直朝向镜头，所以，文字不会随着物体的旋转而旋转，永远都是水平的
    text1->setAutoRotateToScreen(true);//跟随视角不断变化，但离物体越远，文字越小，和现实当中像类似
    text1->setText(L"滑坡体长约300米");//设置显示的文字,加L是为了解决乱码问题

    //转换成宽字节
//    char huapoLong[] = "滑坡体长约300米";
//    char *data1 = huapoLong;
//    DWORD len1 = MultiByteToWideChar(CP_ACP, 0, data1, -1, NULL, 0);//得到data的字节数
//    TCHAR *des1 = new TCHAR[len1];
//    MultiByteToWideChar(CP_ACP, 0, data1, -1, des1, len1);
//    text1->setText(des1);//设置显示的文字

    geode->addDrawable(text1.get());

    //画线, 用来标注滑坡体长
    osg::ref_ptr<osg::Vec3Array> points_long = new osg::Vec3Array();  //顶点数组
    osg::ref_ptr<osg::Vec4Array>colors_long = new osg::Vec4Array;  //颜色RGB值数组
    osg::ref_ptr<osg::Geometry> geometry_long = new osg::Geometry();
    //添加顶点坐标
    /*points_long->push_back(osg::Vec3f(10988455.978f, 3621723.137f, 3000.0f));
    points_long->push_back(osg::Vec3f(10988681.774f, 3621156.375f, 3000.00f));*/
    points_long->push_back(osg::Vec3f(472187.034f, 3439161.855f, 3200.0f));
    points_long->push_back(osg::Vec3f(472325.733f, 3438513.517f, 3200.00f));
    //添加顶点颜色
    colors_long->push_back(osg::Vec4f(1.0f, 0.0f, 0.0f, 1.0f));
    colors_long->push_back(osg::Vec4f(1.0f, 0.0f, 0.0f, 1.0f));
    //设置图元绘制方式
    geometry_long->setVertexArray(points_long.get());
    geometry_long->setColorArray(colors_long);//设置颜色数组
    geometry_long->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, 2));
    geometry_long->setColorBinding(osg::Geometry::BIND_PER_VERTEX);
    geode->addDrawable(geometry_long.get());

    //test节点，标注滑坡体宽度信息
    osg::ref_ptr<osgText::Text>text2 = new osgText::Text;
    text2->setFont(font);
    text2->setPosition(osg::Vec3f(472635.387f, 3438945.743f, 3200.00f)); //文本位置
    text2->setColor(osg::Vec4(1, 0, 0, 1));
    text2->setAxisAlignment(osgText::Text::SCREEN); //一直朝向镜头，所以，文字不会随着物体的旋转而旋转，永远都是水平的
    text2->setAutoRotateToScreen(true);//跟随视角不断变化，但离物体越远，文字越小，和现实当中像类似
    text2->setCharacterSize(50);
    text2->setText(L"宽约150米");//设置显示的文字,加L是为了解决乱码问题

    //转换成宽字节
//    char huapoWidth[] = "宽约150米";
//    char *data2 = huapoWidth;
//    DWORD len2 = MultiByteToWideChar(CP_ACP, 0, data2, -1, NULL, 0);//得到data的字节数
//    TCHAR *des2 = new TCHAR[len2];
//    MultiByteToWideChar(CP_ACP, 0, data2, -1, des2, len2);
//    text2->setText(des2);//设置显示的文字

    geode->addDrawable(text2.get());
    //画线，用来标注滑坡体宽
    osg::ref_ptr<osg::Vec3Array> points_width = new osg::Vec3Array();  //顶点数组
    osg::ref_ptr<osg::Vec4Array>colors_width = new osg::Vec4Array;  //颜色RGB值数组
    osg::ref_ptr<osg::Geometry> geometry_width = new osg::Geometry();
    //points_width->push_back(osg::Vec3f(10988639.171f, 3621535.683f, 3000.0f));//添加顶点坐标
    //points_width->push_back(osg::Vec3f(10989325.082f, 3621625.15f, 3000.00f));
    points_width->push_back(osg::Vec3f(472370.891f, 3438916.713f, 3200.0f));//添加顶点坐标
    points_width->push_back(osg::Vec3f(472899.883f, 3438974.773f, 3200.00f));

    colors_width->push_back(osg::Vec4f(1.0f, 0.0f, 0.0f, 1.0f)); //添加顶点颜色
    colors_width->push_back(osg::Vec4f(1.0f, 0.0f, 0.0f, 1.0f));

    geometry_width->setVertexArray(points_width.get());
    geometry_width->setColorArray(colors_width);//设置颜色数组
    geometry_width->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, 2));
    geometry_width->setColorBinding(osg::Geometry::BIND_PER_VERTEX);
    geode->addDrawable(geometry_width.get());

    return geode;
}

//添加符号化信息
osg::ref_ptr<osg::Geode> LandslideForm::addInformation()
{
    osg::ref_ptr<osg::Geode>geode = new osg::Geode;
    //添加符号化信息
    //创建精细度对象，精细度越高，细分就越多
    osg::ref_ptr<osg::TessellationHints> hints = new osg::TessellationHints;
    hints->setDetailRatio(0.5f);
    osg::ref_ptr < osg::ShapeDrawable >shape1 = new osg::ShapeDrawable(new osg::Box(osg::Vec3(472310.3835f, 3438800.686f, 3100.00f),
        30.0f, 30.0f, 150.0f), hints);  //设置长方体长、宽、高
    shape1->setColor(osg::Vec4(0.0f, 0.8f, 0.0f, 1.0f));  //设置颜色
    osg::ref_ptr < osg::ShapeDrawable >shape2 = new osg::ShapeDrawable(new osg::Box(osg::Vec3(472350.3835f, 3438900.686f, 3100.00f),
        30.0f, 30.0f, 135.0f), hints);  //设置长方体长、宽、高
    shape2->setColor(osg::Vec4(0.5f, 0.0f, 0.5f, 1.0f));  //设置颜色
    osg::ref_ptr < osg::ShapeDrawable >shape3 = new osg::ShapeDrawable(new osg::Box(osg::Vec3(472200.3835f, 3438850.686f, 3100.00f),
        20.0f, 20.0f, 120.0f), hints);  //设置长方体长、宽、高
    shape3->setColor(osg::Vec4(0.6f, 0.6f, 0.6f, 1.0f));  //设置颜色
    osg::ref_ptr < osg::ShapeDrawable >shape4 = new osg::ShapeDrawable(new osg::Box(osg::Vec3(473000.3835f, 3439000.686f, 3100.00f),
        20.0f, 30.0f, 120.0f), hints);  //设置长方体长、宽、高
    shape4->setColor(osg::Vec4(0.8f, 0.8f, 0.8f, 1.0f));  //设置颜色
    osg::ref_ptr < osg::ShapeDrawable >shape5 = new osg::ShapeDrawable(new osg::Box(osg::Vec3(472200.3835f, 3439100.686f, 3100.00f),
        30.0f, 20.0f, 150.0f), hints);  //设置长方体长、宽、高
    shape5->setColor(osg::Vec4(0.5f, 0.5f, 0.5f, 1.0f));  //设置颜色
    osg::ref_ptr < osg::ShapeDrawable >shape6 = new osg::ShapeDrawable(new osg::Box(osg::Vec3(472150.3835f, 3439000.686f, 3100.00f),
        30.0f, 30.0f, 125.0f), hints);  //设置长方体长、宽、高
    shape6->setColor(osg::Vec4(0.0f, 0.8f, 1.0f, 1.0f));  //设置颜色
    osg::ref_ptr < osg::ShapeDrawable >shape7 = new osg::ShapeDrawable(new osg::Box(osg::Vec3(472320.3835f, 3438860.686f, 3100.00f),
        30.0f, 30.0f, 145.0f), hints);  //设置长方体长、宽、高
    shape7->setColor(osg::Vec4(1.0f, 0.8f, 0.0f, 1.0f));  //设置颜色
    osg::ref_ptr < osg::ShapeDrawable >shape8 = new osg::ShapeDrawable(new osg::Box(osg::Vec3(472310.3835f, 3438860.686f, 3100.00f),
        50.0f, 30.0f, 120.0f), hints);  //设置长方体长、宽、高
    shape8->setColor(osg::Vec4(0.0f, 0.2f, 0.0f, 1.0f));  //设置颜色

    geode->addChild(shape1);
    geode->addChild(shape2);
    geode->addChild(shape3);
    geode->addChild(shape4);
    geode->addChild(shape5);
    geode->addChild(shape6);
    geode->addChild(shape7);
    geode->addChild(shape8);

    return geode;
}

//***改变shp的大小和颜色，步骤1
osg::Image *LandslideForm::createImage(int width, int height, osg::Vec3 color)
{
    osg::ref_ptr<osg::Image> image = new osg::Image;
    image->allocateImage( width, height, 1, GL_RGB, GL_UNSIGNED_BYTE );
    unsigned char* data = image->data();
    for ( int y=0; y<height; ++y )
    {
        for ( int x=0; x<width; ++x )
        {
            *(data++) = color.x();
            *(data++) = color.y();
            *(data++) = color.z();
        }
    }
    return image.release();
}

//***改变shp的大小和颜色，步骤2
void LandslideForm::ChangeSHP(osg::ref_ptr<osg::Node> node, osg::Vec4 color, float size, bool IsPoint)
{
    osg::ref_ptr<osg::Image> image= createImage(256,256,osg::Vec3(color.x()*255,color.y()*255,color.z()*255));
    if (image.get())
    {
        osg::ref_ptr<osg::Texture2D> texture=new osg::Texture2D();
        texture->setImage(image.get());

        //设置自动生成纹理坐标
        osg::ref_ptr<osg::TexGen> texgen=new osg::TexGen();
        texgen->setMode(osg::TexGen::NORMAL_MAP);

        //设置纹理环境，模式为BLEND
        osg::ref_ptr<osg::TexEnv> texenv=new osg::TexEnv;
        texenv->setMode(osg::TexEnv::ADD);
        texenv->setColor(color);

        //启动单元一自动生成纹理坐标，并使用纹理
        osg::ref_ptr<osg::StateSet> state=new osg::StateSet;
        state->setTextureAttributeAndModes(1,texture.get(),osg::StateAttribute::ON);
        state->setTextureAttributeAndModes(1,texgen.get(),osg::StateAttribute::ON);


         if(IsPoint)
             {
                 osg::ref_ptr<osg::Point> pointsize = new osg::Point;
                 pointsize->setSize(size);
                 state->setAttributeAndModes(pointsize,osg::StateAttribute::ON);
                 state->setMode(GL_POINT_SPRITE_ARB,osg::StateAttribute::ON); //点精灵效果
             }
             else
             {
                 osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth;
                 lw->setWidth(size);
                 state->setAttributeAndModes(lw,osg::StateAttribute::ON);
             }
         node->setStateSet(state.get());
    }
}

//写出滑坡时刻文件（彭琪代码）
void LandslideForm::writeRaster(char *savePath, GDALDataset *dataSet, float *bufferData)
{
    const char *pszFormat = "GTiff";
    int bandNum = dataSet->GetRasterCount();
    int rasterXSize = dataSet->GetRasterXSize(), rasterYSize = dataSet->GetRasterYSize();
    double GeoTransform[6];                     	//获取坐标信息
    dataSet->GetGeoTransform(GeoTransform);
    const char* projectionRef = dataSet->GetProjectionRef();	//获取投影信息
    GDALDriver *poDriver = GetGDALDriverManager()->GetDriverByName(pszFormat);  //获取指定驱动类型
    GDALDataset* poDatasetCreate = poDriver->Create(                              //创建待写入文件的数据集
        savePath,                                                      //文件路径
        rasterXSize, rasterYSize,                                                     //图像文件的大小
        bandNum,                                                             //图像的波段数
        GDT_Float32                                                    //图像数据类型
        , NULL);                                                        //图像储存方式
    poDatasetCreate->SetGeoTransform(GeoTransform);
    poDatasetCreate->SetProjection(projectionRef);
    int mapBand[3] = { 1, 2, 3 };
    if (dataSet->GetRasterCount() > 1)
        poDatasetCreate->RasterIO(GF_Write, 0, 0, rasterXSize, rasterYSize, bufferData,
            rasterXSize, rasterYSize, GDT_Float32, 3, mapBand, 0, 0, 0);
    else
        poDatasetCreate->RasterIO(GF_Write, 0, 0, rasterXSize, rasterYSize, bufferData,
            rasterXSize, rasterYSize, GDT_Float32, 1, NULL, 0, 0, 0);
    GDALClose(poDatasetCreate);
}

//******在附近地方找表面纹理，根据地理作弊获取指定位置的像元值
//GeoX, GeoY[in]:地理位置;  nBandCOunt[OUT]:存放波段数; 	xSize, ySize[IN]:要获取像元值的范围，宽和高默认为1
bool LandslideForm::GetPixValByGeoPos(GDALDataset *pDataset, const double GeoX, const double GeoY,
                                      std::vector<float> &pixelValues, int xSize, int ySize)
{
    try{
        pixelValues.clear(); //先将存放颜色的容器pixelValues清空
        double GT[6];
        //得到仿射变换模型
        pDataset->GetGeoTransform(GT);
        //得到影像宽和高
        int rasterXSize = pDataset->GetRasterXSize();
        int rasterYSize = pDataset->GetRasterYSize();
        //得到影像波段数
        int nBandCount = pDataset->GetRasterCount();
        int iCol, iRow;
        //地理位置转换为影像行列位置
        if (!Projection2ImageRowCol(GT, GeoY, GeoX, iCol, iRow))
            throw 0;
        //地理位置转换结果是否超出影像范围
//        cout<<"GeoY:"<<GeoY<<", GeoX:"<<GeoX<<", iCol:"<<iCol<<", iRow:"<<iRow<<endl;
        //if (iCol < 0 || iCol >= rasterXSize || iRow < 0 || iRow >= rasterYSize)
        if (iCol < 0 || iCol > rasterXSize || iRow < 0 || iRow > rasterYSize)
        {
            return false;
        }
        else
        {  //没有进入
            int *pBuf;
            pBuf = new int[nBandCount*xSize*ySize + 1];	//不知道为什么不+1的情况下delete改指针会报错 所以我加了1
            int *panBandMap = new int[nBandCount];
            for (int i = 0; i < nBandCount; ++i)
                panBandMap[i] = i + 1;
            //获取指定行列位置每个波段的像元值，存入pBuf
            pDataset->RasterIO(GF_Read, iCol, iRow, xSize, ySize, pBuf, xSize,
                ySize, GDT_CInt32, nBandCount, panBandMap, 4, 0, 0);

            delete[] panBandMap;
            panBandMap = NULL;

            //hpc 像元值转成对应的rgb分量值
            for (int i = 0; i < nBandCount; i++)
            {
                pixelValues.push_back(*(pBuf + i));
            }

            if (pBuf)
                delete[] pBuf;
            pBuf = NULL;
        }
    }catch(exception e)
    {
        return false;
    }
//    cout<<"out:"<<pixelValues[0]<<",  "<<pixelValues[1]<<",  "<<pixelValues[2]<<",  "<<pixelValues.size()<<endl;
    return true;
}

//*******由地理坐标得到图像行列号
bool LandslideForm::Projection2ImageRowCol(double *adfGeoTransform, double dProjX, double dProjY, int &iCol, int &iRow)
{
    try
    {
        double dTemp = adfGeoTransform[1] * adfGeoTransform[5] - adfGeoTransform[2] * adfGeoTransform[4];
        double dCol = 0.0, dRow = 0.0;
        dCol = (adfGeoTransform[5] * (dProjX - adfGeoTransform[0]) -
            adfGeoTransform[2] * (dProjY - adfGeoTransform[3])) / dTemp + 0.5;
        dRow = (adfGeoTransform[1] * (dProjY - adfGeoTransform[3]) -
            adfGeoTransform[4] * (dProjX - adfGeoTransform[0])) / dTemp + 0.5;

        iCol = int(dCol);
        iRow = int(dRow);
        return true;
    }
    catch (...)
    {
        return false;
    }
}

//开始演进
void LandslideForm::on_pushButton_2_clicked()
{
    this->close();
    emit sendStart(3);
}


//加载滑坡体信息--加载堆积体
void LandslideForm::on_pushButton_3_clicked()
{
    //获取文件夹路径
     QString fileName = QFileDialog::getOpenFileName(this);
     if(fileName.isEmpty()){ //选择文件是否存在
         QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
     }else{
         if(lineEdit->text().isEmpty()){ //是否已经有选择过路径了
             lineEdit->setText(fileName);
             urlStr.push_back(fileName.toStdString());
         }else{ //若之前选择过，现只需修改即可
             urlStr[0]=fileName.toStdString();
             lineEdit->setText(fileName);
         }
     }
}

//加载滑坡体信息--加载滑坡道
void LandslideForm::on_pushButton_4_clicked()
{
    if(lineEdit->text().isEmpty()){ //是否已经有选择过路径了
        QMessageBox::information(NULL, "Warning", "请先选择堆积体", QMessageBox::Yes );
    }else{
        //获取文件夹路径
         QString fileName = QFileDialog::getOpenFileName(this);
         if(fileName.isEmpty()){ //选择文件是否存在
             QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
         }else{
             if(lineEdit2->text().isEmpty()){ //是否已经有选择过路径了
                 lineEdit2->setText(fileName);
                 urlStr.push_back(fileName.toStdString());
             }else{ //若之前选择过，现只需修改即可
                 urlStr[1]=fileName.toStdString();
                 lineEdit2->setText(fileName);
             }
         }
    }

}

//加载滑坡体信息--加载滑坡体
void LandslideForm::on_pushButton_5_clicked()
{
    if(lineEdit2->text().isEmpty()){ //是否已经有选择过路径了
        QMessageBox::information(NULL, "Warning", "请先选择滑坡道", QMessageBox::Yes );
    }else{
        //获取文件夹路径
         QString fileName = QFileDialog::getOpenFileName(this);
         if(fileName.isEmpty()){ //选择文件是否存在
             QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
         }else{
             if(lineEdit3->text().isEmpty()){ //是否已经有选择过路径了
                 lineEdit3->setText(fileName);
                 urlStr.push_back(fileName.toStdString());
             }else{ //若之前选择过，现只需修改即可
                 urlStr[2]=fileName.toStdString();
                 lineEdit3->setText(fileName);
             }
         }
    }
}

//加载滑坡体信息--加载灾后影像用作纹理
void LandslideForm::on_pushButton_6_clicked()
{
    if(lineEdit3->text().isEmpty()){ //是否已经有选择过路径了
        QMessageBox::information(NULL, "Warning", "请先选择滑坡体", QMessageBox::Yes );
    }else{
        //获取文件夹路径
         QString fileName = QFileDialog::getOpenFileName(this);
         if(fileName.isEmpty()){ //选择文件是否存在
             QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
         }else{
             if(lineEdit4->text().isEmpty()){ //是否已经有选择过路径了
                 lineEdit4->setText(fileName);
                 urlStr.push_back(fileName.toStdString());
             }else{ //若之前选择过，现只需修改即可
                 urlStr[3]=fileName.toStdString();
                 lineEdit4->setText(fileName);
             }
         }
    }
}

//加载滑坡体信息--加载中心线
void LandslideForm::on_pushButton_7_clicked()
{
    if(lineEdit4->text().isEmpty()){ //是否已经有选择过路径了
        QMessageBox::information(NULL, "Warning", "请先选择灾后影像", QMessageBox::Yes );
    }else{
        //获取文件夹路径
         QString fileName = QFileDialog::getOpenFileName(this);
         if(fileName.isEmpty()){ //选择文件是否存在
             QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
         }else{
             if(lineEdit5->text().isEmpty()){ //是否已经有选择过路径了
                 lineEdit5->setText(fileName);
                 urlStr.push_back(fileName.toStdString());
             }else{ //若之前选择过，现只需修改即可
                 urlStr[4]=fileName.toStdString();
                 lineEdit5->setText(fileName);
             }
         }
    }
}

//加载滑坡体信息--加载dem
void LandslideForm::on_pushButton_8_clicked()
{
    if(lineEdit5->text().isEmpty()){ //是否已经有选择过路径了
        QMessageBox::information(NULL, "Warning", "请先选择中心线", QMessageBox::Yes );
    }else{
        //获取文件夹路径
         QString fileName = QFileDialog::getOpenFileName(this);
         if(fileName.isEmpty()){ //选择文件是否存在
             QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
         }else{
             if(lineEdit6->text().isEmpty()){ //是否已经有选择过路径了
                 lineEdit6->setText(fileName);
                 urlStr.push_back(fileName.toStdString());
             }else{ //若之前选择过，现只需修改即可
                 urlStr[5]=fileName.toStdString();
                 lineEdit6->setText(fileName);
             }
         }
    }

//    if(urlStr.size()!=6)  //判断两个路径是否存在
//    {
//        QMessageBox::information(NULL, "Warning", "Please input parameters", QMessageBox::Yes );
//        urlStr.clear(); //清空两个路径重新加载
//    }else{
//        emit sendURL(urlStr);  //将记录的文件路径信息传给可视化界面
//    }
}

//加载场景模型
void LandslideForm::on_pushButton_9_clicked()
{    
    //获取文件夹路径
    string scenePath; //场景路径
     QString fileName = QFileDialog::getOpenFileName(this);
     if(fileName.isEmpty()){ //选择文件是否存在
         QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
     }else{
         if(lineEdit7->text().isEmpty()){ //是否已经有选择过路径了
             lineEdit7->setText(fileName);
             scenePath=fileName.toStdString();
         }else{ //若之前选择过，现只需修改即可
             scenePath=fileName.toStdString();
             lineEdit7->setText(fileName);
         }
         emit sendScenePath(scenePath);  //用于传送选择的场景
     }
}


//清空所有选择
void LandslideForm::on_pushButton_10_clicked()
{
    urlStr.clear(); //清空容器
    lineEdit->setText("");
    lineEdit2->setText("");
    lineEdit3->setText("");
    lineEdit4->setText("");
    lineEdit5->setText("");
    lineEdit6->setText("");
    lineEdit7->setText("");
    lineEdit8->setText("");
}

void LandslideForm::on_pushButton_11_clicked()
{
    if(lineEdit6->text().isEmpty()){ //是否已经有选择过路径了
        QMessageBox::information(NULL, "Warning", "请先选择镶嵌后的dem", QMessageBox::Yes );
    }else{
        //获取文件夹路径
         QString fileName = QFileDialog::getOpenFileName(this);
         if(fileName.isEmpty()){ //选择文件是否存在
             QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
         }else{
             if(lineEdit8->text().isEmpty()){ //是否已经有选择过路径了
                 lineEdit8->setText(fileName);
                 urlStr.push_back(fileName.toStdString());
             }else{ //若之前选择过，现只需修改即可
                 urlStr[6]=fileName.toStdString();
                 lineEdit8->setText(fileName);
             }
         }
}
}
