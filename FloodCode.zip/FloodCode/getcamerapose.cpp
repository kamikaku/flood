#include "getcamerapose.h"
#include "ui_getcamerapose.h"

GetCameraPose::GetCameraPose(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::GetCameraPose)
{
    ui->setupUi(this);

}

GetCameraPose::~GetCameraPose()
{
    delete ui;
}

void GetCameraPose::Getagrv(vector<double> pVectorParameters)
{
    pvector=pVectorParameters;
//    QString::number(value, 'f', 2);   double2QString
    ui->textEdit->setText(QString::number(pvector[0],'f',2));     //以浮点数输出，保留2位小数
    ui->textEdit_2->setText(QString::number(pvector[1],'f',2));
    ui->textEdit_3->setText(QString::number(pvector[2],'f',2));
    ui->textEdit_5->setText(QString::number(pvector[3],'g',6));
    ui->textEdit_6->setText(QString::number(pvector[4],'g',6));   //以科学计数法输出，保留5位有效数字
    ui->textEdit_4->setText(QString::number(pvector[5],'g',6));
    ui->textEdit_8->setText(QString::number(pvector[6],'f',2));
    ui->textEdit_9->setText(QString::number(pvector[7],'f',2));
    ui->textEdit_7->setText(QString::number(pvector[8],'f',2));

}
