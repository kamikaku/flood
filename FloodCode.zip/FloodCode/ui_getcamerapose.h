/********************************************************************************
** Form generated from reading UI file 'getcamerapose.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GETCAMERAPOSE_H
#define UI_GETCAMERAPOSE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_GetCameraPose
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QTextEdit *textEdit;
    QTextEdit *textEdit_2;
    QTextEdit *textEdit_3;
    QTextEdit *textEdit_4;
    QTextEdit *textEdit_5;
    QTextEdit *textEdit_6;
    QTextEdit *textEdit_7;
    QTextEdit *textEdit_8;
    QTextEdit *textEdit_9;

    void setupUi(QDialog *GetCameraPose)
    {
        if (GetCameraPose->objectName().isEmpty())
            GetCameraPose->setObjectName(QStringLiteral("GetCameraPose"));
        GetCameraPose->resize(735, 220);
        label = new QLabel(GetCameraPose);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 20, 61, 41));
        label->setLayoutDirection(Qt::LeftToRight);
        label_2 = new QLabel(GetCameraPose);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 80, 101, 41));
        label_2->setLayoutDirection(Qt::LeftToRight);
        label_3 = new QLabel(GetCameraPose);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(70, 140, 41, 41));
        label_3->setLayoutDirection(Qt::LeftToRight);
        label_4 = new QLabel(GetCameraPose);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(140, 30, 21, 31));
        label_5 = new QLabel(GetCameraPose);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(340, 30, 21, 31));
        label_6 = new QLabel(GetCameraPose);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(540, 30, 21, 31));
        label_7 = new QLabel(GetCameraPose);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(540, 90, 21, 31));
        label_8 = new QLabel(GetCameraPose);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(340, 90, 21, 31));
        label_9 = new QLabel(GetCameraPose);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(140, 90, 21, 31));
        label_10 = new QLabel(GetCameraPose);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(540, 150, 21, 31));
        label_11 = new QLabel(GetCameraPose);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(340, 150, 21, 31));
        label_12 = new QLabel(GetCameraPose);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(140, 150, 21, 31));
        textEdit = new QTextEdit(GetCameraPose);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(170, 30, 111, 31));
        textEdit_2 = new QTextEdit(GetCameraPose);
        textEdit_2->setObjectName(QStringLiteral("textEdit_2"));
        textEdit_2->setGeometry(QRect(370, 30, 111, 31));
        textEdit_3 = new QTextEdit(GetCameraPose);
        textEdit_3->setObjectName(QStringLiteral("textEdit_3"));
        textEdit_3->setGeometry(QRect(570, 30, 111, 31));
        textEdit_4 = new QTextEdit(GetCameraPose);
        textEdit_4->setObjectName(QStringLiteral("textEdit_4"));
        textEdit_4->setGeometry(QRect(570, 90, 111, 31));
        textEdit_5 = new QTextEdit(GetCameraPose);
        textEdit_5->setObjectName(QStringLiteral("textEdit_5"));
        textEdit_5->setGeometry(QRect(170, 90, 111, 31));
        textEdit_6 = new QTextEdit(GetCameraPose);
        textEdit_6->setObjectName(QStringLiteral("textEdit_6"));
        textEdit_6->setGeometry(QRect(370, 90, 111, 31));
        textEdit_7 = new QTextEdit(GetCameraPose);
        textEdit_7->setObjectName(QStringLiteral("textEdit_7"));
        textEdit_7->setGeometry(QRect(570, 150, 111, 31));
        textEdit_8 = new QTextEdit(GetCameraPose);
        textEdit_8->setObjectName(QStringLiteral("textEdit_8"));
        textEdit_8->setGeometry(QRect(170, 150, 111, 31));
        textEdit_9 = new QTextEdit(GetCameraPose);
        textEdit_9->setObjectName(QStringLiteral("textEdit_9"));
        textEdit_9->setGeometry(QRect(370, 150, 111, 31));

        retranslateUi(GetCameraPose);

        QMetaObject::connectSlotsByName(GetCameraPose);
    } // setupUi

    void retranslateUi(QDialog *GetCameraPose)
    {
        GetCameraPose->setWindowTitle(QApplication::translate("GetCameraPose", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:18pt;\">eye:</span></p></body></html>", Q_NULLPTR));
        label_2->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:18pt;\">center:</span></p></body></html>", Q_NULLPTR));
        label_3->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:18pt;\">up:</span></p></body></html>", Q_NULLPTR));
        label_4->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:14pt;\">X</span></p></body></html>", Q_NULLPTR));
        label_5->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:14pt;\">Y</span></p></body></html>", Q_NULLPTR));
        label_6->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:14pt;\">Z</span></p></body></html>", Q_NULLPTR));
        label_7->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:14pt;\">Z</span></p></body></html>", Q_NULLPTR));
        label_8->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:14pt;\">Y</span></p></body></html>", Q_NULLPTR));
        label_9->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:14pt;\">X</span></p></body></html>", Q_NULLPTR));
        label_10->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:14pt;\">Z</span></p></body></html>", Q_NULLPTR));
        label_11->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:14pt;\">Y</span></p></body></html>", Q_NULLPTR));
        label_12->setText(QApplication::translate("GetCameraPose", "<html><head/><body><p><span style=\" font-size:14pt;\">X</span></p></body></html>", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class GetCameraPose: public Ui_GetCameraPose {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GETCAMERAPOSE_H
