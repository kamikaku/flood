﻿#include "choosefiledialog.h"
#include "ui_choosefiledialog.h"

ChooseFileDialog::ChooseFileDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ChooseFileDialog)
{
    ui->setupUi(this);
    this->setFixedSize(this->width(),this->height());
    this->setWindowTitle("文件路径");

    //connect(ui->chooseButton,SIGNAL(clicked()),this,SLOT(on_chooseButton_clicked()));
}

ChooseFileDialog::~ChooseFileDialog()
{
    delete ui;
}

void ChooseFileDialog::on_chooseButton_clicked()
{

   QString dir = QFileDialog::getExistingDirectory(this, tr("选择文件夹"), "/home", QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

    if(!dir.isEmpty()){
        ui->filePathEdit->setPlainText(dir);
    }


}


void ChooseFileDialog::on_ConfirmButton_clicked()
{
    QString input_data = ui->filePathEdit->toPlainText();
    if(input_data.isEmpty()){
        QMessageBox mbox;
        mbox.setText("提示!");
        mbox.setInformativeText("确定所选路径为空吗？");
        mbox.setStandardButtons(QMessageBox::Yes| QMessageBox::No);
        mbox.setDefaultButton(QMessageBox::No);
        mbox.setButtonText(QMessageBox::Yes, QString("确 定"));
        mbox.setButtonText(QMessageBox::No, QString("取 消"));
        int ret = mbox.exec();
        switch(ret){
            case QMessageBox::Yes:
                this->close();
            break;
        case QMessageBox::No:
            break;
        }
    }
    else{
     this->path = input_data;
        std::list<FileManage>::iterator itr;
        for(itr=BindingFiles.begin();itr!=BindingFiles.end();++itr){
            if(nodename==itr->getName()){
                nodetype = itr->getType();
                FileManage fm(nodename,path,nodetype);
                *itr = fm;
            }
        }

        //绑定完成之后重新读取进json文件中
            QJsonArray Bind_files;
            for(itr=BindingFiles.begin();itr!=BindingFiles.end();++itr){
                QJsonObject obj;
                obj.insert("name",itr->getName());
                obj.insert("path",itr->getPath());
                obj.insert("type",itr->getType());
                Bind_files.append(obj);
            }
            QJsonObject Viewtree_root;
            Viewtree_root.insert("test",Bind_files);
            QString new_json = QJsonDocument(Viewtree_root).toJson();
            QString ExePath = QCoreApplication::applicationDirPath();
            QFile file(ExePath+"/TreeMeta.json");
            //存在打开，不存在创建
            file.open(QIODevice::WriteOnly | QIODevice::Text);
            //写入内容,这里需要转码，否则报错。
            QByteArray str = new_json.toUtf8();

            //写入QByteArray格式字符串
            file.write(str);
            QMessageBox::warning(this,"绑定","绑定文件路径完成！");
            file.flush();
            //关闭文件
            file.close();

     this->close();

     //qDebug()<<path;
    }

}
