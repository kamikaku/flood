﻿#include "barrierlake.h"

BarrierLake::BarrierLake(float widh,float heigh,float Lh):w(widh),h(heigh)
{
    Lake_H = Lh;
}

//获取堰塞湖的初始位置
void BarrierLake::get_Pos(std::string path){

    osg::ref_ptr<osg::Node> blake = osgDB::readNodeFile(path);
    if(blake==NULL)
    {
        return;
    }
    osg::ComputeBoundsVisitor boundVisitor;
    blake->accept(boundVisitor);
    osg::BoundingBox boundingBox = boundVisitor.getBoundingBox();
    pos_S = osg::Vec3(boundingBox.xMin(),boundingBox.yMin(),boundingBox.zMax()+Lake_H); //设定堰塞湖的初始位置

    pos_init = pos_S;

}


//画堰塞湖
osg::ref_ptr<osg::Node> BarrierLake::Draw_Lake(){

    osg::Vec3 width = osg::Vec3(w,0.0f,0.0f);
    osg::Vec3 heigh = osg::Vec3(0.0f,h,0.0f);

    osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
            //定义顶点
            osg::ref_ptr<osg::Vec3Array> vertexArray = new osg::Vec3Array;
            geometry->setVertexArray(vertexArray);
            vertexArray->push_back(osg::Vec3(pos_S.x(), pos_S.y(), pos_S.z()));
            vertexArray->push_back(osg::Vec3(pos_S.x()+width.x(), pos_S.y(), pos_S.z()));
            vertexArray->push_back(osg::Vec3(pos_S.x()+width.x(), pos_S.y()+heigh.y(), pos_S.z()));
            vertexArray->push_back(osg::Vec3(pos_S.x(), pos_S.y()+heigh.y(), pos_S.z()));
            //定义颜色数组
            osg::ref_ptr<osg::Vec4Array> colorArray = new osg::Vec4Array();
            geometry->setColorArray(colorArray);
            geometry->setColorBinding(osg::Geometry::BIND_PER_VERTEX);
            colorArray->push_back(osg::Vec4(99.0/255.0f,119.0/255.0f,115.0/255.0f,0.98));
            colorArray->push_back(osg::Vec4(122.0/255.0f,138.0/255.0f,128.0/255.0f,0.98));
            colorArray->push_back(osg::Vec4(157.0/255.0f,161.0/255.0f,159.0/255.0f,0.85));
            colorArray->push_back(osg::Vec4(158.0/255.0f,151.0/255.0f,154.0/255.0f,0.9));

            //设置顶点关联方式
             //PrimitiveSet类，这个类松散地封装了OpenGL的绘图基元，
             //包括点（POINTS），线（LINES），多段线（LINE_STRIP），封闭线（LINE_LOOP），四边形（QUADS），多边形（POLYGON）等。
             geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS, 0, 4));
                  //开启融合操作
             geometry ->getOrCreateStateSet()->setMode(GL_BLEND, osg::StateAttribute::ON);
             //设置渲染模式
             geometry ->getOrCreateStateSet()->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
             //关闭光照，这样任意面，都可以看到半透明效果。
             geometry ->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

             osg::ref_ptr<osg::Geode> geode=new osg::Geode;
             geode->addDrawable(geometry);

            return geode.get();

}

//改变堰塞湖的位置
void BarrierLake::change_Pos(){

    pos_S = pos_init - dpos;
}


//初始化堰塞湖位置
void BarrierLake::init_Pos(){
    pos_S = pos_init;
}
