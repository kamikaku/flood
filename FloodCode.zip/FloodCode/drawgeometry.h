﻿#ifndef DRAWGEOMETRY_H
#define DRAWGEOMETRY_H
#pragma execution_character_set("utf-8")

//#include <Windows.h>
#include <QWidget>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <time.h>

#include <QDebug>
#include <QPushButton>
#include <QFileDialog>
#include <QString>
#include <QLineEdit>
#include <QMessageBox>
#include <QTextCodec>

#include <osgUtil/DelaunayTriangulator>
#include <osgUtil/TriStripVisitor>
#include <osg/Drawable>
#include <osg/ShapeDrawable>
#include <osg/Texture2D>
#include <osg/TexEnv>
#include <osg/TexGen>
#include <osg/DrawPixels>

#include<osg/LineWidth>
#include<osg/Point>
#include<osg/BoundingBox>
#include<osg/NodeVisitor>
#include<osg/ComputeBoundsVisitor>
#include<osg/AutoTransform>
#include <osg/PositionAttitudeTransform>
#include <osg/Material>

#include "adapterwidget.h"
#include "viewerqt.h"
#include "blinkingdisplay.h"
#include "globalvar.h"

#include "gdal.h"
#include "gdal_priv.h"
#include "gdal_version.h"
#include "ogrsf_frmts.h"
#include "xmldoc.h"
#include "caculator.h"

extern std::list<FileManage> BindingFiles;
extern QString NOW_NODENAME;

class DrawGeometry
{
public:
    DrawGeometry();
    osg::ref_ptr<osg::Node> turn_Billboard(osg::Node* node,osg::Vec3 position,osg::Vec3 scale);
    osg::ref_ptr<osg::Node> Drawtext(const char* info,osg::Vec3 position);
    osg::ref_ptr<osg::Node> Background(float dx,float dz,osg::Vec3 center);
    osg::ref_ptr<osg::Node> AutoTrans(osg::Node* node,osg::Vec3 position);
    osg::ref_ptr<osg::Node> Textinfo(const char* c,osg::Vec3 pos,osg::Quat quat,osgText::Text::Layout lay,float scale);
    osg::ref_ptr<osg::Node> Textinfo(const char* c,osg::Vec3 pos,osg::Quat quat,float scale,bool isBound=false);
    osg::ref_ptr<osg::Node> Textinfo(string c,osg::Vec3 pos,osg::Quat quat,float scale,bool isBound=false);

    osg::ref_ptr<osg::Node> DoubleArrow(osg::Vec3 pos,osg::Quat quat,osg::Vec3 scale);
    //创建缩放的动画
    osg::ref_ptr<osg::AnimationPath> createScaleAni(osg::Vec3 pos,osg::Quat quat,osg::Vec3 scale);
    osg::ref_ptr<osg::Node> return_DArrow(osg::Vec3 pos,osg::Quat quat,osg::Vec3 scale);//给双箭头赋予动画
    osg::ref_ptr<osg::Node> Return_G(int num);
    osg::ref_ptr<osg::Node> Reason();

    //画线
    osg::ref_ptr<osg::Node> DrawinfoLine(osg::Vec3 pos1,osg::Vec3 pos2,osg::Vec4 color);
    //string2UTF-8
    std::wstring string_To_wstring(string pStr);

    //x字y底
   osg::ref_ptr<osg::Node> WB_BT(string c,osg::Vec3 pos,float scale,osg::Vec4 tcolor=osg::Vec4(0,0.3,0.6,1),osg::Vec4 bcolor=osg::Vec4(1,1,1,1));
   osg::ref_ptr<osg::Node> WB_BT(const char* c, osg::Vec3 pos, float scale,osg::Vec4 tcolor=osg::Vec4(0,0.3,0.6,1), osg::Vec4 bcolor=osg::Vec4(1,1,1,1));

   osg::ref_ptr<osg::Node> WB_BT_AutoScreen(const char* c, osg::Vec3 pos, float scale,bool withline = false,osg::Vec4 tcolor=osg::Vec4(0,0.3,0.6,1),osg::Vec4 bcolor=osg::Vec4(1,1,1,1));
       osg::ref_ptr<osg::Node> WB_BT_AutoScreen(string c, osg::Vec3 pos, float scale,bool withline = false,osg::Vec4 tcolor=osg::Vec4(0,0.3,0.6,1),osg::Vec4 bcolor=osg::Vec4(1,1,1,1));

       osg::ref_ptr<osg::Node> Word_Side(string c, osg::Vec3 pos, float scale,osg::Vec4 tcolor=osg::Vec4(85/255.0,1/255.0,13/255.0,1),osg::Vec4 scolor=osg::Vec4(1,1,1,1));

       osg::ref_ptr<osg::Node> drawBendarrow(osg::Vec3 v1,osg::Vec3 v2,float width,std::string imagepath,int drawtype=1);

};

#endif // DRAWGEOMETRY_H
