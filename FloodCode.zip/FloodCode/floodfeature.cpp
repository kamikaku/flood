﻿#include "floodfeature.h"
#include <string>
#include "renderclass.h"
FloodFeature::FloodFeature()
{

}

//创建显示面板 用于显示洪水的参数
osg::ref_ptr<osg::Camera> FloodFeature::CreateHUD(){

    //图例面板背景颜色
      osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
      osg::ref_ptr<osg::Vec4Array>colorArray=new osg::Vec4Array;
      geometry=osg::createTexturedQuadGeometry(osg::Vec3(620.0f,500.0f,0.0f),
                                               osg::Vec3(180.0f,0.0f,0.0f),osg::Vec3(0.0f,100.0f,0.0f));
//      colorArray->push_back(osg::Vec4(0.9,0.9,0.88,0.5f)); //getColor是根据属性值计算颜色值的函数，需自行定义
//       colorArray->push_back(osg::Vec4(0.0,0.6,0.8,0.4f));
      colorArray->push_back(osg::Vec4(0.8,0.8,0.8,0.5f));
      geometry->setColorArray(colorArray.get());
      geometry->setColorBinding(osg::Geometry::BIND_OVERALL);

      //文字


      //演进时间
      osgText::Text *text2=new osgText::Text;
      //设置字体
      text2->setFont("fonts/simhei.ttf");
      //设置文字显示的位置
      text2->setPosition(osg::Vec3(640.0f,570.0f,0.0f));
      text2->setColor( osg::Vec4( 0, 0, 0, 1));
      int rt = (int)runTime;
      std::string rtime = "演进时间 ";//+std::to_string(runTime)+" 秒";
      if(rt<60){
          rtime+=std::to_string(rt)+" 秒";
      }
      else if(rt<3600)
      {
          int sec = rt % 60;
          rt = rt/60;
          rtime+=std::to_string(rt)+" 分 ";
          rtime+=std::to_string(sec)+" 秒";
      }
      else
      {
        int m = rt%3600;
        int s = m%60;
        m = m/60;
        rt = rt/3600;
        rtime+=std::to_string(rt)+" 时 ";
        rtime+=std::to_string(m)+" 分 ";
        rtime+=std::to_string(s)+" 秒";
      }
      const char* runc = rtime.c_str();
      QTextCodec* code2 = QTextCodec::codecForName("UTF-8");
      QString qstr2 = QObject::tr(runc);
      std::string str2 = code2->fromUnicode(qstr2).data();
      text2->setText(str2, osgText::String::ENCODING_UTF8);
      text2->setCharacterSize(12);  //设置字体大小

      //总库容
      osgText::Text *text1=new osgText::Text;
      //设置字体
      text1->setFont("fonts/simhei.ttf");
      //设置文字显示的位置
      text1->setPosition(osg::Vec3(640.0f,510.0f,0.0f));
      text1->setColor( osg::Vec4( 0, 0, 0, 1));
      std::string tVol = "总库容: ";

      if(totalVol>10000000){

          float vol = totalVol/100000000;
          QString str = QString::number(vol,'f',2);

          tVol+=str.toStdString();
          tVol+=" 亿立方米";
      }

      else if(totalVol>1000000){

          float vol = totalVol/1000000;
          QString str = QString::number(vol,'f',2);

          tVol+=str.toStdString();
          tVol+=" 百万立方米";
      }
      else if(totalVol>1000)
      {
          float vol = totalVol/10000;
          QString str = QString::number(vol,'f',2);

          tVol+=str.toStdString();
          tVol+=" 万立方米";
      }
      else{
          float vol = totalVol;
          QString str = QString::number(vol,'f',2);

          tVol+=str.toStdString();
          tVol+=" 立方米";
      }


      const char* tvolc = tVol.c_str();
      QTextCodec* code1 = QTextCodec::codecForName("UTF-8");
      QString qstr1 = QObject::tr(tvolc);
      std::string str1 = code1->fromUnicode(qstr1).data();
      text1->setText(str1, osgText::String::ENCODING_UTF8);
      text1->setCharacterSize(12);  //设置字体大小


      //剩余库容

      osgText::Text *text3=new osgText::Text;
      //设置字体
      text3->setFont("fonts/simhei.ttf");
      //设置文字显示的位置
      text3->setPosition(osg::Vec3(640.0f,540.0f,0.0f));
      text3->setColor(osg::Vec4( 0, 0, 0, 1));
      std::string dep = "剩余库容: ";//+std::to_string(vol)+" 立方米";

      if(restVol>10000000){

          float vol = restVol/100000000;
          QString str = QString::number(vol,'f',2);

          dep+=str.toStdString();
          dep+=" 亿立方米";
      }

      else if(restVol>1000000){

          float vol = restVol/1000000;
          QString str = QString::number(vol,'f',2);

          dep+=str.toStdString();
          dep+=" 百万立方米";
      }
      else if(restVol>1000)
      {
          float vol = restVol/10000;
          QString str = QString::number(vol,'f',2);

          dep+=str.toStdString();
          dep+=" 万立方米";
      }
      else{
          float vol = restVol;
          QString str = QString::number(vol,'f',2);

          dep+=str.toStdString();
          dep+=" 立方米";
      }
      const char* depc = dep.c_str();
      QTextCodec* code3 = QTextCodec::codecForName("UTF-8");
      QString qstr3 = QObject::tr(depc);
      std::string str3 = code3->fromUnicode(qstr3).data();
      text3->setText(str3, osgText::String::ENCODING_UTF8);
      text3->setCharacterSize(12);  //设置字体大小


      //几何体节点
      osg::Geode*geode=new osg::Geode();
      geode->addChild(geometry);

      //将文字Text作这drawable加入到Geode节点中
//      geode->addDrawable(text);
      geode->addDrawable(text1); //将文字Text作这drawable加入到Geode节点中
      geode->addDrawable(text2); //将文字Text作这drawable加入到Geode节点中
      geode->addDrawable(text3); //将文字Text作这drawable加入到Geode节点中



      //设置状态
      osg::StateSet* stateset = geode->getOrCreateStateSet();
      stateset->setMode(GL_LIGHTING,osg::StateAttribute::OFF);//关闭灯光
      stateset->setMode(GL_DEPTH_TEST,osg::StateAttribute::OFF);//关闭深度测试
      //打开GL_BLEND混合模式（以保证Alpha纹理正确）
      stateset->setMode(GL_BLEND,osg::StateAttribute::ON);

      //相机
      osg::Camera* camera = new osg::Camera;
      //设置透视矩阵
      camera->setProjectionMatrix(osg::Matrix::ortho2D(0,800,0,600));//正交投影
      //设置绝对参考坐标系，确保视图矩阵不会被上级节点的变换矩阵影响
      camera->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
      //视图矩阵为默认的
      camera->setViewMatrix(osg::Matrix::identity());
      //设置背景为透明，否则的话可以设置ClearColor
      camera->setClearMask(GL_DEPTH_BUFFER_BIT);
      camera->setAllowEventFocus( false);//不响应事件，始终得不到焦点
      //设置渲染顺序，必须在最后渲染
      camera->setRenderOrder(osg::Camera::POST_RENDER);
      camera->addChild(geode);//将要显示的Geode节点加入到相机
      return camera;

}


//将每一帧的洪水参数输出为txt文件

void FloodFeature::output_TO_TXT(std::string path){

// std::ofstream outfile;

//    outfile.open(path.c_str(),std::ios::out|std::ios::app);
//    if(!outfile.is_open()){
//        return ;
//    }

//    //写入
//    outfile<<velocity<<"\n"<<discharge<<"\n"<<runTime<<"\n"<<depth;

//    outfile.close();

    QString outpath = QString(QString::fromLocal8Bit(path.c_str()));//string转为QString
    QFile fout(outpath);
    if(!fout.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        std::cout << "Open failed." << endl;
        return;
    }

    QTextStream txtOutput(&fout);

//    QString vel = QString("%1").arg(velocity);
//    QString dis = QString("%1").arg(discharge);
    QString rtime = QString("%1").arg(runTime);
//    QString dep = QString("%1").arg(depth);
    QString rvol = QString("%1").arg(restVol);
    QString tvol = QString("%1").arg(totalVol);
    QString tshallow = QString("%1").arg(shallow);
    QString tdeep = QString("%1").arg(deep);

//    txtOutput<<vel<<'\n'<<dis<<'\n'<<rtime<<'\n'<<dep;
    txtOutput<<rtime<<'\n'<<rvol<<'\n'<<tvol<<'\n'<<tshallow<<'\n'<<tdeep;
    fout.close();

}


//读取存储洪水参数的txt文件
void FloodFeature::input_from_TXT(std::string path){

    QString inpath = QString(QString::fromLocal8Bit(path.c_str()));
    QFile fin(inpath);
    if(!fin.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        std::cout << "Open failed." << endl;
        return;
    }
    QTextStream txtInput(&fin);
//    QString finfo[4];
//    QString finfo[2];
//    QString finfo[3];
    QString finfo[5];

    QString lineStr;
    int i=0;
    while(!txtInput.atEnd())
    {
        lineStr = txtInput.readLine();
        finfo[i] = lineStr;

        if(i>4){break;}
        i++;
    }

//    velocity = finfo[0].toFloat();
//    discharge = finfo[1].toFloat();
    runTime = finfo[0].toFloat();
    restVol = finfo[1].toFloat();
    totalVol = finfo[2].toFloat();
    shallow = finfo[3].toInt();
    deep = finfo[4].toInt();
//    depth = finfo[3].toFloat();


    fin.close();
}



//显示洪水中的要素
osg::ref_ptr<osg::Group> FloodFeature::return_Signs(){

        std::string path = return_ViewTree_Path(NOW_NODENAME).toStdString(); //洪水标记内容的路径
        XMLDoc *pxml = new XMLDoc();
         vector<string> pHouse;
         vector<string> pRiver;
         vector<string> pRoad;
        pHouse=pxml->readXmlFnD("House");
        pRiver=pxml->readXmlFnD("River");
        pRoad=pxml->readXmlFnD("Road");

        ReadshpDialog *rdg = new ReadshpDialog();
        std::string hpath,wpath,rpath="";

//    std::string path = "E:/DiasterData/flood_jinshajiang";
         if(pHouse.size()!=0){
             hpath = pHouse[0];
         }
         if(pRiver.size()!=0){
             wpath = pRiver[0];
         }
         if(pRoad.size()!=0){
             rpath = pRoad[0];
         }
    //创建Group
        osg::ref_ptr<osg::Group> group = new osg::Group;

     //加载房屋
        std::string hp =hpath;//+"house.shp";
//        if(hp!=""){
////        rdg->color = QColor(9,247,104);
//          rdg->renderrank = 6.0f;
//          rdg->color = QColor(176,232,220);
//        rdg->read_shp(hp.c_str());
//        group->addChild(rdg->draw_SHP()->asNode());
//        }

        DamageDescription *dd= new DamageDescription();

        if(hp!=""){
                    list<list<Point3D>> list2 = dd->gdal_read_polygonshp(hp.c_str());
                    list<Point3D> plist;
                    std::list<std::list<Point3D>>::iterator it2;

                 //设置颜色
                 osg::ref_ptr<osg::Vec4Array> housecolors = new osg::Vec4Array;

                 //添加数据
                 housecolors->push_back(osg::Vec4(195/255.0f, 231/255.0f, 239/255.0f, 1.0));//176 226 255
                 for ( it2=list2.begin() ; it2 != list2.end(); it2++ )
                 {
                     plist=*it2;
                     osg::ref_ptr<osg::Geode> building1_prjnode=dd->Drawsamplehouse(plist,housecolors);
                     //关闭光源(必须添加，不然会影响加载的其他shp，导致光线变黑)
                     building1_prjnode->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源
                   RenderClass *rc = new RenderClass;
                   rc->setNodeRender(*building1_prjnode,6.0f);

                     group->addChild(building1_prjnode.get());
                 }

        }
//        list<list<Point3D>> list2 = dd->gdal_read_polygonshp(hp.c_str());
//        list<Point3D> plist;
//        std::list<std::list<Point3D>>::iterator it2;

//     //设置颜色
//     osg::ref_ptr<osg::Vec4Array> housecolors = new osg::Vec4Array;

//     //添加数据
//     housecolors->push_back(osg::Vec4(0.9, 0.9, 0.8, 1.0));
//     for ( it2=list2.begin() ; it2 != list2.end(); it2++ )
//     {
//         plist=*it2;
//         osg::ref_ptr<osg::Geode> building1_prjnode=dd->Drawsamplehouse(plist,housecolors);
//         //关闭光源(必须添加，不然会影响加载的其他shp，导致光线变黑)
//         building1_prjnode->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源
//         group->addChild(building1_prjnode.get());
//     }


        //加载河道
   //     osg::ref_ptr<osg::Node> maskriver = osgDB::readNodeFile(wpath+"riverway.shp");
        std::string mrpath = wpath;//+"riverway.shp";
        if(mrpath!=""){
         rdg = new ReadshpDialog();
        rdg->renderrank = 1.0f;
        rdg->color = QColor(0,102,255);
        rdg->read_shp(mrpath.c_str());
        group->addChild(rdg->draw_SHP()->asNode());
        }


     //加载道路
//     osg::ref_ptr<osg::Node> road = osgDB::readNodeFile(rpath+"route.shp");
     std::string rdpath = rpath;//+"route.shp";
     if(rpath!=""){
//     rdg->color = QColor(221,184,34);
         rdg = new ReadshpDialog();
       rdg->renderrank = 1.0f;
       rdg->color = QColor(246,222,145);
         rdg->linew = 3.0f;
     rdg->read_shp(rdpath.c_str());
     group->addChild(rdg->draw_SHP()->asNode());
     }



     //加载标记


    vector<string> pVectorotherFeature = pxml->readXmlFnD("Othershp");
    for(int i =0;i<pVectorotherFeature.size();i++){

        if(i==0){

         std::string opath = pVectorotherFeature[i];
         rdg = new ReadshpDialog;
//         rdg->color = QColor(77,179,118);
         rdg->txcolor = QColor(255,255,255);
        rdg->read_shp(opath.c_str());
        group->addChild(rdg->draw_SHP());
        }
        if(i==1){
//            std::string opath = pVectorotherFeature[i];
//            rdg = new ReadshpDialog;
//            rdg->txcolor = QColor(255,0,255);
//            rdg->txsize = 35;
//            rdg->read_shp(opath.c_str());
//            group->addChild(rdg->draw_SHP());

        }
    }

    delete pxml;
    delete rdg;
//    delete sk;

return group.get();

}


osg::ref_ptr<osg::Camera> FloodFeature::CreateSD(){


    //图例面板背景颜色
//      osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
//      osg::ref_ptr<osg::Vec4Array>colorArray=new osg::Vec4Array;
//      geometry=osg::createTexturedQuadGeometry(osg::Vec3(620.0f,500.0f,0.0f),
//                                               osg::Vec3(180.0f,0.0f,0.0f),osg::Vec3(0.0f,100.0f,0.0f));
////      colorArray->push_back(osg::Vec4(0.9,0.9,0.88,0.5f)); //getColor是根据属性值计算颜色值的函数，需自行定义
////       colorArray->push_back(osg::Vec4(0.0,0.6,0.8,0.4f));
//      colorArray->push_back(osg::Vec4(0.8,0.8,0.8,0.5f));
//      geometry->setColorArray(colorArray.get());
//      geometry->setColorBinding(osg::Geometry::BIND_OVERALL);

    osgText::Text *text1=new osgText::Text;
    //设置字体
    text1->setFont("fonts/simhei.ttf");
    //设置文字显示的位置
    text1->setPosition(osg::Vec3(380.0f,4.0f,0.0f));
    text1->setColor( osg::Vec4( 1, 1, 1, 1));
    std::string sd = "Deep";
    const char* sdc = sd.c_str();
    QTextCodec* code = QTextCodec::codecForName("UTF-8");
    QString qstr = QObject::tr(sdc);
    std::string str = code->fromUnicode(qstr).data();
    text1->setText(str, osgText::String::ENCODING_UTF8);
    text1->setCharacterSize(11);  //设置字体大小

    osg::Geode *geode=new osg::Geode();
//    geode->addChild(geometry);
    geode->addDrawable(text1);

    //设置状态
    osg::StateSet* stateset = geode->getOrCreateStateSet();
    stateset->setMode(GL_LIGHTING,osg::StateAttribute::OFF);//关闭灯光
    stateset->setMode(GL_DEPTH_TEST,osg::StateAttribute::OFF);//关闭深度测试
    //打开GL_BLEND混合模式（以保证Alpha纹理正确）
    stateset->setMode(GL_BLEND,osg::StateAttribute::ON);



    //相机
    osg::Camera* camera = new osg::Camera;
    //设置透视矩阵
    camera->setProjectionMatrix(osg::Matrix::ortho2D(0,800,0,600));//正交投影
    //设置绝对参考坐标系，确保视图矩阵不会被上级节点的变换矩阵影响
    camera->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
    //视图矩阵为默认的
    camera->setViewMatrix(osg::Matrix::identity());
    //设置背景为透明，否则的话可以设置ClearColor
    camera->setClearMask(GL_DEPTH_BUFFER_BIT);
    camera->setAllowEventFocus( false);//不响应事件，始终得不到焦点
    //设置渲染顺序，必须在最后渲染
    camera->setRenderOrder(osg::Camera::POST_RENDER);
    camera->addChild(geode);//将要显示的Geode节点加入到相机
    return camera;

}
