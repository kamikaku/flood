﻿#ifndef FLOODFORM_H
#define FLOODFORM_H
#pragma execution_character_set("utf-8")

#include <QWidget>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <time.h>

#include <QPushButton>
#include <QLineEdit>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QFileDialog>
#include <QString>
#include <QMessageBox>

#include <osgUtil/DelaunayTriangulator>
#include <osgUtil/TriStripVisitor>
#include <osg/Drawable>

#include "adapterwidget.h"
#include "viewerqt.h"
#include "createscalarbar.h"

using namespace std;

namespace Ui {
class FloodForm;
}

class FloodForm : public QWidget
{
    Q_OBJECT

public:
    explicit FloodForm(QWidget *parent = 0);
    ~FloodForm();

private:
    Ui::FloodForm *ui;

public:  //定义成员变量
    std::string Fformat=".ive";
    ViewerQT *viewer;
//    osg::ref_ptr<osg::Group> root;
    osg::ref_ptr<osg::Geode> geode;
//    vector<vector<string>>vdem;// 存放分割后的字符串,DEM文件
    vector<float> floodValues;  //存储洪水界面的参数值
    vector<string> urlStr; //用于存储选择场景和计算文件路径

    osg::Vec4 color1=osg::Vec4(1,0.89,0.76,1.0f);  //浅颜色
    osg::Vec4 color2=osg::Vec4(0.94,0.46,0.02,1.0f);  //深颜色

    QPushButton *pushButton;

    QLineEdit *lineEdit1;
    QLineEdit *lineEdit2;
    QLineEdit *lineEdit3;
    QLineEdit *lineEdit4;  //现在计算文件信息
    QLineEdit *lineEdit5;
    QLineEdit *lineEdit6;
    QLineEdit *lineEdit7;
    QLineEdit *lineEdit8;
    float damVolume;  //库容
    float damWidth; //坝宽
    float damHeight; //坝高

    QDoubleSpinBox *doubleSpinBox1;
    QDoubleSpinBox *doubleSpinBox2;

//    QSpinBox *spinBox5;
    float breakWidth; //溃口宽度
    float breakHeight; //溃口高度
    float spatialTimeRatio = 100; //时空比率

public:
    osg::Vec4 floodColor(float ZValue, float D_value);  //设置洪水颜色
    osg::ref_ptr<osg::Node> createLegend(int minValue,int maxValue); //创建图例，主要显示各种灾害颜色代表意义

private slots:
    void on_pushButton_3_clicked();  //按钮事件，开始计算
    void on_pushButton_4_clicked();  //洪水演进按钮

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();


    void on_pushButton_9_clicked();

signals:
    void transmitSignals(bool flag);
    void sendfloodValues( vector<QString> values);
    void sendStart(int flag); //开始演进
    void sendURL(vector<string> UrlStr);  //用于传送选择的场景和计算需要的文件路径
    void sendScenePath(string sceneUrl);  //用于传送选择的场景


};

#endif // FLOODFORM_H
