﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
//    ui->widget->installEventFilter(this);
//    ui->widget->setStyleSheet("background-color:white;");
    QFile file(":/qss/qss/MacOS.qss");
    file.open(QFile::ReadOnly);
    QString styleSheet = QLatin1String(file.readAll());
    qApp->setStyleSheet(styleSheet);

    treeView=ui->treeView;  //目录树    
    m_statusLabel = new QLabel;
    m_statusLabel->resize(100, 30);
    ui->statusBar->addPermanentWidget(m_statusLabel);
    QTimer* coordTime = new QTimer;
    timerM = new QTimer;
//    coordTime->start(0.01);
//    connect(coordTime,SIGNAL(timeout()),this,SLOT(showCoordinate()));

    createActions(); //菜单栏布局
    ff = new FloodForm;   //初始化洪水界面
    df = new DebrisFlow(); //初始化泥石流界面
    ll = new LandslideForm(); //初始化滑坡界面
    lf=new LandslideInfor();  //初始化滑坡信息类
    fl = new floodInfo;
    floodf = new FloodFeature();//洪水参数类
    debf = new Debrisflowfeature();//泥石流参数类

    mr = new Monitor;//监测站，监测流量，流速，水深
    rootflood = new osg::Group;
//    ShapeMark* sk = new ShapeMark;
//    sk->read_text("E:/TEMPTEST/mark.xml");
//    std::string pathm = "E:/JSJTEST/ML618.shp";
//    mr->Get_Monitior(pathm);
    //viewWeb->load(QUrl("www.baidu.com"));



//    osg::ref_ptr<osg::Camera> cm = floodf->CreateHUD();
//    floodf->output_TO_TXT("E:/1.txt");
//    floodf->input_from_TXT("E:/1.txt");
//    osg::ref_ptr<osg::Camera> cm = floodf->CreateHUD();

    m_pFlood=new CAFlood();
    m_pDebrisFlow=new CADebrisFlow();

    timer=new QTimer;  //在构函中对直接new一个timer对象供程序使用，保证只有一个对象即后面不需要在new
    //===添加场景
    viewer = new ViewerQT;
    viewer->setCameraManipulator(new osgGA::TrackballManipulator);
    root = new osg::Group;
    rootflood=new osg::Group;
    rootflood1=new osg::Group;

    rootlandslide=new osg::Group;


    setlocale( LC_ALL, "chs" );   //很关键的一个函数，识别unicode中文字符


     shpNodes =new osg::Group;
     shpNodes->setName("shpLayer");
     shpNodes->setDataVariance(osg::Object::DYNAMIC);


    //简单交互事件
    viewer->setCameraManipulator(new osgGA::TrackballManipulator);
    viewer->setSceneData(root);   //会重置视点为系统默认的视点

    //设置初始视点
    if(terrain!=NULL){

        root->addChild(terrain);
        viewer->setCameraManipulator(new osgGA::TrackballManipulator);

    }


    viewer->addEventHandler(new UseEventHandler());  //事件回调，获取鼠标释放后的视点
    viewer->addEventHandler(new PickHandle());//点击鼠标获取三维坐标事件

    //创建光源
    //设置默认光源，位置在右上角
    viewer->getLight()->setPosition(osg::Vec4(1.0f,1.0f,0.0f,0.0f));
    //环境光
    viewer->getLight()->setAmbient(osg::Vec4(0.6f,0.6f,0.6f,1.0f));
    //漫反射光
    viewer->getLight()->setDiffuse(osg::Vec4(0.2f,0.2f,0.2f,1.0f));


    viewer->addEventHandler(new osgGA::StateSetManipulator(viewer->getCamera()->getOrCreateStateSet()));
    root->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);

    //布局加载显示
    hLayout = ui->horizontalLayout_2;
    hLayout->addWidget(viewer);

}

MainWindow::~MainWindow()
{
    delete ui;
}

//##############尝试子控件绘图#########################


//bool MainWindow::eventFilter(QObject *watched, QEvent *event)
//{
//    if(watched == ui->widget && event->type() == QEvent::Paint)
//    {
//        showPaint(); //响应函数
//    }
//    return QWidget::eventFilter(watched,event);
//}

////实现响应函数
//void MainWindow::showPaint()
//{
//    QPainter painter(ui->widget);
//    painter.setPen(QPen(Qt::black,3));
////    painter.setBrush(Qt::black);
////    painter.drawRect(1,1,20,20);
//     painter.drawLine(240,90,130,270);
//     painter.drawLine(240,90,340,270);//1 2 层

//     painter.drawLine(340,270,60,460);
//     painter.drawLine(340,270,240,460);
//     painter.drawLine(340,270,420,460);//2 3层
//}


//#################################################
//读取JSON文件
QJsonObject MainWindow::readJSON(QString json){
    QFile file(json);
    file.open(QFile::ReadOnly | QFile::Text);
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("GBK"));
    QTextCodec *codec = QTextCodec::codecForName("UTF8");
//    if(!file.open(QIODevice::ReadOnly))
//    {
//        return QJsonObject();
//    }

    QString datastr = codec->toUnicode(file.readAll());//file.readAll();
    QByteArray data = datastr.toUtf8();
    file.close();

    QJsonParseError json_error;
    QJsonDocument jsonDoc(QJsonDocument::fromJson(data,&json_error));

    if(json_error.error != QJsonParseError::NoError)
    {
        return QJsonObject();
    }

    QJsonObject rootObj = jsonDoc.object();
    QStringList keys = rootObj.keys();


//       for(int i = 0; i < keys.size(); i++)
//       {
//           qDebug() << "key" << i << " is:" << keys.at(i);
//       }

//             QJsonArray dataArray = rootObj.value("test").toArray();
//             for(int i=0;i<dataArray.count();i++){
//                QJsonObject obj = dataArray.at(i).toObject();
//                qDebug() << obj.value("name").toString();
//             }

    return rootObj;
}


//======目录树双击跳场景=====
void MainWindow::OnlineTreeViewDoubleClick(const QModelIndex & index){

    osg::Vec3d eye,center,up;
    //float distance = 2.40415e-019;
    QString name = index.data().toString();

    bool flag = model->itemFromIndex(index)->isEnabled();
    NOW_NODENAME = name;
    std::string NodePath = return_ViewTree_Path(name).toStdString();
    std::string NodeType = return_ViewTree_Type(name).toStdString();

    //文件解析
    XMLDoc *pXmlDoc=new XMLDoc();


    if(NodeType == "1"){
        types=1;
         root->removeChild(0,root->getNumChildren()); //删除场景中所有节点
        //跑的时候只让当前节点可用
        for(int i=0;i<BindingFiles.size();i++){
            model->item(i)->setEnabled(false);
        }
        model->itemFromIndex(index)->setEnabled(false);

//        osg::ref_ptr<osg::Node> t = osgDB::readNodeFile(NodePath+"/Disaster_DiXing/jinshajiang.ive");

        vector<string> pFloodfile;
        pFloodfile=pXmlDoc->readXmlFnD("Path");
        osg::ref_ptr<osg::Node> t = osgDB::readNodeFile(pFloodfile[0]);
        root->addChild(t.get()); //加载场景

//        vector<string> Barrierfile;
//        Barrierfile=pXmlDoc->readXmlFnD("BarrierLake");
//        brLake = NULL;
//        if(Barrierfile.size()!=0){
//            if(Barrierfile[0]!=""){
//             brLake = new BarrierLake(2000,2000,40);//初始化lake
//             std::string p = Barrierfile[0]; //NodePath+"/Disaster_Signs/River/BarrierLake.shp";
//             brLake->get_Pos(p);
//            }
//        }

        vector<string> CameraVector;
        CameraVector=pXmlDoc->readXmlFnD("Camera");
        eye = osg::Vec3d(atof(const_cast<const char *>(CameraVector[0].c_str())), atof(const_cast<const char *>(CameraVector[1].c_str())), atof(const_cast<const char *>(CameraVector[2].c_str())));   //将string转化为double
        center = osg::Vec3d(atof(const_cast<const char *>(CameraVector[3].c_str())), atof(const_cast<const char *>(CameraVector[4].c_str())), atof(const_cast<const char *>(CameraVector[5].c_str())));
        up = osg::Vec3d(atof(const_cast<const char *>(CameraVector[6].c_str())), atof(const_cast<const char *>(CameraVector[7].c_str())), atof(const_cast<const char *>(CameraVector[8].c_str())));
        //视点转换
        osg::Matrix m;
        m.makeLookAt(eye,center,up);
        viewer->setCameraManipulator(new osgGA::TrackballManipulator);
        viewer->getCameraManipulator()->setByInverseMatrix(m);

        //加载房屋等标记
        root->addChild(floodf->return_Signs());
        if(brLake!=NULL){
        root->addChild(brLake->Draw_Lake());
        }
        displayflood=0;
        connect(timer,SIGNAL(timeout()),this,SLOT(displayInfo()));
        timer->start(1*1000);

//        //下雨
//        root->addChild(fl->rainEffect());

//        //==控制洪水过程==
//        types=1;  //表示洪水
//        index_num=1;  //初始化，从第一个文件开始读取
//        speedInt=1;  //重置播放倍数，从1开始
//        vector<string> PlayVector;
//        PlayVector = pXmlDoc->readXmlFnD("Play");

//        startOutPath=PlayVector[0];   //NodePath+"/Disaster_Play";//"E:/datas/output/flood_jinshajiang";
//        QDir *dir=new QDir(startOutPath.c_str());  //洪水，选择使用文件夹时候使用
//        QStringList filter;
//        QList<QFileInfo> *fileInfo=new QList<QFileInfo>(dir->entryInfoList(filter));
//        fileNum=fileInfo->count()-2;  //文件个数，不知道什么原因要多了2个,因此这里需要减2
//        connect(timer,SIGNAL(timeout()),this,SLOT(Visualize()));
//        timer->start(0.0005);
    }
    else if(NodeType == "2"){


    }
    else if(NodeType == "3"){

    }
    //把所有节点设置为可用
     for(int i=0;i<BindingFiles.size();i++){
          model->item(i)->setEnabled(true);
       }

//    osg::Matrix m;
//    m.makeLookAt(eye,center,up);
//    viewer->setCameraManipulator(new osgGA::TrackballManipulator);
//    viewer->getCameraManipulator()->setByInverseMatrix(m);
}

//=====目录是单击获取视点====
void MainWindow::ClickTree(const QModelIndex & index){
    osg::Vec3d eye,center,up;
     float distance=2.93713e+030;
     viewer->getCamera()->getViewMatrixAsLookAt(eye,center,up,distance);
     std::cout<<eye._v[0]<<" "<<eye._v[1]<<" "<<eye._v[2]<<endl;
     std::cout<<center._v[0]<<" "<<center._v[1]<<" "<<center._v[2]<<endl;
     std::cout<<up._v[0]<<" "<<up._v[1]<<" "<<up._v[2]<<endl;
     std::cout<<distance<<endl<<endl;
}

//===菜单栏、工具栏参数设置、以及目录树
void MainWindow::createActions()
{
    //获取当前exe的文件夹路径
    myAppPath = QCoreApplication::applicationDirPath();
    //===文件
    QMenu *fileMenu = menuBar()->addMenu(tr("Files"));
    QToolBar *fileToolBar = ui->mainToolBar;

    //打开
    const QIcon openIcon = QIcon::fromTheme("document-open", QIcon(":/src/images/open.png"));
    QAction *openAct = new QAction(openIcon, tr("Open"), this);
    openAct->setShortcuts(QKeySequence::Open);
    openAct->setStatusTip(tr("Open file"));
    connect(openAct, &QAction::triggered, this, &MainWindow::open);
    fileMenu->addAction(openAct);
    fileToolBar->addAction(openAct);


    //加载场景数据
    const QIcon addIcon = QIcon::fromTheme("document-open", QIcon(":/src/images/addData.png"));
    QAction *addAct = new QAction(addIcon, tr("Load Scene"), this);
    addAct->setStatusTip(tr("Load scene .ive"));
    connect(addAct, &QAction::triggered, this, &MainWindow::addData);
    fileMenu->addAction(addAct);
    fileToolBar->addAction(addAct);
    fileMenu->addSeparator();  //分隔符

    //返回上一视图
        const QIcon preIcon = QIcon::fromTheme("document-open", QIcon(":/src/images/pre.png"));
        QAction *preAct = new QAction(preIcon, tr("previous"), this);
        preAct->setStatusTip(tr("previous view"));
        connect(preAct, &QAction::triggered, this, &MainWindow::preView);
        fileMenu->addAction(preAct);
        fileToolBar->addAction(preAct);
        //跳至下一视图
        const QIcon nextIcon = QIcon::fromTheme("document-open", QIcon(":/src/images/next.png"));
        QAction *nextAct = new QAction(nextIcon, tr("next"), this);
        nextAct->setStatusTip(tr("next view"));
        connect(nextAct, &QAction::triggered, this, &MainWindow::nextView);
        fileMenu->addAction(nextAct);
        fileToolBar->addAction(nextAct);
    fileMenu->addSeparator();  //分隔符


    //打开矢量数据
    QAction *addShp = fileMenu->addAction(tr("Load Shape"));
    addShp->setStatusTip(tr("Load shape data"));
    connect(addShp, &QAction::triggered, this, &MainWindow::OpenShapeFile);
    //清除数据
    QAction *delNode = fileMenu->addAction(tr("clear"));
    delNode->setStatusTip(tr("clear all the data"));
    connect(delNode, &QAction::triggered, this, &MainWindow::DeleteAllNode);

    //保存
    const QIcon saveIcon = QIcon::fromTheme("document-save", QIcon(":/src/images/save.png"));
    QAction *saveAct = new QAction(saveIcon, tr("Save"), this);
    saveAct->setShortcuts(QKeySequence::Save);
    saveAct->setStatusTip(tr(""));
    connect(saveAct, &QAction::triggered, this, &MainWindow::save);
    fileMenu->addAction(saveAct);
    fileToolBar->addAction(saveAct);
    //另存为
    QAction *saveAsAct = fileMenu->addAction(tr("Save as"));
    saveAsAct->setShortcuts(QKeySequence::SaveAs);
    saveAsAct->setStatusTip(tr(""));
    connect(saveAsAct, &QAction::triggered, this, &MainWindow::saveAs);
    fileMenu->addSeparator();  //分隔符
    //退出
    const QIcon exitIcon = QIcon::fromTheme("application-exit");
    QAction *exitAct = fileMenu->addAction(exitIcon, tr("exit"), qApp, &QApplication::closeAllWindows);
    exitAct->setShortcuts(QKeySequence::Quit);
    exitAct->setStatusTip(tr("quit the system"));



    //===演进控制
    QMenu *interactiveDisplay = menuBar()->addMenu(tr("control"));
    //开始演进
    const QIcon startIcon = QIcon::fromTheme("document-open", QIcon(":/src/images/start.png"));
    QAction *startAct = new QAction(startIcon, tr("start"), this);
    startAct->setStatusTip(tr(""));
    connect(startAct, &QAction::triggered, this, &MainWindow::startRoam);
    interactiveDisplay->addAction(startAct);
    fileToolBar->addAction(startAct);

    //暂停
    const QIcon pauseIcon = QIcon::fromTheme("document-open", QIcon(":/src/images/pause.png"));
    QAction *pauseAct = new QAction(pauseIcon, tr("suspend"), this);
    pauseAct->setStatusTip(tr(""));
    connect(pauseAct, &QAction::triggered, this, &MainWindow::pauseRoam);
    interactiveDisplay->addAction(pauseAct);
    fileToolBar->addAction(pauseAct);

    //继续
    const QIcon continueIcon = QIcon::fromTheme("document-open", QIcon(":/src/images/continue.png"));
    QAction *countinueAct = new QAction(continueIcon, tr("continuate"), this);
    countinueAct->setStatusTip(tr(""));
    connect(countinueAct, &QAction::triggered, this, &MainWindow::continueRoma);
    interactiveDisplay->addAction(countinueAct);
    fileToolBar->addAction(countinueAct);
//    QAction *countinueRoam = interactiveDisplay->addAction(tr("&继续演进"));
//    countinueRoam->setStatusTip(tr("&继续演进"));
//    connect(countinueRoam, &QAction::triggered, this, &MainWindow::continueRoma);
    //停止
    const QIcon stopIcon = QIcon::fromTheme("document-open", QIcon(":/src/images/stop.png"));
    QAction *stopAct = new QAction(stopIcon, tr("stop"), this);
    stopAct->setStatusTip(tr("打开已有文件"));
    connect(stopAct, &QAction::triggered, this, &MainWindow::stopRoam);
    interactiveDisplay->addAction(stopAct);
    fileToolBar->addAction(stopAct);
//    QAction *stopRoam = interactiveDisplay->addAction(tr("&停止演进"));
//    stopRoam->setStatusTip(tr("&停止演进"));
//    connect(stopRoam, &QAction::triggered, this, &MainWindow::stopRoam);

    interactiveDisplay->addSeparator();  // 添加分隔符
    //演进速度控制
    const QIcon speedIcon = QIcon::fromTheme("document-open", QIcon(":/src/images/speedUp.png"));
    QAction *speedAct = new QAction(speedIcon, tr("accelerate"), this);
    speedAct->setStatusTip(tr("打开已有文件"));
    connect(speedAct, &QAction::triggered, this, &MainWindow::speedControl);
    interactiveDisplay->addAction(speedAct);
    fileToolBar->addAction(speedAct);
//    QAction*speedControl=interactiveDisplay->addAction(tr("&快速演进"));
//    speedControl->setStatusTip(speedInt+"&倍速度演进播放");
//    connect(speedControl,&QAction::triggered,this,&MainWindow::speedControl);

    //重新开始
    const QIcon restartIcon = QIcon::fromTheme("document-open", QIcon(":/src/images/restart.png"));
    QAction *restartAct = new QAction(restartIcon, tr("restart"), this);
    restartAct->setStatusTip(tr("打开已有文件"));
    connect(restartAct, &QAction::triggered, this, &MainWindow::restartRoam);
    interactiveDisplay->addAction(restartAct);
    fileToolBar->addAction(restartAct);

\
    //===灾害模拟，灾害类型选择
    QMenu *diasterMenu = menuBar()->addMenu(tr("&Camera"));


    //获取相机参数
    QAction *GetCameraParameter = diasterMenu->addAction(tr("get camera para"));
//    GetCameraParameter->setStatusTip(tr("get current camera para"));
    connect(GetCameraParameter,&QAction::triggered,this,&MainWindow::getCameraParmeter);




//    //控制全溃半溃半溃状态
//    QMenu *floodmodel = menuBar()->addMenu(tr("&溃决状态"));
//    //全溃
//    QAction *allF = floodmodel->addAction(tr("全溃"));
//    connect(allF,&QAction::triggered,this,&MainWindow::FloodModelA);
//    QAction *halfF = floodmodel->addAction(tr("半溃"));
//    connect(halfF,&QAction::triggered,this,&MainWindow::FloodModelH);



    //===创建目录树===
    //定义场景树图标和model
    QMap<QString,QIcon> m_publicIconMap;//存放目录树图标
    m_publicIconMap[QStringLiteral("treeItem_Point")] =QIcon(QStringLiteral(":/src/images/Point.png"));
    model = new QStandardItemModel(treeView);
    model->setHorizontalHeaderLabels(QStringList()<<QStringLiteral("Flood Disaster"));

    //读取json中的文件获取一个json的object
    QJsonObject json_obj = readJSON(myAppPath+"/TreeMeta.json");

    qDebug()<<myAppPath+"/TreeMeta.json";
    //把json中的数组读出来
    QJsonArray meta = json_obj.value("test").toArray();

    //把数组中路径和名称读进list中
    for(int i=0;i<meta.count();i++){
        QJsonObject obj = meta.at(i).toObject();
        FileManage fm(obj.value("name").toString(),obj.value("path").toString(),obj.value("type").toString());
        BindingFiles.push_back(fm);
    }


    //根据名称属性创建目录树
    std::list<FileManage>::iterator itr;
    for(itr=BindingFiles.begin();itr!=BindingFiles.end();++itr){

        QStandardItem* itemPoint =new QStandardItem(m_publicIconMap[QStringLiteral("treeItem_Point")],QStringLiteral("%1").arg(itr->getName()));
        model->appendRow(itemPoint);
    }

    //创建右键菜单事件
        QAction *setFilePath = new QAction("设定数据路径",ui->treeView);
        ui->treeView->setContextMenuPolicy(Qt::CustomContextMenu);
        QObject::connect(ui->treeView,&QTreeView::customContextMenuRequested,[=]{
          QMenu menu;

          QPoint posAtViewport = ui->treeView->viewport()->mapFromGlobal(QCursor::pos());
          QModelIndex index = ui->treeView->indexAt(posAtViewport);
          if(index.isValid()){
          menu.addAction(setFilePath);
          }

          menu.exec(QCursor::pos());
        });


    //创建目录树双击事件
    treeView->setModel(model);
    treeView->setEditTriggers(0);
    connect(treeView,SIGNAL(doubleClicked(const QModelIndex)),this,SLOT(OnlineTreeViewDoubleClick(const QModelIndex)));
    //单击事件
    connect(ui->treeView,SIGNAL(clicked(const QModelIndex)),this,SLOT(ClickTree(const QModelIndex)));
    //绑定文件夹事件
    connect(setFilePath,SIGNAL(triggered()),this,SLOT(BindFilePath()));
}

//=====绑定路径=====
void MainWindow::BindFilePath(){
    QModelIndex curIndex = ui->treeView->currentIndex();
    QString t = curIndex.data().toString();
    ChooseFileDialog *cdg = new ChooseFileDialog;
    cdg->nodename = t;
    cdg->setWindowTitle(t+" 设置路径");
    cdg->setAttribute(Qt::WA_DeleteOnClose);//设置之后关闭窗口释放内存
    cdg->exec();
}

//===加载文件
void MainWindow::loadFile(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QFile::ReadOnly | QFile::Text)) {
        QMessageBox::warning(this, tr("Application"),
            tr("Cannot read file %1:\n%2.")
            .arg(QDir::toNativeSeparators(fileName), file.errorString()));
        return;
    }

    curFile = fileName;
    QString shownName = curFile;
    if (curFile.isEmpty())
    {
        shownName = "untitled.txt";
    }
    setWindowFilePath(shownName);
    statusBar()->showMessage(tr("open"), 2000);
}

//===保存,如果没有保存过，才调用这个函数
void MainWindow::saveFile(const QString &fileName)
{
    osg::Vec3d eye,center,up;
    viewer->getCamera()->getViewMatrixAsLookAt(eye,center,up);

    osg::ref_ptr<osg::Group> r = root;
    osg::ref_ptr<osg::Camera> cam = new osg::Camera;

    cam->setViewMatrixAsLookAt(eye,center,up);

    string campath = fileName.toStdString()+"_cam.osg";
    string filepath = fileName.toStdString()+".ive";

    cout<<"campath:"<<campath<<",  filepath:"<<filepath<<endl;
    osgDB::writeNodeFile(*cam.get(),campath);
    osgDB::writeNodeFile(*r.get(),filepath);
}

//===打开工程
void MainWindow::open()
{

    //打开文件
    QString fileName = QFileDialog::getOpenFileName(this);
    if (!fileName.isEmpty())
    {
        loadFile(fileName);

        statusBar()->showMessage(tr(fileName.toStdString().c_str()), 2000);  //状态栏显示文件路径
        osgDB::Options *a = new osgDB::Options(std::string("noTriStripPolygons"));
        loadNode = osgDB::readNodeFile(fileName.toStdString().c_str(),a); //加载节点
        if(loadNode!=NULL){
            //删除之前场景中所有的节点
         root->removeChild(0,root->getNumChildren());
//        loadNode->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);  //设置场景光线
        }
        else{
            return;
        }
        QFileInfo fi;
        fi = QFileInfo(fileName);
        root->addChild(loadNode.get());
        string campath = fi.absolutePath().toStdString()+"/"+fi.completeBaseName().toStdString()+"_cam.osg";
        std::cout<<campath.c_str()<<endl;
        osg::ref_ptr<osg::Node> cam = osgDB::readNodeFile(campath);

        if(cam!=NULL){
        osg::Vec3d eye,center,up;

        cam->asCamera()->getViewMatrixAsLookAt(eye,center,up);

        viewer->getCameraManipulator()->setByInverseMatrix(cam->asCamera()->getViewMatrix());
        }
    }else {
//        QMessageBox::information(NULL, "Warning", "请选择文件!", QMessageBox::Yes );
        return;
    }

}

//加载场景数据
void MainWindow::addData()
{


    //打开文件
//    QString fileName = QFileDialog::getOpenFileName(this);
    QString fileName = QFileDialog::getOpenFileName(this,tr("文件"),"",tr("(*.ive)"));  //使用过滤器
    if (!fileName.isEmpty())
    {
        loadFile(fileName);
    }

    statusBar()->showMessage(tr(fileName.toStdString().c_str()), 2000);  //状态栏显示文件路径
    osg::ref_ptr<osg::Node>addNode = osgDB::readNodeFile(fileName.toStdString().c_str()); //加载节点
    if(addNode!=NULL){

    //删除之前场景中所有的节点
//    root->removeChild(0,root->getNumChildren());
//    addNode->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);  //设置场景光线

    root->addChild(addNode.get());
    viewer->setCameraManipulator(new osgGA::TrackballManipulator);
    viewer->setSceneData(root);

    hLayout = ui->horizontalLayout_2;
    hLayout->addWidget(viewer);
    }
}

void MainWindow::preView()
{
    if(numViewers>1)
        {
            numViewers--;
            osg::Vec3d eye=eyePoints.at(numViewers-1);
            osg::Vec3d center=centerPoints.at(numViewers-1);
            osg::Vec3d up=upPoints.at(numViewers-1);
            //设置新的视角
            osg::Matrix m;
            m.makeLookAt(eye,center,up);
            viewer->getCameraManipulator()->setByInverseMatrix(m);
            cout<<eyePoints.size()<<",   "<<numViewers<<",   "<<eye._v[0]<<",  "<<eye._v[1]<<",  "<<eye._v[2]<<endl;
    }
}

void MainWindow::nextView()
{
    if(numViewers<eyePoints.size()-1)
        {
            numViewers++;

            osg::Vec3d eye=eyePoints.at(numViewers);
            osg::Vec3d center=centerPoints.at(numViewers);
            osg::Vec3d up=upPoints.at(numViewers);
            //设置新的视角
            osg::Matrix m;
            m.makeLookAt(eye,center,up);
            viewer->getCameraManipulator()->setByInverseMatrix(m);
            cout<<eyePoints.size()<<",   "<<numViewers<<",   "<<eye._v[0]<<",  "<<eye._v[1]<<",  "<<eye._v[2]<<endl;
        }
}

//===保存
void MainWindow::save()
{
    if (curFile.isEmpty())
    {
        saveAs();
    }else {
        saveFile(curFile);
    }
}

//===另存为
void MainWindow::saveAs()
{
    QFileDialog dialog(this);
    dialog.setWindowModality(Qt::WindowModal);
    dialog.setAcceptMode(QFileDialog::AcceptSave);

    QString fileName = QFileDialog::getSaveFileName(this);
    curFile=fileName;  //赋为全局，用于在保存中判断，若第一次保存则需要先另存为设置路径

    saveFile(fileName);  //调用保存方法
}


void MainWindow::getCameraParmeter()
{

    osg::Vec3d eye,center,up;
     float distance=2.93713e+030;
     viewer->getCamera()->getViewMatrixAsLookAt(eye,center,up,distance);
     std::cout<<eye._v[0]<<" "<<eye._v[1]<<" "<<eye._v[2]<<endl;
     std::cout<<center._v[0]<<" "<<center._v[1]<<" "<<center._v[2]<<endl;
     std::cout<<up._v[0]<<" "<<up._v[1]<<" "<<up._v[2]<<endl;
     std::cout<<distance<<endl<<endl;

     GetCameraPose *getCameraPosef=new GetCameraPose();
     connect(this,SIGNAL(Sendagrv(vector<double>)),getCameraPosef,SLOT(Getagrv(vector<double>)));   //主窗体传值给子窗体显示

     vector<double> pVectorParameters;
     pVectorParameters.push_back(eye._v[0]);
     pVectorParameters.push_back(eye._v[1]);
     pVectorParameters.push_back(eye._v[2]);
     pVectorParameters.push_back(center._v[0]);
     pVectorParameters.push_back(center._v[1]);
     pVectorParameters.push_back(center._v[2]);
     pVectorParameters.push_back(up._v[0]);
     pVectorParameters.push_back(up._v[1]);
     pVectorParameters.push_back(up._v[2]);
     emit Sendagrv(pVectorParameters);

//    getCameraPosef->setFixedSize(750,210);
    getCameraPosef->setWindowTitle("获取相机参数");
    getCameraPosef->show();

}

void MainWindow::FloodModelA(){
if(types==1){
//    std::string NodePath = return_ViewTree_Path(NOW_NODENAME ).toStdString();
    if(brLake!=NULL){
    brLake->init_Pos();
    }
    XMLDoc *pXmlDoc=new XMLDoc();
    vector<string> PlayVector;
    PlayVector = pXmlDoc->readXmlFnD("Play");
    startOutPath=PlayVector[0];
    index_num=1;
    flagRoam=true;
    speedInt=1;
//    startOutPath = NodePath+"/Disaster_Play";
    QDir *dir=new QDir(startOutPath.c_str());  //洪水，选择使用文件夹时候使用
    QStringList filter;
    QList<QFileInfo> *fileInfo=new QList<QFileInfo>(dir->entryInfoList(filter));
    fileNum=fileInfo->count()-2;  //文件个数，不知道什么原因要多了2个,因此这里需要减2
    delete pXmlDoc;
    delete dir;
    connect(timer,SIGNAL(timeout()),this,SLOT(Visualize()));  //重现开始演进时，需要重新建立连接
    timer->start(0.0005);
}

}

void MainWindow::FloodModelH(){

    if(types==1){
//       std::string NodePath = return_ViewTree_Path(NOW_NODENAME).toStdString();
        if(brLake!=NULL){
        brLake->init_Pos();
        }
        XMLDoc *pXmlDoc=new XMLDoc();
        vector<string> PlayVector;
        PlayVector = pXmlDoc->readXmlFnD("PlayH");
        startOutPath=PlayVector[0];
        index_num=1;
        flagRoam=true;
        speedInt=1;
//        startOutPath = NodePath+"/Disaster_PlayH";
        QDir *dir=new QDir(startOutPath.c_str());  //洪水，选择使用文件夹时候使用
        QStringList filter;
        QList<QFileInfo> *fileInfo=new QList<QFileInfo>(dir->entryInfoList(filter));
        fileNum=fileInfo->count()-2;  //文件个数，不知道什么原因要多了2个,因此这里需要减2
        delete dir;
        delete pXmlDoc;
        connect(timer,SIGNAL(timeout()),this,SLOT(Visualize()));  //重现开始演进时，需要重新建立连接
        timer->start(0.0005);
    }
}





int f_num=1;
//===将洪水结果进行可视化

//各种灾害开始演进
//bool flagdiag = true;  //为了防止弹出两个选择框，强行设置


void MainWindow::FloodVis(){

    osg::ref_ptr<osg::Node> node=new osg::Node;
//    node->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);  // 关闭光源
//    root->removeChild(1,root->getNumChildren());  //移除上一个节点,更新节点,应该是生成的灾害时刻节点
//    root->removeChild(2,root->getNumChildren());  //移除上一个节点,更新节点，应该是图例节点

    char fileName [2000];
    string filename_ive;
    ostringstream oss;
    ostringstream ossin;
    ostringstream ossmon;
    ostringstream ossHP;
    string inpath;
    string str2=".ive";
    int mul = 2;

        rootflood1->setName("floodM");
            rootflood1->removeChildren(0,rootflood1->getNumChildren());
            root->removeChild(rootflood1);
//            root->removeChild(5,root->getNumChildren());  //移除上一个节点,更新节点,应该是生成的灾害时刻节点
//            root->removeChild(6,root->getNumChildren());  //移除上一个节点,更新节点，应该是图例节点


        oss<<startOutPath2<<"/"<<f_num<<str2;  //自动选择文件夹时使用
        filename_ive=oss.str();
        strcpy(fileName,filename_ive.c_str());  //将string转为char[]

        //读取洪水txt文件，并显示
        ossin<<startOutPath2<<"/"<<f_num<<".txt";
        inpath = ossin.str();
        floodf->input_from_TXT(inpath);
        shallowColor=floodf->shallow;
        deepColor = floodf->deep;
        //读取监测站json文件 更新监测站数据
        if(!mr->AllMonitor->empty()||f_num==1){
        ossmon<<startOutPath2<<"/"<<f_num<<".json";
        mr->Read_from_Json(ossmon.str());
        }
        //根据时间改变堰塞湖的高度
        if(brLake!=NULL){
        brLake->dpos = osg::Vec3(0,0,(brLake->Lake_H/fileNum)*4*index_num);
        brLake->change_Pos();
        }
        //读取节点
        node=osgDB::readNodeFile(fileName);

        osg::Depth* dep = new osg::Depth;     //case中有定义，必须加{}，不然直接会跳到default
        dep->setFunction(osg::Depth::Function::ALWAYS);
        node->getOrCreateStateSet()->setAttribute(dep, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        node->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        // 设置渲染系数，哪个模型要显示在前面，就调大该模型的渲染系数
        node->getOrCreateStateSet()->setRenderBinDetails(5, "RenderBin");


        rootflood1->addChild(node.get());




        root->addChild(rootflood1);
//        root->addChild(floodf->CreateHUD()); //添加洪水信息
//        root->addChild(floodf->CreateSD());
//        root->addChild(ff->createLegend(shallowColor,deepColor));  //添加图例
        if(!mr->AllMonitor->empty()||f_num==1){
        root->addChild(mr->return_M_Info()); //添加监测站信息
        }
        if(brLake!=NULL){
        root->addChild(brLake->Draw_Lake());//添加堰塞湖
        }
//        root->addChild(landNode.get()); //滑坡灾害链时添加************************
        if(flagRoam){
            f_num+=2*speedInt;  //这里控制灾害演进的倍数
        }else{
            f_num=f_num;
        }

        if(!mr->AllMonitor->empty()||f_num==1){
            mul=3;
        }



        if((f_num)*mul>fileNum2){  //判断是否超过文件夹中预存文件个数 ,这里是结束演进后要不要停留在最后一个时刻 这里index_num乘以了3是因为文件中加入了洪水的信息和监测站，数量多出了3倍

            disconnect(timerM,SIGNAL(timeout()),this,SLOT(FloodVis()));  //断开信号槽连接
            disconnect(timer,SIGNAL(timeout()),this,SLOT(Visualize()));
            connect(timer,SIGNAL(timeout()),this,SLOT(displayInfo()));
            timer->start(1*1000);
            mr->AllMonitor = new list<PointM>;



}

}


//可视化1
void MainWindow::Visualize()
{
    osg::ref_ptr<osg::Node> node=new osg::Node;
//    node->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);  // 关闭光源
//    root->removeChild(1,root->getNumChildren());  //移除上一个节点,更新节点,应该是生成的灾害时刻节点
//    root->removeChild(2,root->getNumChildren());  //移除上一个节点,更新节点，应该是图例节点

    char fileName [2000];
    string filename_ive;
    ostringstream oss;
    ostringstream ossin;
    ostringstream ossmon;
    ostringstream ossHP;
    string inpath;
    string str1;
    string str2=".ive";
    int mul = 2;
    switch (types){
    case 1: { //洪水

        rootflood->setName("floodAni");
            rootflood->removeChildren(0,rootflood->getNumChildren());
            root->removeChild(rootflood);
//            root->removeChild(5,root->getNumChildren());  //移除上一个节点,更新节点,应该是生成的灾害时刻节点
//            root->removeChild(6,root->getNumChildren());  //移除上一个节点,更新节点，应该是图例节点

        oss<<startOutPath<<"/"<<index_num<<str2;  //自动选择文件夹时使用
        filename_ive=oss.str();
        strcpy(fileName,filename_ive.c_str());  //将string转为char[]


        //读取洪水txt文件，并显示
        ossin<<startOutPath<<"/"<<index_num<<".txt";
        inpath = ossin.str();
        floodf->input_from_TXT(inpath);
        shallowColor=floodf->shallow;
        deepColor = floodf->deep;
        //读取监测站json文件 更新监测站数据
        if(!mr->AllMonitor->empty()||index_num==1){
        ossmon<<startOutPath<<"/"<<index_num<<".json";
        mr->Read_from_Json(ossmon.str());
        }
        //根据时间改变堰塞湖的高度
        if(brLake!=NULL){
        brLake->dpos = osg::Vec3(0,0,(brLake->Lake_H/fileNum)*4*index_num);
        brLake->change_Pos();
        }
        //读取节点
        node=osgDB::readNodeFile(fileName);

        osg::Depth* dep = new osg::Depth;     //case中有定义，必须加{}，不然直接会跳到default
        dep->setFunction(osg::Depth::Function::ALWAYS);
        node->getOrCreateStateSet()->setAttribute(dep, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        node->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        // 设置渲染系数，哪个模型要显示在前面，就调大该模型的渲染系数
        node->getOrCreateStateSet()->setRenderBinDetails(5, "RenderBin");


        rootflood->addChild(node.get());
        root->addChild(rootflood);
//        root->addChild(floodf->CreateHUD()); //添加洪水信息
//        root->addChild(floodf->CreateSD());
//        root->addChild(ff->createLegend(shallowColor,deepColor));  //添加图例
        if(!mr->AllMonitor->empty()||index_num==1){
        root->addChild(mr->return_M_Info()); //添加监测站信息
        }
        if(brLake!=NULL){
        root->addChild(brLake->Draw_Lake());//添加堰塞湖
        }

        if(flagRoam){
            index_num+=5*speedInt;  //这里控制灾害演进的倍数
        }else{
            index_num=index_num;
        }       

        if(!mr->AllMonitor->empty()||index_num==1){
            mul=3;
        }

        SearchNode* snd = new SearchNode();
        int ix = snd->return_Nodeindex(root,"mandi");

        if(index_num>1640&&ix==-1){

            //调整视角
            osg::Vec3d eye,center,up;
            eye =osg::Vec3d(972047.50,3853280.42,3260.25);
            center =osg::Vec3d(-3.34517e+29,2.27184e+30,-1.83128e+30);
            up =osg::Vec3d(-0.09,0.62,0.78);

            osg::Matrix m;
            m.makeLookAt(eye,center,up);
            viewer->getCameraManipulator()->setByInverseMatrix(m);

            //围堤决口
            osg::ref_ptr<osg::Node> mandiT = fl->showText("embankment burst",osg::Vec3(970583,3.85675e+6,301.063),80.0);//embankment burst
            mandiT->setName("mandi");
            RenderClass *rc = new RenderClass;
            rc->setNodeRender(*mandiT,100);
            root->addChild(mandiT.get());

            ix = snd->return_Nodeindex(root,"floodtext");
            root->removeChild(ix);

            osg::ref_ptr<osg::Node> hudT = fl->CreateInfoHUD("Oct. 8 to Oct. 9"); //10月8日 秋收季节 October 8 Autumn => harvest season
            hudT->setName("floodtext");
            root->addChild(hudT.get());


            startOutPath2="E://experiment//dali//flood//mandi//mout";
//            startOutPath2="E://experiment//out1";
            QDir *dir=new QDir(startOutPath2.c_str());  //洪水，选择使用文件夹时候使用
            QStringList filter;
            QList<QFileInfo> *fileInfo=new QList<QFileInfo>(dir->entryInfoList(filter));
            fileNum2=fileInfo->count()-2;  //文件个数，不知道什么原因要多了2个,因此这里需要减2
            connect(timerM,SIGNAL(timeout()),this,SLOT(FloodVis()));
            timerM->start(1);

        }

        if((index_num)*mul>fileNum){  //判断是否超过文件夹中预存文件个数 ,这里是结束演进后要不要停留在最后一个时刻 这里index_num乘以了3是因为文件中加入了洪水的信息和监测站，数量多出了3倍

            disconnect(timer,SIGNAL(timeout()),this,SLOT(Visualize()));  //断开信号槽连接

            mr->AllMonitor = new list<PointM>;

            //把所有节点设置为可用
             for(int i=0;i<BindingFiles.size();i++){
                  model->item(i)->setEnabled(true);
               }

//            flagdiag = true;
            //是否保留灾害最后状态
//            root->removeChild(1,root->getNumChildren());  //移除最后一个灾害节点
//            root->removeChild(2,root->getNumChildren());  //移除图例节点
        }
        break;

    }
    default:
        break;
    }
}


int index=1;
int count1 = 0;
int count2 = 0;
long Temp1 = 0;
double Total_Time2 = 0.0;          //迭代总的时间


int times = 1;



//======水淹分析===========
void MainWindow::FloodingAnalysis()
{
    if(Alutte<13)
    {
        Alutte +=1.0;
        rootflood->removeChild(0,rootflood->getNumChildren());   //删除第一个矩形，使得每次只显示一个图层
        pos_SY=pos_SY+osg::Vec3(0.0f,0.0f,3.0f);  //每次抬高3m
//        pos_SY=pos_SY+osg::Vec3(0.0f,10.0f,3.0f);  //每次抬高3m,并向右10个单位

        cout<<"ZZ: "<<pos_SY._v[2]<<endl;

        //无渐变色
//        width_SY=osg::Vec3(1000.0f,0.0f,0.0f);
//        height_SY=osg::Vec3(0.0f,1000.0f,0.0f);
//        osg::ref_ptr<osg::Vec4Array>colorArray=new osg::Vec4Array;
//        colorArray->push_back(osg::Vec4(0.44f,0.51f,0.48f,1.0)); //设置颜色
//        osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
//        geometry=osg::createTexturedQuadGeometry(pos_SY,width_SY,height_SY);
//        geometry->setColorArray(colorArray.get());
//        geometry->setColorBinding(osg::Geometry::BIND_OVERALL);


        //渐变色
//        width_SY=osg::Vec3(1000.0f,0.0f,0.0f);
//        height_SY=osg::Vec3(0.0f,1000.0f,0.0f);
        width_SY=osg::Vec3(2000.0f,0.0f,0.0f);
        height_SY=osg::Vec3(0.0f,2000.0f,0.0f);
        osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
        //定义顶点
        osg::ref_ptr<osg::Vec3Array> vertexArray = new osg::Vec3Array;
        geometry->setVertexArray(vertexArray);
        vertexArray->push_back(osg::Vec3(pos_SY.x(), pos_SY.y(), pos_SY.z()));
        vertexArray->push_back(osg::Vec3(pos_SY.x()+width_SY.x(), pos_SY.y(), pos_SY.z()));
        vertexArray->push_back(osg::Vec3(pos_SY.x()+width_SY.x(), pos_SY.y()+height_SY.y(), pos_SY.z()));
        vertexArray->push_back(osg::Vec3(pos_SY.x(), pos_SY.y()+height_SY.y(), pos_SY.z()));
        //定义颜色数组
        osg::ref_ptr<osg::Vec4Array> colorArray = new osg::Vec4Array();
        geometry->setColorArray(colorArray);
        geometry->setColorBinding(osg::Geometry::BIND_PER_VERTEX);
        colorArray->push_back(osg::Vec4(99.0/255.0f,119.0/255.0f,115.0/255.0f,0.98));
        colorArray->push_back(osg::Vec4(122.0/255.0f,138.0/255.0f,128.0/255.0f,0.98));
        colorArray->push_back(osg::Vec4(157.0/255.0f,161.0/255.0f,159.0/255.0f,0.85));
        colorArray->push_back(osg::Vec4(158.0/255.0f,151.0/255.0f,154.0/255.0f,0.9));
        //定义法线
//        osg::ref_ptr<osg::Vec3Array> normalArray = new osg::Vec3Array();
//        geometry->setNormalArray(normalArray);
//        geometry->setNormalBinding(osg::Geometry::BIND_OVERALL);
//        normalArray->push_back(osg::Vec3(0.f, 0.f, 1.0f));
        //设置顶点关联方式
        //PrimitiveSet类，这个类松散地封装了OpenGL的绘图基元，
        //包括点（POINTS），线（LINES），多段线（LINE_STRIP），封闭线（LINE_LOOP），四边形（QUADS），多边形（POLYGON）等。
        geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS, 0, 4));
        //开启融合操作
        geometry ->getOrCreateStateSet()->setMode(GL_BLEND, osg::StateAttribute::ON);
        //设置渲染模式
        geometry ->getOrCreateStateSet()->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
        //关闭光照，这样任意面，都可以看到半透明效果。
        geometry ->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
        geometry->getOrCreateStateSet()->setRenderBinDetails(-3,"RenderBin");
        geometry->setDataVariance(osg::Object::DYNAMIC);
        osg::ref_ptr<osg::Geode> geode=new osg::Geode;
        geode->addDrawable(geometry);
        rootflood->addChild(geode);
        root->addChild(rootflood);

//        if(Alutte==1.0){
        if(Alutte==10.0){
            osg::ref_ptr<osg::Geode> geotext=new osg::Geode;
            osg::ref_ptr<osgText::Font> font_1 = osgText::readFontFile("fonts/msyh.ttc");
            osg::ref_ptr<osgText::Text> text_1 = new osgText::Text;
            text_1->setFont(font_1);
//            text_1->setText(L"堰塞湖\n总库容: 1.83亿立方米");

            XMLDoc *pXmlDoc=new XMLDoc();
            vector<string> pVectorBarrierLake=pXmlDoc->readXml("BarrierLake");
            std::wstring str=string_To_wstring(pVectorBarrierLake[1]);
            text_1->setText(str.c_str());

            text_1->setCharacterSize(100);
            text_1->setAutoRotateToScreen(true);
            text_1->setBackdropType(osgText::Text::OUTLINE);//文件描边
            text_1->setBackdropColor(osg::Vec4(1.0, 1.0, 1.0, 1.0));//文字描边的颜色
//            text_1->setPosition(osg::Vec3(pos_CY.x(), pos_CY.y(), pos_CY.z()));

            text_1->setPosition(osg::Vec3(pos_SY.x()+500.0, pos_SY.y()+500.0, pos_CY.z()));

            text_1->setColor(osg::Vec4(0.0, 0.0, 1.0, 1.0));//字体颜色
            text_1->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);  //设置场景光线,关闭光源
            geotext->addDrawable(text_1.get());
            rootflood1->addChild(geotext);
            root->addChild(rootflood1);
        }

//        cout<<"Num: "<<root->getNumChildren()<<endl;
//        cout<<"Alutte: "<<Alutte<<endl;
    }else{
        Alutte = 0.0;
        disconnect(_timer,SIGNAL(timeout()),this,SLOT(FloodingAnalysis()));

        rootflood1->removeChild(0,rootflood1->getNumChildren());  //移除堰塞湖文字显示

//        //场景漫游
//        DamageDescription *damagd=new DamageDescription();
//        osg::Vec3 pos1=osg::Vec3(474253,3.43918e+006,8264.11);
//        osg::Vec3 pos2=osg::Vec3(473513,3.4363e+006,5717.94);
//        osgGA::AnimationPathManipulator* animationPathManipulator1 = new osgGA::AnimationPathManipulator;
//        animationPathManipulator1->setAnimationPath(damagd->createCameraPath(pos1,pos2));
//        viewer->setCameraManipulator(animationPathManipulator1);


        //灾情展示
        osg::Vec3d eye,center,up;
//        eye = osg::Vec3d(473513,3.4363e+006,5717.94);
//        center = osg::Vec3d(-1.08143e+030,1.81834e+030,-2.03737e+030);
//        up = osg::Vec3d(-0.298779,0.627715,0.718822);
        XMLDoc *pXmlDoc=new XMLDoc();
        vector<string> pVectorCamera2=pXmlDoc->readXml("Camera2");
        eye = osg::Vec3d(atof(const_cast<const char *>(pVectorCamera2[0].c_str())), atof(const_cast<const char *>(pVectorCamera2[1].c_str())), atof(const_cast<const char *>(pVectorCamera2[2].c_str())));
        center = osg::Vec3d(atof(const_cast<const char *>(pVectorCamera2[3].c_str())), atof(const_cast<const char *>(pVectorCamera2[4].c_str())), atof(const_cast<const char *>(pVectorCamera2[5].c_str())));
        up = osg::Vec3d(atof(const_cast<const char *>(pVectorCamera2[6].c_str())), atof(const_cast<const char *>(pVectorCamera2[7].c_str())), atof(const_cast<const char *>(pVectorCamera2[8].c_str())));
        osg::Matrix m;
        m.makeLookAt(eye,center,up);
        viewer->getCameraManipulator()->setByInverseMatrix(m);

        connect(timer,SIGNAL(timeout()),this,SLOT(displayLandslideInfo()));
        timer->start(1*1000);
    }

}

//期望为E方差为V的高斯分布随机值,滑坡
//作用：加高程的时候产生一个小的波动
double MainWindow::gaussRand(double E, double V)
{
    /*
     * C++中生成[X,Y]之间的随机数，
     * 公式：rand%（Y-X+1）+X
     * 例生成[0,10]之间的随机数，rand()%11
     *
     * rand()返回 0~RAND_MAX 之间的随机数
     * RAND_MAX=32767
     * (double)rand() / RAND_MAX  //得到一个 0~1.0 之间的随机浮点数
    */
    static double V1, V2, S;
    static int phase = 0;
    double X;

    if (phase == 0) {
        do {
//            double U1 = (double)rand() / RAND_MAX;  //原有的随机数生成
//            double U2 = (double)rand() / RAND_MAX;
            double U1 = rand()%10 /10.0+0.8;
            double U2 = rand()%10 /10.0+0.8;

            V1 = 2 * U1 - 1;
            V2 = 2 * U2 - 1;
            S = V1 * V1 + V2 * V2;
        } while (S >= 1 || S == 0);

        X = V1 * sqrt(-2 * log(S) / S);
    }
    else
        X = V2 * sqrt(-2 * log(S) / S);

    phase = 1 - phase;

    return X * V + E;
}

//string2wstring
wstring MainWindow::string_To_wstring(string pStr)
{
    //不能识别转义字符(但是将xml中的换行符修改为&#x000A;即可识别换行符)
    unsigned len = pStr.size() * 2;// 预留字节数
    setlocale(LC_CTYPE, "");     //必须调用此函数
    wchar_t *p = new wchar_t[len];// 申请一段内存存放转换后的字符串
    mbstowcs(p,pStr.c_str(),len);// 转换
    std::wstring str1(p);
    delete[] p;// 释放申请的内存
    return str1;
}

// float xt=20.0;
 osg::ref_ptr<osg::MatrixTransform> mt=new osg::MatrixTransform();
//开始演进
void MainWindow::startRoam()
{
    flagRoam=true;
}

//暂停演进
void MainWindow::pauseRoam()
{
    if(types!=1&&types!=2&&types!=3)
    {
        return;
    }
    if(types==3)//如果是滑坡的话，暂停需要停止timer的运行
    {
//        if(landslide_pro==1){
//        disconnect(timer,SIGNAL(timeout()),this,SLOT(displayInfo()));
//        displayIndex = -1;
//        }
//        if(landslide_pro==2){
//            disconnect(timer,SIGNAL(timeout()),this,SLOT(displayLandslideInfo()));
//            displayIndex2 = -1;
//        }
        timer->stop();
    }

    else{
        flagRoam=false;
    }
}

//继续演进
void MainWindow::continueRoma()
{
    if(types!=1&&types!=2&&types!=3)
    {
        return;
    }
    if(types==3){
//        if(landslide_pro==1){
//        displayIndex = cur_disNum-1;
//        connect(timer, SIGNAL(timeout()), this, SLOT(displayInfo()));
//        timer->start(50);
//        }
//        if(landslide_pro==2){
//            displayIndex2 = cur_disNum-1;
//            connect(timer, SIGNAL(timeout()), this, SLOT(displayLandslideInfo()));
//            timer->start(100);
//        }
        if(displayIndex!=0){
        timer->start(100);
        }
        if(displayIndex2!=0){
            timer->start(1000);
        }
        if(displayIndex3!=0){
            timer->start(200);
        }
    }

    else{
        flagRoam=true;
    }

}

//停止演进
void MainWindow::stopRoam()
{
    if(types!=1&&types!=2&&types!=3)
    {
        return;
    }
    index_num=1;
    flagRoam=false;
    root->removeChild(1,root->getNumChildren());
}

//重新开始
void MainWindow::restartRoam()
{
    if(types!=1&&types!=2&&types!=3)
    {
        return;
    }
    if(types==3&&landslideOutPath!=""){   //因为滑坡保留了前一时刻的节点，所以重新开始时要先移除
        disconnect(timer,SIGNAL(timeout()),this,SLOT(displayInfo()));
        disconnect(timer,SIGNAL(timeout()),this,SLOT(displayLandslideInfo()));
        disconnect(timer,SIGNAL(timeout()),this,SLOT(afterLandslide()));
        root->removeChild(1,root->getNumChildren());  //移除上一个节点,更新节点,应该是生成的灾害时刻节点
//        root->removeChild(2,root->getNumChildren());  //移除上一个节点,更新节点，应该是图例节点
        landslide_pro =1;
        displayIndex=0;
        displayIndex2=0;
        displayIndex3=0;
        timer->stop();
        timer = new QTimer;
        connect(timer, SIGNAL(timeout()), this, SLOT(displayInfo()));
        timer->start(50);
        return;
    }
    if(types==1){
        //堰塞湖需要重新初始化位置
        if(brLake!=NULL){
        brLake->init_Pos();
        }
    }
    index_num=1;
    flagRoam=true;
    speedInt=1;  //将演进速度重置为1

    //只有在开始演进的时候才能使用
    connect(timer,SIGNAL(timeout()),this,SLOT(Visualize()));  //重现开始演进时，需要重新建立连接
    if(types==2){
        timer->start(60);
        return;
    }
    timer->start(0.0005);
}

//用于快进控制
void MainWindow::speedControl()
{
    if(types!=1&&types!=2&&types!=3)
    {
        return;
    }
    //这里只设置了三倍加速，达到三倍加速时，又将加速倍数设置为1
    if(speedInt<=4)
        ++speedInt;
    else
        speedInt=1;
}



void MainWindow::OpenShapeFile()
{

    ReadshpDialog* rsd = new ReadshpDialog();
    connect(rsd,SIGNAL(sendGroup(shapeFormat*)),this,SLOT(receiveGroup(shapeFormat*)));
    rsd->show();
//     rsd->read_shp("E:/swjt/danba/shp/Road/normalroad.shp");
//     osg::ref_ptr<osg::Group> node1 = rsd->draw_SHP();
//     root->addChild(node1.get());
}

void MainWindow::DeleteAllNode()
{
    root->removeChildren(0,root->getNumChildren());
}

void MainWindow::receiveGroup(shapeFormat* sft){

    ReadshpDialog *rdg = new ReadshpDialog;
    rdg->color=sft->color;
    rdg->txcolor=sft->txcolor;
    rdg->txsize = sft->txsize;
    rdg->read_shp(sft->shpPath.c_str());
    root->addChild(rdg->draw_SHP());
//    shpNodes->addChild(rdg->draw_SHP());
    delete rdg;
    delete sft;

}



void MainWindow::closeEvent(QCloseEvent *event){
    if( QMessageBox::question(this,
                                 tr("Quit"),
                                 tr("是否关闭整个程序?"),
                                  QMessageBox::Yes, QMessageBox::No )
                       == QMessageBox::Yes){
            event->accept();//不会将事件传递给组件的父组件

            qApp->quit();
        }
        else
          event->ignore();

}



void MainWindow::showCoordinate()
{
    if(coord.size()!=0){
    double x = coord[0];
    double y = coord[1];
    double z = coord[2];
    QString str = "( X:" + QString::number(x) + ", Y:" + QString::number(y) + ", Z:"+QString::number(z)+")";
    QPalette pal;
    pal.setColor(QPalette::WindowText,Qt::white);
    m_statusLabel->setPalette(pal);

    m_statusLabel->setText(str);

    }
}



void MainWindow::displayInfo()
{
    displayflood++;
    if(displayflood==0){
        disconnect(timer,SIGNAL(timeout()),this,SLOT(displayInfo()));
        return;
    }
    else if(displayflood==1){
        //下雨
        osg::ref_ptr<osg::Node> rain = fl->rainEffect();
        rain->setName("Rain");
       root->addChild(rain.get());
       //加入文字
       osg::ref_ptr<osg::Node> hudT = fl->CreateInfoHUD("Heavy rainfall in Dali since August 30");//自8月30号以来大荔县赵渡镇大量降雨
       hudT->setName("raintext");
       root->addChild(hudT.get());
       timer->start(5*1000);

    }

    else if(displayflood==2){
        disconnect(timer,SIGNAL(timeout()),this,SLOT(displayInfo()));

        cameraAni();

        SearchNode* snd = new SearchNode();
        int ix = snd->return_Nodeindex(root,"Rain");
        root->removeChild(ix);
        ix = snd->return_Nodeindex(root,"raintext");
        root->removeChild(ix);

        osg::ref_ptr<osg::Node> hudT = fl->CreateInfoHUD("The water level in the upper reaches of the luo River\n surged and the water flow increased"); //洛河上游水位激增，水流量加大

        hudT->setName("floodtext");
        root->addChild(hudT.get());

            //==控制洪水过程==
        XMLDoc *pXmlDoc=new XMLDoc();
        types=1;  //表示洪水
            index_num=1;  //初始化，从第一个文件开始读取
            speedInt=1;  //重置播放倍数，从1开始
            vector<string> PlayVector;
            PlayVector = pXmlDoc->readXmlFnD("Play");

            startOutPath=PlayVector[0];   //NodePath+"/Disaster_Play";//"E:/datas/output/flood_jinshajiang";
            QDir *dir=new QDir(startOutPath.c_str());  //洪水，选择使用文件夹时候使用
            QStringList filter;
            QList<QFileInfo> *fileInfo=new QList<QFileInfo>(dir->entryInfoList(filter));
            fileNum=fileInfo->count()-2;  //文件个数，不知道什么原因要多了2个,因此这里需要减2
            connect(timer,SIGNAL(timeout()),this,SLOT(Visualize()));
            timer->start(1);
    }

    else if(displayflood==3){

        //受灾房屋约757户

//        ReadshpDialog *rdg = new ReadshpDialog;
        osg::ref_ptr<osg::Group> group = new osg::Group;
        std::string hp ="E:/experiment/dali/shape/3d/maskbuilding.shp";
        DamageDescription *dd= new DamageDescription();
        if(hp!=""){
                    list<list<Point3D>> list2 = dd->gdal_read_polygonshp(hp.c_str());
                    list<Point3D> plist;
                    std::list<std::list<Point3D>>::iterator it2;

                 //设置颜色
                 osg::ref_ptr<osg::Vec4Array> housecolors = new osg::Vec4Array;
                 //添加数据
                 housecolors->push_back(osg::Vec4(1.0, 0.0, 0.0, 1.0));
                 for ( it2=list2.begin() ; it2 != list2.end(); it2++ )
                 {
                     plist=*it2;
                     osg::ref_ptr<osg::Geode> building1_prjnode=dd->Drawsamplehouse(plist,housecolors);
                     //关闭光源(必须添加，不然会影响加载的其他shp，导致光线变黑)
                     building1_prjnode->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源
                   RenderClass *rc = new RenderClass;
                   rc->setNodeRender(*building1_prjnode,7.0f);

                     group->addChild(building1_prjnode.get());
                 }

        }

        root->addChild(group.get());

    SearchNode* snd = new SearchNode();
        int ix = snd->return_Nodeindex(root,"floodtext");
        root->removeChild(ix);
        ix = snd->return_Nodeindex(root,"mandi");
        root->removeChild(ix);

//        osg::Vec3 pos1(971731.0f,3.85624e+6,306.0f);
//        osg::ref_ptr<osg::Node> label_line = lf->CreateInfoPos_withline(2,pos1);
//        label_line->setName("Riverlabel");
//        root->addChild(label_line.get());
        osg::ref_ptr<osg::Node> hudT = fl->CreateInfoHUD("About 757 houses affected"); //受灾房屋约有757栋
        hudT->setName("House");
        root->addChild(hudT.get());

        twinkindex = root->getNumChildren()-2;
        twinktimer = new QTimer();
        twinkNum =1;
        connect(twinktimer,SIGNAL(timeout()),this,SLOT(Twink()));
        twinktimer->start(100);


}

else if(displayflood==5){
        //损毁农田49.1万亩
        SearchNode* snd = new SearchNode();
//            int ix = snd->return_Nodeindex(root,"House");
//            root->removeChild(ix);
            int ix = snd->return_Nodeindex(root,"school");
            root->removeChild(ix);

        osg::ref_ptr<osg::Node> hudT = fl->CreateInfoHUD("About 327.3 km^2 of farmland was destroyed"); //损毁农田约49.1万亩，包含大量玉米、花生、萝卜等农作物
        hudT->setName("framland");

        std::string opath = "E://experiment//dali//shape//3d//farmland.shp";
        ReadshpDialog *rdg = new ReadshpDialog;
        rdg->color = QColor(43,255,128);
        rdg->renderrank = 6.0f;
        rdg->read_shp(opath.c_str());

        root->addChild(rdg->draw_SHP());
        root->addChild(hudT.get());

        twinkindex = root->getNumChildren()-2;
        twinktimer = new QTimer();
        twinkNum = 1;
        connect(twinktimer,SIGNAL(timeout()),this,SLOT(Twink()));
        twinktimer->start(100);

}
    else if(displayflood==4){
        //学校
        SearchNode* snd = new SearchNode();
        int ix = snd->return_Nodeindex(root,"House");
        root->removeChild(ix);
//        int ix = snd->return_Nodeindex(root,"framland");
//        root->removeChild(ix);
        osg::ref_ptr<osg::Node> hudT = fl->CreateInfoHUD("Several schools affected by flooding, classes delayed");//多所学校受洪水影响，延迟上课
        hudT->setName("school");
        std::string opath = "E://experiment//dali//shape//3d//Sname3.shp";
        ReadshpDialog *rdg = new ReadshpDialog;
        rdg->txcolor = QColor(255,255,255);
        rdg->txsize = 35;
        rdg->read_shp(opath.c_str());
        root->addChild(rdg->draw_text(1));
        root->addChild(hudT.get());

        osg::ref_ptr<osg::Group> group = new osg::Group;
        std::string hp ="E:/experiment/dali/shape/3d/SclF.shp";
        DamageDescription *dd= new DamageDescription();
        if(hp!=""){
                    list<list<Point3D>> list2 = dd->gdal_read_polygonshp(hp.c_str());
                    list<Point3D> plist;
                    std::list<std::list<Point3D>>::iterator it2;

                 //设置颜色
                 osg::ref_ptr<osg::Vec4Array> housecolors = new osg::Vec4Array;
                 //添加数据
                 housecolors->push_back(osg::Vec4((240.0/255.0),(255.0/255.0),(101.0/255.0), 1.0));
                 for ( it2=list2.begin() ; it2 != list2.end(); it2++ )
                 {
                     plist=*it2;
                     osg::ref_ptr<osg::Geode> building1_prjnode=dd->Drawsamplehouse(plist,housecolors);
                     //关闭光源(必须添加，不然会影响加载的其他shp，导致光线变黑)
                     building1_prjnode->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源
                   RenderClass *rc = new RenderClass;
                   rc->setNodeRender(*building1_prjnode,7.0f);

                     group->addChild(building1_prjnode.get());
                 }

        }
        root->addChild(group.get());

        twinkindex = root->getNumChildren()-3;
        twinktimer = new QTimer();
        twinkNum = 1;
        connect(twinktimer,SIGNAL(timeout()),this,SLOT(Twink()));
        twinktimer->start(100);

    }

}

void MainWindow::Twink(){
    timer->stop();
    int ix = twinkindex;
    if(twinkNum%2==0){
     root->getChild(ix)->setNodeMask(false);
    }
    else{
        root->getChild(ix)->setNodeMask(true);
    }
    if(twinkNum==11){
        timer->start(2000);
        disconnect(twinktimer,SIGNAL(timeout()),this,SLOT(Twink()));
        twinkNum =1;
    }
    twinkNum++;

}


osg::ref_ptr<osg::AnimationPath> MainWindow::cameraAni(){

       osgGA::AnimationPathManipulator *animationPathMp = new osgGA::AnimationPathManipulator();
       //给动画漫游器添加关键帧
       osg::AnimationPath* _animationPath = new osg::AnimationPath;

       //当出于模型右边，既x方向20处，为了看见模型
       //要使相机沿着Y轴顺时针旋转90度
//       osg::Quat q1(osg::DegreesToRadians(90.0), osg::Y_AXIS);
//       osg::Quat q2(osg::DegreesToRadians(90.0), osg::X_AXIS);
//       q1 *= q2;

//       osg::Quat q3(osg::DegreesToRadians(-90.0), osg::X_AXIS);
//       osg::Quat q4(osg::DegreesToRadians(180.0), osg::Y_AXIS);
//       q3 *= q4;

       osg::Quat q5(osg::DegreesToRadians(-90.0), osg::Z_AXIS);

       _animationPath->insert(0.0, osg::AnimationPath::ControlPoint(osg::Vec3d(969186.73,3853987.74,3132.11)));
       _animationPath->insert(4.0, osg::AnimationPath::ControlPoint(osg::Vec3d(971418.85,3856265.37,2965.80)));
       //设置路径是回摆的
       _animationPath->setLoopMode(osg::AnimationPath::SWING);
       animationPathMp->setAnimationPath(_animationPath);
       viewer->setCameraManipulator(animationPathMp);
       return NULL;

}



