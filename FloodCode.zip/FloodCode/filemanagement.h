﻿#ifndef FILEMANAGEMENT_H
#define FILEMANAGEMENT_H

#include <QApplication>
#include <QTreeView>
#include <QStandardItem>
#include <QStandardItemModel>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QDir>
#include <QMessageBox>

class FileManage
{
public:
    FileManage(QString n,QString p,QString t);
private:
    QString name;
    QString path;
    QString dtype;
public:
    QString getName(){return name;}
    QString getPath(){return path;}
    QString getType(){return dtype;}
    void setName(QString n){name = n;}
    void setPath(QString p){path = p;}
    void setType(QString t){dtype = t;}
};

#endif // FILEMANAGEMENT_H
