﻿#include "DemageDescription.h"

DemageDescription::DemageDescription()
{

}

//改变shp颜色
//***改变shp的大小和颜色，步骤1
osg::Image *DemageDescription::createImage(int width, int height, osg::Vec3 color)
{
    osg::ref_ptr<osg::Image> image = new osg::Image;
    image->allocateImage( width, height, 1, GL_RGB, GL_UNSIGNED_BYTE );
    unsigned char* data = image->data();
    for ( int y=0; y<height; ++y )
    {
        for ( int x=0; x<width; ++x )
        {
            *(data++) = color.x();
            *(data++) = color.y();
            *(data++) = color.z();
        }
    }
    return image.release();
}

//***改变shp的大小和颜色，步骤2
void DemageDescription::ChangeSHP(osg::ref_ptr<osg::Node> node, osg::Vec4 color, float size, bool IsPoint)
{
    osg::ref_ptr<osg::Image> image= createImage(256,256,osg::Vec3(color.x(),color.y(),color.z()));
    if (image.get())
    {
        osg::ref_ptr<osg::Texture2D> texture=new osg::Texture2D();
        texture->setImage(image.get());

        //设置自动生成纹理坐标
        osg::ref_ptr<osg::TexGen> texgen=new osg::TexGen();
        texgen->setMode(osg::TexGen::NORMAL_MAP);

        //设置纹理环境，模式为BLEND
        osg::ref_ptr<osg::TexEnv> texenv=new osg::TexEnv;
        texenv->setMode(osg::TexEnv::ADD);
        texenv->setColor(color);

        //启动单元一自动生成纹理坐标，并使用纹理
        osg::ref_ptr<osg::StateSet> state=new osg::StateSet;

        state->setTextureAttributeAndModes(1,texture.get(),osg::StateAttribute::ON);
        state->setTextureAttributeAndModes(1,texgen.get(),osg::StateAttribute::ON);

         if(IsPoint)
             {
                 osg::ref_ptr<osg::Point> pointsize = new osg::Point;
                 pointsize->setSize(size);
                 state->setAttributeAndModes(pointsize,osg::StateAttribute::ON);
                 state->setMode(GL_POINT_SPRITE_ARB,osg::StateAttribute::ON); //点精灵效果(需要添加osg/PointSprite引用)
             }
             else
             {
                 osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth;
                 lw->setWidth(size);
                 state->setAttributeAndModes(lw,osg::StateAttribute::ON);
             }
         node->setStateSet(state.get());
    }
}


//读取shp数据
list<list<Point3D>> DemageDescription::gdal_read_polygonshp(const char* path)   //函数前必须要加上类名（VS中可以不加）
{
    list<list<Point3D>>* p_list2=new list<list<Point3D>>;

    GDALAllRegister();
    GDALDataset   *poDS;
    CPLSetConfigOption("SHAPE_ENCODING", "");  //解决中文乱码问题
    //读取shp文件
    poDS = (GDALDataset*)GDALOpenEx(path, GDAL_OF_VECTOR, NULL, NULL, NULL);

    if (poDS == NULL)
    {
        cout << "Open failed.\n%s" << endl;
    }

    int nLayerCnt = poDS->GetLayerCount();
    int nLayerIdx = 0;

    for (; nLayerIdx < nLayerCnt; ++nLayerIdx)
    {
        OGRLayer* curLayer = poDS->GetLayer(nLayerIdx);
        GIntBig nFtrCount = curLayer->GetFeatureCount();

        if (NULL != curLayer->GetName())
        {
            std::cout << curLayer->GetName() << " 's FeatureCount :" << nFtrCount << std::endl;
        }
        OGRFeature * ftr = curLayer->GetNextFeature();
        double height;
        while (ftr)
        {
//            double height = ftr->GetFieldAsDouble("Height");  //获取属性表值
            height=ftr->GetFieldAsDouble("Height");  //获取属性表值
            if(height==0.0)
                height=50.0;
            OGRGeometry * poGeom = ftr->GetGeometryRef();
            switch (wkbFlatten(poGeom->getGeometryType()))
            {
//            case wkbLineString:
//            {
//                OGRLineString* poLS = static_cast<OGRLineString*>(poGeom);
//                const char* pGeoName = poLS->getGeometryName();
//                if (NULL != pGeoName)
//                {
//                    std::cout << " Geo name:" << pGeoName << std::endl;
//                }
//                int iPnum = poLS->getNumPoints();
//                std::cout << " Point Count:" << iPnum;
//                double iLen = poLS->get_Length();
//                std::cout << " Len :" << iLen;
//                for (int i = 0; i < iPnum; i++)
//                {
//                    Point3D p_Point3D;
//                    p_Point3D.X = poLS->getX(i);
//                    p_Point3D.Y = poLS->getY(i);
//                    p_Point3D.Z = poLS->getZ(i);
//                    p_list->push_back(p_Point3D);
//                    std::cout << " X : " << p_Point3D.X << " , Y : " << p_Point3D.Y<<" , Z : "<<p_Point3D.Z;
//                }
//                std::cout << std::endl;
//            }
//            break;
            case wkbPolygon:  //多边形
            {
                list<Point3D>* p_list= new list<Point3D>;
                OGRPolygon* poPoly = static_cast<OGRPolygon*>(poGeom);
                //cout << "poPoly->getNumInteriorRings():" << "  " << poPoly->getNumInteriorRings(); //获取的是内环个数，非坐标
                poPoly->closeRings();       //闭合环，使起点与终点重合
//                OGREnvelope3D* poEnvelop3D = new OGREnvelope3D;    //获取该要素的三维范围
//                poPoly->getEnvelope(poEnvelop3D);

                OGRLinearRing* poLR=poPoly->getExteriorRing();
                int Num=poLR->getNumPoints(); //获取内环点个数(起点与终点重合)

//                cout<<"Num: "<<Num<<endl;
//                poLR->getX(0);
//                cout<<"X: "<<poLR->getX(0)<<" X5: "<<poLR->getX(4)<<endl;

                for(int i=0;i<Num;i++)
                {
                    Point3D p_Point3D;
                    p_Point3D.X = poLR->getX(i);
                    p_Point3D.Y = poLR->getY(i);
                    p_Point3D.Z = poLR->getZ(i);
                    p_Point3D.height=height;
                    p_list->push_front(p_Point3D);
                }
                p_list2->push_front(*p_list);
            }
            default:
                break;
            }

            ftr = curLayer->GetNextFeature();
        }

        delete curLayer;
    }
    return *p_list2;
    GDALClose(poDS);  //不注释掉会报错

}

list<Point3D> DemageDescription::gdal_read_pointshp(const char *path)
{
    list<Point3D>* p_list=new list<Point3D>;

    GDALAllRegister();
    GDALDataset   *poDS;
    CPLSetConfigOption("SHAPE_ENCODING", "");  //解决中文乱码问题
    //读取shp文件
    poDS = (GDALDataset*)GDALOpenEx(path, GDAL_OF_VECTOR, NULL, NULL, NULL);

    if (poDS == NULL)
    {
        cout << "Open failed.\n%s" << endl;
    }

    int nLayerCnt = poDS->GetLayerCount();
    int nLayerIdx = 0;

    for (; nLayerIdx < nLayerCnt; ++nLayerIdx)
    {
        OGRLayer* curLayer = poDS->GetLayer(nLayerIdx);
        GIntBig nFtrCount = curLayer->GetFeatureCount();

        if (NULL != curLayer->GetName())
        {
            std::cout << curLayer->GetName() << " 's FeatureCount :" << nFtrCount << std::endl;
        }
        OGRFeature * ftr = curLayer->GetNextFeature();
        while (ftr)
        {
            OGRGeometry * poGeom = ftr->GetGeometryRef();
            switch (wkbFlatten(poGeom->getGeometryType()))
            {
            case wkbPoint:
                case wkbPoint25D:
                {
                    OGRPoint* poPS = static_cast<OGRPoint*>(poGeom);
                    Point3D p_Point3D;
                    p_Point3D.X = poPS->getX();
                    p_Point3D.Y = poPS->getY();
                    p_Point3D.Z = poPS->getZ();
                    p_list->push_back(p_Point3D);
                }
                break;
            default:
                break;
            }

            ftr = curLayer->GetNextFeature();
        }

        delete curLayer;
    }
    return *p_list;
    GDALClose(poDS);  //不注释掉会报错
}

//绘制建筑物
osg::ref_ptr<osg::Geometry> DemageDescription::Drawhousehall(std::list<Point3D> plist,osg::ref_ptr<osg::Vec4Array> colors)
{
    std::list<Point3D>::iterator it;
    //创建顶点数组，逆时针添加
    osg::ref_ptr<osg::Vec3Array> verticeshall = new osg::Vec3Array;
    int i=0;
    for ( it=plist.begin() ; it != plist.end(); it++ )
    {
        verticeshall->push_back(osg::Vec3(it->X, it->Y, it->Z)); //0
        i++;
        verticeshall->push_back(osg::Vec3(it->X, it->Y, it->Z+it->height)); //1
        i++;
    }
    //创建一个几何对象
    osg::ref_ptr<osg::Geometry> samplehousehall = new osg::Geometry;
    //设置顶点数据、纹理坐标、法线数组
    samplehousehall->setVertexArray(verticeshall.get());
    samplehousehall->setColorArray(colors.get());

    //设置颜色的绑定方式为一个属性与所有顶点绑定
    samplehousehall->setColorBinding(osg::Geometry::BIND_OVERALL);
    //添加图元，多段四边形条带，即一系列四边形
    samplehousehall->addPrimitiveSet(new osg::DrawArrays(osg::DrawArrays::QUAD_STRIP, 0, i));

    return samplehousehall;

}

osg::ref_ptr<osg::Geometry> DemageDescription::Drawhouseroof(std::list<Point3D> plist,osg::ref_ptr<osg::Vec4Array> colors)
{
    std::list<Point3D>::iterator it;
    //创建顶点数组，逆时针添加
    osg::ref_ptr<osg::Vec3Array> verticesroof = new osg::Vec3Array;
    int t=0;
    for ( it=plist.begin() ; it != plist.end(); it++ )
    {
        verticesroof->push_back(osg::Vec3(it->X, it->Y, it->Z+it->height)); //1
        t++;
    }

//    //创建颜色数组
//    osg::ref_ptr<osg::Vec4Array> colors = new osg::Vec4Array;
//    //添加数据
//    colors->push_back(osg::Vec4(255.0, 0.0, 0.0, 1.0));
    //创建一个几何对象
    osg::ref_ptr<osg::Geometry> samplehouseroof = new osg::Geometry;
    //设置顶点数据、纹理坐标、法线数组
    samplehouseroof->setVertexArray(verticesroof.get());
    samplehouseroof->setColorArray(colors.get());

    //设置颜色的绑定方式为一个属性与所有顶点绑定
    samplehouseroof->setColorBinding(osg::Geometry::BIND_OVERALL);
    //添加图元，多段四边形条带，即一系列四边形
    samplehouseroof->addPrimitiveSet(new osg::DrawArrays(osg::DrawArrays::QUADS, 0, t));

    return samplehouseroof;

}

//用Geode加载
osg::ref_ptr<osg::Geode> DemageDescription::Drawsamplehouse(std::list<Point3D> plist,osg::ref_ptr<osg::Vec4Array> colors)
{
    osg::ref_ptr<osg::Geode> samplehouse=new osg::Geode;
    osg::ref_ptr<osg::Geometry> househall= new osg::Geometry;
    osg::ref_ptr<osg::Geometry> houseroof=new osg::Geometry;

    househall=Drawhousehall(plist,colors);
    houseroof=Drawhouseroof(plist,colors);

    samplehouse->addDrawable(househall.get());
    samplehouse->addDrawable(houseroof.get());

    return samplehouse;

}


//绘制图例
//创建图例，主要显示各种灾害颜色代表意义
osg::ref_ptr<osg::Node> DemageDescription::CreateLegend(osg::ref_ptr<osg::Group> legendroot)
{
    QTextCodec *codec=QTextCodec::codecForName("GBK");
    QTextCodec::setCodecForLocale(codec);
    QTextCodec* code = QTextCodec::codecForName("UTF-8");

    unsigned int Num=legendroot->getNumChildren();  //获取Group中节点个数

    //图例要素绘制
    //几何体节点
    osg::Geode*geode=new osg::Geode();

    double h=(Num+1)*20+20.0;
    double Height=10.0;
    double startwidth=500.0f;

    //图例面板背景颜色
    osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
    osg::ref_ptr<osg::Vec4Array>colorArray=new osg::Vec4Array;
    geometry=osg::createTexturedQuadGeometry(osg::Vec3(startwidth-5,0.0f,0.0f),
                                             osg::Vec3(160.0f,0.0f,0.0f),osg::Vec3(0.0f,h,0.0f));    //中心（起点）、宽、高
    colorArray->push_back(osg::Vec4(245.0f,245.0f,245.0f,0.5f)); //getColor是根据属性值计算颜色值的函数，需自行定义
    geometry->setColorArray(colorArray.get());
    geometry->setColorBinding(osg::Geometry::BIND_OVERALL);
    geode->addChild(geometry);

    //文字
    //图例
    osgText::Text *text=new osgText::Text;
    //设置字体
    text->setFont("fonts/simhei.ttf");
    //设置文字显示的位置
    text->setPosition(osg::Vec3(startwidth,h-20,0.0f));
    text->setColor( osg::Vec4( 0, 0, 0, 1));
    text->setText(L"图例");//设置显示的文字

    text->setCharacterSize(16);  //设置字体大小
    geode->addDrawable(text);   //将文字Text作这drawable加入到Geode节点中

    for(unsigned int t=0;t<Num;t++)
    {
        if(legendroot->getChild(t)->getName()=="Hospital")
        {
            //示意图片
            osg::ref_ptr<osg::Geometry>Hospitalgeometry=new osg::Geometry;
            //读取图片，用于贴图（osg自带的资源）
            string filepath="E:/ChuanJuDisasterModel/testdata/picture/Hospital.png";
            osg::Vec3 position=osg::Vec3(startwidth,Height,0.0f);
            Hospitalgeometry=DrawPicture1(filepath,position);
            geode->addChild(Hospitalgeometry);

            //医院
            osgText::Text *Hospitaltext=new osgText::Text;
            //设置字体
            Hospitaltext->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            Hospitaltext->setPosition(osg::Vec3(startwidth+30,Height+5,0.0f));
            Hospitaltext->setColor( osg::Vec4( 0, 0, 0, 1));
            Hospitaltext->setText(L"医院");    //设置显示的文字
            Hospitaltext->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(Hospitaltext);
            Height=Height+20.0;
        }
        else if(legendroot->getChild(t)->getName()=="School")
        {
            //示意图片
            osg::ref_ptr<osg::Geometry>Schoolgeometry=new osg::Geometry;
            //读取图片，用于贴图（osg自带的资源）
            string filepath="E:/ChuanJuDisasterModel/testdata/picture/School.png";
            osg::Vec3 position=osg::Vec3(startwidth,Height,0.0f);
            Schoolgeometry=DrawPicture1(filepath,position);
            geode->addChild(Schoolgeometry);

            //学校
            osgText::Text *Schooltext=new osgText::Text;
            //设置字体
            Schooltext->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            Schooltext->setPosition(osg::Vec3(startwidth+30,Height+5,0.0f));
            Schooltext->setColor( osg::Vec4( 0, 0, 0, 1));
            Schooltext->setText(L"学校");    //设置显示的文字
            Schooltext->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(Schooltext);
            Height=Height+20.0;
        }
        else if(legendroot->getChild(t)->getName()=="HydropowerStation")
        {
            //示意图片
            osg::ref_ptr<osg::Geometry>HydropowerStationgeometry=new osg::Geometry;
            //读取图片，用于贴图（osg自带的资源）
            string filepath="E:/ChuanJuDisasterModel/testdata/picture/Hydropower Station.png";
            osg::Vec3 position=osg::Vec3(startwidth,Height,0.0f);
            HydropowerStationgeometry=DrawPicture1(filepath,position);
            geode->addChild(HydropowerStationgeometry);

            //发电站
            osgText::Text *HydropowerStationtext=new osgText::Text;
            //设置字体
            HydropowerStationtext->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            HydropowerStationtext->setPosition(osg::Vec3(startwidth+30,Height+5,0.0f));
            HydropowerStationtext->setColor( osg::Vec4( 0, 0, 0, 1));
            HydropowerStationtext->setText(L"水利设施");    //设置显示的文字
            HydropowerStationtext->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(HydropowerStationtext);
            Height=Height+20.0;
        }
        else if(legendroot->getChild(t)->getName()=="Bridge2")
        {
            //示意图片
            osg::ref_ptr<osg::Geometry>Bridge2geometry=new osg::Geometry;
            //读取图片，用于贴图（osg自带的资源）
            string filepath="E:/ChuanJuDisasterModel/testdata/picture/Bridge2.png";
            osg::Vec3 position=osg::Vec3(startwidth,Height,0.0f);
            Bridge2geometry=DrawPicture1(filepath,position);
            geode->addChild(Bridge2geometry);

            //桥梁
            osgText::Text *Bridge2text=new osgText::Text;
            //设置字体
            Bridge2text->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            Bridge2text->setPosition(osg::Vec3(startwidth+30,Height+5,0.0f));
            Bridge2text->setColor( osg::Vec4( 0, 0, 0, 1));
            Bridge2text->setText(L"桥梁");    //设置显示的文字
            Bridge2text->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(Bridge2text);
            Height=Height+20.0;
        }
        else if(legendroot->getChild(t)->getName()=="unsafebuilding")
        {
            //绘制矩形框
            osg::ref_ptr<osg::Geometry>unsafebuildinggeometry=new osg::Geometry;
            osg::Vec3 position1=osg::Vec3(startwidth,Height,0.0f);
            osg::ref_ptr<osg::Vec4Array> colorArrayrect=new osg::Vec4Array;
            colorArrayrect->push_back(osg::Vec4(255.0f,0.0f,0.0f,1.0f));
            unsafebuildinggeometry=DrawRectangle(position1, colorArrayrect);
            geode->addChild(unsafebuildinggeometry);

            //受损建筑
            osgText::Text *unsafebuildingtext=new osgText::Text;
            //设置字体
            unsafebuildingtext->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            unsafebuildingtext->setPosition(osg::Vec3(startwidth+30,Height+2,0.0f));
            unsafebuildingtext->setColor( osg::Vec4( 0, 0, 0, 1));
            unsafebuildingtext->setText(L"受损建筑");    //设置显示的文字
            unsafebuildingtext->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(unsafebuildingtext);
            Height=Height+20.0;
        }
        else if(legendroot->getChild(t)->getName()=="safebuilding")
        {
            //绘制矩形框
            osg::ref_ptr<osg::Geometry>safebuildinggeometry=new osg::Geometry;
            osg::Vec3 position1=osg::Vec3(startwidth,Height,0.0f);
            osg::ref_ptr<osg::Vec4Array> colorArrayrect=new osg::Vec4Array;
            colorArrayrect->push_back(osg::Vec4(0.0f,255.0f,0.0f,1.0f));
            safebuildinggeometry=DrawRectangle(position1, colorArrayrect);
            geode->addChild(safebuildinggeometry);

            //安全建筑
            osgText::Text *safebuildingtext=new osgText::Text;
            //设置字体
            safebuildingtext->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            safebuildingtext->setPosition(osg::Vec3(startwidth+30,Height+2,0.0f));
            safebuildingtext->setColor( osg::Vec4( 0, 0, 0, 1));
            safebuildingtext->setText(L"安全建筑");    //设置显示的文字
            safebuildingtext->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(safebuildingtext);
            Height=Height+20.0;
        }
        else if(legendroot->getChild(t)->getName()=="building")
        {
            //绘制矩形框
            osg::ref_ptr<osg::Geometry>buildinggeometry=new osg::Geometry;
            osg::Vec3 position1=osg::Vec3(startwidth,Height,0.0f);
            osg::ref_ptr<osg::Vec4Array> colorArrayrect=new osg::Vec4Array;
            colorArrayrect->push_back(osg::Vec4(250.0f,128.0f,10.0f,1.0f));
            buildinggeometry=DrawRectangle(position1, colorArrayrect);
            geode->addChild(buildinggeometry);

            //危险建筑
            osgText::Text *buildingtext=new osgText::Text;
            //设置字体
            buildingtext->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            buildingtext->setPosition(osg::Vec3(startwidth+30,Height+2,0.0f));
            buildingtext->setColor( osg::Vec4( 0, 0, 0, 1));
            buildingtext->setText(L"危险建筑");    //设置显示的文字
            buildingtext->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(buildingtext);
            Height=Height+20.0;
        }
        else if(legendroot->getChild(t)->getName()=="huadao_Line")
        {
            //红色直线
            osg::ref_ptr<osg::Geometry>huadao_Linegeometry=new osg::Geometry;
            osg::ref_ptr<osg::Vec4Array>colorArray1=new osg::Vec4Array;
            colorArray1->push_back(osg::Vec4(255.0f,0.0f,0.0f,1.0f));  //设置线的颜色
            huadao_Linegeometry=DrawLine(osg::Vec3(startwidth,Height,0.0f),osg::Vec3(startwidth+20.0,Height,0.0f),colorArray1,3.0f);
            geode->addChild(huadao_Linegeometry);

            //滑坡边界
            osgText::Text *huadao_Linetext=new osgText::Text;
            //设置字体
            huadao_Linetext->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            huadao_Linetext->setPosition(osg::Vec3(startwidth+30,Height-5,0.0f));
            huadao_Linetext->setColor( osg::Vec4( 0, 0, 0, 1));
            huadao_Linetext->setText(L"滑坡边界");    //设置显示的文字
            huadao_Linetext->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(huadao_Linetext);
            Height=Height+20.0;
        }
        else if(legendroot->getChild(t)->getName()=="saferoad")
        {
            //绿色直线
            osg::ref_ptr<osg::Geometry>saferoadgeometry=new osg::Geometry;
            osg::ref_ptr<osg::Vec4Array>colorArray1=new osg::Vec4Array;
            colorArray1->push_back(osg::Vec4(0.0f,255.0f,0.0f,1.0f));  //设置线的颜色
            saferoadgeometry=DrawLine(osg::Vec3(startwidth,Height,0.0f),osg::Vec3(startwidth+20.0,Height,0.0f),colorArray1,3.0f);
            geode->addChild(saferoadgeometry);

            //安全道路
            osgText::Text *saferoadtext=new osgText::Text;
            //设置字体
            saferoadtext->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            saferoadtext->setPosition(osg::Vec3(startwidth+30,Height-5,0.0f));
            saferoadtext->setColor( osg::Vec4( 0, 0, 0, 1));
            saferoadtext->setText(L"安全道路");    //设置显示的文字
            saferoadtext->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(saferoadtext);
            Height=Height+20.0;
        }
        else if(legendroot->getChild(t)->getName()=="unsaferoad")
        {
            //橘色直线
            osg::ref_ptr<osg::Geometry>unsaferoadgeo=new osg::Geometry;
            osg::ref_ptr<osg::Vec4Array>colorArray1=new osg::Vec4Array;
            colorArray1->push_back(osg::Vec4(255.0f,165.0f,0.0f,1.0f));  //设置线的颜色
            unsaferoadgeo=DrawLine(osg::Vec3(startwidth,Height,0.0f),osg::Vec3(startwidth+20.0,Height,0.0f),colorArray1,3.0f);
            geode->addChild(unsaferoadgeo);

            //危险道路
            osgText::Text *unsaferoadtext=new osgText::Text;
            //设置字体
            unsaferoadtext->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            unsaferoadtext->setPosition(osg::Vec3(startwidth+30,Height-5,0.0f));
            unsaferoadtext->setColor( osg::Vec4( 0, 0, 0, 1));
            unsaferoadtext->setText(L"危险道路");    //设置显示的文字
            unsaferoadtext->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(unsaferoadtext);
            Height=Height+20.0;
        }
        else if(legendroot->getChild(t)->getName()=="normalreiver")
        {
            //蓝色直线
            osg::ref_ptr<osg::Geometry>normalreivergeometry=new osg::Geometry;
            osg::ref_ptr<osg::Vec4Array>colorArray1=new osg::Vec4Array;
            colorArray1->push_back(osg::Vec4(0.0f,191.0f,255.0f,1.0f));  //设置线的颜色
            normalreivergeometry=DrawLine(osg::Vec3(startwidth,Height,0.0f),osg::Vec3(startwidth+20.0,Height,0.0f),colorArray1,3.0f);
            geode->addChild(normalreivergeometry);

            //原始河道
            osgText::Text *normalreivertext=new osgText::Text;
            //设置字体
            normalreivertext->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            normalreivertext->setPosition(osg::Vec3(startwidth+30,Height-5,0.0f));
            normalreivertext->setColor( osg::Vec4( 0, 0, 0, 1));
            normalreivertext->setText(L"原始河道");    //设置显示的文字
            normalreivertext->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(normalreivertext);
            Height=Height+20.0;
        }
        else if(legendroot->getChild(t)->getName()=="maskreiver")
        {
            //红色虚线
            osg::ref_ptr<osg::Geometry>maskreivergeo=new osg::Geometry;
            osg::ref_ptr<osg::Vec4Array>colorArray2=new osg::Vec4Array;
            colorArray2->push_back(osg::Vec4(255,0.0,0.0,1.0f)); //设置线的颜色
            maskreivergeo=DrawStippleLine(osg::Vec3(startwidth,Height,0.0f),osg::Vec3(startwidth+20.0,Height,0.0f),colorArray2,3.0f);
            geode->addChild(maskreivergeo);

            //堵塞河道
            osgText::Text *maskreivertext=new osgText::Text;
            //设置字体
            maskreivertext->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            maskreivertext->setPosition(osg::Vec3(startwidth+30,Height-5,0.0f));
            maskreivertext->setColor( osg::Vec4( 0, 0, 0, 1));
            maskreivertext->setText(L"堵塞河道");//设置显示的文字
            maskreivertext->setCharacterSize(12);  //设置字体大小
            geode->addDrawable(maskreivertext);
            Height=Height+20.0;
        }
    }

    //设置状态
    osg::StateSet* stateset = geode->getOrCreateStateSet();
    stateset->setMode(GL_LIGHTING,osg::StateAttribute::OFF);//关闭灯光
    stateset->setMode(GL_DEPTH_TEST,osg::StateAttribute::OFF);//关闭深度测试
    //打开GL_BLEND混合模式（以保证Alpha纹理正确）
    stateset->setMode(GL_BLEND,osg::StateAttribute::ON);

    //相机
    osg::Camera* camera = new osg::Camera;
    //设置透视矩阵
    camera->setProjectionMatrix(osg::Matrix::ortho2D(0,600,0,600));//正交投影
    //设置绝对参考坐标系，确保视图矩阵不会被上级节点的变换矩阵影响
    camera->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
    //视图矩阵为默认的
    camera->setViewMatrix(osg::Matrix::identity());
    //设置背景为透明，否则的话可以设置ClearColor
    camera->setClearMask(GL_DEPTH_BUFFER_BIT);
    camera->setAllowEventFocus( false);//不响应事件，始终得不到焦点
    //设置渲染顺序，必须在最后渲染
    camera->setRenderOrder(osg::Camera::POST_RENDER);
    camera->addChild(geode);//将要显示的Geode节点加入到相机
//    camera->addChild(geometry3);
    return camera;
}

//绘制直线
osg::ref_ptr<osg::Geometry> DemageDescription::DrawLine(osg::Vec3 startvec3, osg::Vec3 endvec3, osg::ref_ptr<osg::Vec4Array> colors,double linewidth)
{
    osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;

    osg::ref_ptr<osg::Vec3Array> vecarry1 = new osg::Vec3Array();
    vecarry1->push_back(startvec3);
    vecarry1->push_back(endvec3);
    geometry->setVertexArray(vecarry1.get());
    geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, 2));
    osg::ref_ptr<osg::StateSet> stateset = geometry->getOrCreateStateSet();
    osg::ref_ptr<osg::LineWidth> lineWid = new osg::LineWidth(linewidth);
    stateset->setAttribute(lineWid);
    geometry->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源

    geometry->setColorArray(colors.get());
    geometry->setColorBinding(osg::Geometry::BIND_OVERALL);
    return geometry;
}

//绘制虚线
osg::ref_ptr<osg::Geometry> DemageDescription::DrawStippleLine(osg::Vec3 startvec3, osg::Vec3 endvec3, osg::ref_ptr<osg::Vec4Array> colors, double linewidth)
{
    osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;

    osg::ref_ptr<osg::Vec3Array> vecarry1 = new osg::Vec3Array();
    vecarry1->push_back(startvec3);
    vecarry1->push_back(endvec3);
    geometry->setVertexArray(vecarry1.get());
    geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, 2));
    osg::ref_ptr<osg::StateSet> stateset = geometry->getOrCreateStateSet();
    osg::ref_ptr<osg::LineWidth> lineWid = new osg::LineWidth(linewidth);
    stateset->setAttribute(lineWid);
    osg::ref_ptr<osg::LineStipple> linestipple=new osg::LineStipple(1,0xf0f0);  //设置虚线模式
    stateset->setAttribute(linestipple);
    geometry->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源
    geometry->setColorArray(colors.get());
    geometry->setColorBinding(osg::Geometry::BIND_OVERALL);
    return geometry;
}

//绘制图片
osg::ref_ptr<osg::Geometry> DemageDescription::DrawPicture1(string filepath,osg::Vec3 position)
{
    osg::ref_ptr<osg::Geometry>geometry3=new osg::Geometry;
    geometry3=osg::createTexturedQuadGeometry(position,osg::Vec3(20.0f,0.0f,0.0f),osg::Vec3(0.0f,20.0f,0.0f)); //绘制矩形框（中心、宽、高）

    //读取图片，用于贴图（osg自带的资源）
    osg::ref_ptr<osg::Image> mImage = osgDB::readImageFile(filepath);

    if (mImage.get())
    {
        //关联image
        osg::ref_ptr<osg::Texture2D> texture=new osg::Texture2D();
        texture->setImage(mImage.get());

        //设置自动生成纹理坐标
        osg::ref_ptr<osg::TexGen> texgen=new osg::TexGen();
        texgen->setMode(osg::TexGen::SPHERE_MAP);

        //设置纹理环境，模式为BLEND
        osg::ref_ptr<osg::TexEnv> texenv=new osg::TexEnv;
        texenv->setMode(osg::TexEnv::Mode::ADD);
        texenv->setColor(osg::Vec4(0.6,0.6,0.6,0.0));

        //启动单元一自动生成纹理坐标，并使用纹理
        osg::ref_ptr<osg::StateSet> state=new osg::StateSet;
        //关联Texture2D纹理对象，第三个参数默认为ON(一定要注意下面三个函数参数的设置)
        state->setTextureAttributeAndModes(0,texture.get(),osg::StateAttribute::ON);
        state->setTextureAttributeAndModes(1,texgen.get(),osg::StateAttribute::ON);
        state->setTextureAttribute(1,texenv.get());
        //启用混合
        state->setMode(GL_BLEND, osg::StateAttribute::ON);
        //关闭光源
        state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

        geometry3->setStateSet(state.get());

    }
    return geometry3;
}

//绘制矩形
osg::ref_ptr<osg::Geometry> DemageDescription::DrawRectangle(osg::Vec3 position, osg::ref_ptr<osg::Vec4Array> colorArray)
{
    osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
    geometry=osg::createTexturedQuadGeometry(position,osg::Vec3(20.0f,0.0f,0.0f),osg::Vec3(0.0f,15.0f,0.0f));
    geometry->setColorArray(colorArray.get());
    geometry->setColorBinding(osg::Geometry::BIND_OVERALL);
    return geometry;
}

//布告板技术
//创建树木（使用布告板技术）
osg::ref_ptr<osg::Node> DemageDescription::CreateBillboard(osg::ref_ptr<osg::Image> mImage)
{
    //创建四边形
    osg::ref_ptr<osg::Geometry> mGeometry = new osg::Geometry;

    //设置顶点
    osg::ref_ptr<osg::Vec3Array> mVertexArray = new osg::Vec3Array;
    mVertexArray->push_back(osg::Vec3(-0.5f, 0.0f, -0.5f));
    mVertexArray->push_back(osg::Vec3(0.5f, 0.0f, -0.5f));
    mVertexArray->push_back(osg::Vec3(0.5f, 0.0f, 0.5f));
    mVertexArray->push_back(osg::Vec3(-0.5f, 0.0f, 0.5f));
    mGeometry->setVertexArray(mVertexArray);

    //设置法线
    osg::ref_ptr<osg::Vec3Array> mNormal = new osg::Vec3Array;
    mNormal->push_back(osg::Vec3(1.0f, 0.0f, 0.0f) ^ osg::Vec3(0.0f, 0.0f, 1.0f));
    mGeometry->setNormalArray(mNormal);
    mGeometry->setNormalBinding(osg::Geometry::BIND_OVERALL);

    //设置纹理坐标（没看懂）
    osg::ref_ptr<osg::Vec2Array> mTextureArray = new osg::Vec2Array;
    mTextureArray->push_back(osg::Vec2(0.0f, 0.0f));
    mTextureArray->push_back(osg::Vec2(1.0f, 0.0f));
    mTextureArray->push_back(osg::Vec2(1.0f, 1.0f));
    mTextureArray->push_back(osg::Vec2(0.0f, 1.0f));
    mGeometry->setTexCoordArray(0, mTextureArray);

    //绘制四边形
    mGeometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS, 0, 4));

    if (mImage)
    {
        //状态属性对象
        osg::ref_ptr<osg::StateSet> mStateSet = new osg::StateSet;
        //创建一个Texture2D属性对象
        osg::ref_ptr<osg::Texture2D> mTexture = new osg::Texture2D;
        //关联image
        mTexture->setImage(mImage);
        //关联Texture2D纹理对象，第三个参数默认为ON
        mStateSet->setTextureAttributeAndModes(0, mTexture, osg::StateAttribute::ON);
        //启用混合
        mStateSet->setMode(GL_BLEND, osg::StateAttribute::ON);
        //关闭光源
        mStateSet->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
        mGeometry->setStateSet(mStateSet);
    }

    //创建Billboard对象1
    osg::ref_ptr<osg::Billboard> mBillboard1 = new osg::Billboard;
    //设置旋转模式为绕视点
    mBillboard1->setMode(osg::Billboard::POINT_ROT_EYE);
    //添加Drawable, 并设置位置
    mBillboard1->addDrawable(mGeometry, osg::Vec3(0.0f, 0.0f, 0.0f));

    osg::ref_ptr<osg::Group> mBillboardGroup = new osg::Group;
    mBillboardGroup->addChild(mBillboard1);

    return mBillboardGroup.get();
}


//展示
osg::ref_ptr<osg::Group> DemageDescription::returnroot()
{
	osg::ref_ptr<osg::Group> root = new osg::Group;
	//绘制虚线（调用drawline.h)
    osg::ref_ptr<osg::Geometry> geometry_rever = new osg::Geometry;
    geometry_rever->setUseDisplayList(true);
    geometry_rever->setDrawCallback(new DrawCallback);
    osg::ref_ptr<osg::Geode> geo_rever = new osg::Geode;
    geo_rever->addDrawable(geometry_rever);   //加了全部设置为虚线，不加没效果
    root->addChild(geo_rever.get());

    //动态绘制图例
    osg::ref_ptr<osg::Group> legendroot =new osg::Group;

    //加载不安全道路
    osg::ref_ptr<osg::Node> unsaferoad =osgDB::readNodeFile("E:/ChuanJuDisasterModel/testdata/road/unsaferoad.shp");
	ChangeSHP(unsaferoad,osg::Vec4(255.0f,165.0f,0.0f,1.0),3.0f,false); //改变不安全道路轮廓线的形状
    root->addChild(unsaferoad);
    unsaferoad->setName("unsaferoad");
    legendroot->addChild(unsaferoad);

    //加载淹没河道
    osg::ref_ptr<osg::Node> maskreiver =osgDB::readNodeFile("E:/ChuanJuDisasterModel/testdata/reiver/reiver_1_prj.shp");
    ChangeSHP(maskreiver,osg::Vec4(255.0f,0.0f,0.0f,1.0),5.0f,false); //改变堵塞河流轮廓线的形状
    //设置线宽
    osg::ref_ptr<osg::StateSet> stateset = maskreiver->getOrCreateStateSet();
    osg::ref_ptr<osg::LineStipple> linestipple=new osg::LineStipple(5,0xf0f0);  //设置虚线模式
    stateset->setAttribute(linestipple);
    maskreiver->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源
    root->addChild(maskreiver);
    maskreiver->setName("maskreiver");
    legendroot->addChild(maskreiver);


    //设置shp线大小和颜色

    //加载正常河流
    osg::ref_ptr<osg::Node> normalreiver =osgDB::readNodeFile("E:/ChuanJuDisasterModel/testdata/reiver/reiver_prj.shp");
    ChangeSHP(normalreiver,osg::Vec4(0.0f,191.0f,255.0f,1.0),3.0f,false); //改变河流轮廓线的形状
    root->addChild(normalreiver);
    normalreiver->setName("normalreiver");
    legendroot->addChild(normalreiver);

    //加载滑道
    osg::ref_ptr<osg::Node> huadao_Line =osgDB::readNodeFile("E:/ChuanJuDisasterModel/testdata/huadao_WithZ/huadao_Line.shp");
    ChangeSHP(huadao_Line,osg::Vec4(255.0f,0.0f,0.0f,1.0),3.0f,false); //改变滑坡轮廓线的形状
    root->addChild(huadao_Line);
    huadao_Line->setName("huadao_Line");
    legendroot->addChild(huadao_Line);

    //加载安全道路
    osg::ref_ptr<osg::Node> saferoad =osgDB::readNodeFile("E:/ChuanJuDisasterModel/testdata/road/saferoad.shp");
    ChangeSHP(saferoad,osg::Vec4(0.0f,255.0f,0.0f,1.0),3.0f,false); //改变道路轮廓线的形状
    root->addChild(saferoad);
    saferoad->setName("saferoad");
    legendroot->addChild(saferoad);

    //推高建筑物
    //读取不安全建筑shp(用Geode添加)
    //加载受损房屋
    const char* path="E:/ChuanJuDisasterModel/testdata/building_WithZ/building1_prj.shp";
    osg::ref_ptr<osg::Node> unsafebuilding=osgDB::readNodeFile("E:/ChuanJuDisasterModel/testdata/building_WithZ/building1_prj.shp");  //用于创建图例，Node必须要有值，不然直接设置Name会报错
    list2=gdal_read_polygonshp(path);  //保存shp坐标点
    std::list<std::list<Point3D>>::iterator it2;
    Drawhouse *house=new Drawhouse();
    //设置颜色
    osg::ref_ptr<osg::Vec4Array> housecolors = new osg::Vec4Array;
    //添加数据
    housecolors->push_back(osg::Vec4(255, 0.0, 0.0, 1.0));
    for ( it2=list2.begin() ; it2 != list2.end(); it2++ )
    {
        plist=*it2;
        osg::ref_ptr<osg::Geode> building1_prjnode=house->Drawsamplehouse(plist,housecolors);
        //关闭光源(必须添加，不然会影响加载的其他shp，导致光线变黑)
        building1_prjnode->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源
        root->addChild(building1_prjnode.get());
    }

    unsafebuilding->setName("unsafebuilding");  //Node必须要有值，不然直接设置Name会报错
    legendroot->addChild(unsafebuilding);


    //读取安全建筑shp(用Geode添加)
    //加载安全房屋
    const char* safepath="E:/ChuanJuDisasterModel/testdata/building_WithZ/building_prj.shp";
//    osg::ref_ptr<osg::Geode> building_prj;  //用于创建图例
    osg::ref_ptr<osg::Node> safebuilding=osgDB::readNodeFile("E:/ChuanJuDisasterModel/testdata/building_WithZ/building_prj.shp");  //用于创建图例，Node必须要有值，不然直接设置Name会报错
    safelist2=gdal_read_polygonshp(safepath);  //保存shp坐标点
    std::list<std::list<Point3D>>::iterator buildingit2;
    Drawhouse *safehouse=new Drawhouse();
    //设置颜色
    osg::ref_ptr<osg::Vec4Array> safehousecolors = new osg::Vec4Array;
    //添加数据
    safehousecolors->push_back(osg::Vec4(0.0, 255.0, 0.0, 1.0));
    for ( buildingit2=safelist2.begin() ; buildingit2 != safelist2.end(); buildingit2++ )
    {
        safelist=*buildingit2;
        osg::ref_ptr<osg::Geode> building_prjnode=safehouse->Drawsamplehouse(safelist,safehousecolors);
        //关闭光源(必须添加，不然会影响加载的其他shp，导致光线变黑)
        building_prjnode->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源
        root->addChild(building_prjnode.get());
    }

    safebuilding->setName("safebuilding");   //Node必须要有值，不然直接设置Name会报错
    legendroot->addChild(safebuilding);


    //添加布告板
    osg::ref_ptr<osg::PositionAttitudeTransform> mPosAttTrsf = new osg::PositionAttitudeTransform;
    mPosAttTrsf->setPosition(osg::Vec3(471549.0f, 3437718.0f, 3800.0f));  //设置布告板位置
    mPosAttTrsf->setScale(osg::Vec3(50.0f,50.0f,50.0f));

    //读取图片，用于贴图（osg自带的资源）
    osg::ref_ptr<osg::Image> mImage = osgDB::readImageFile("E:/ChuanJuDisasterModel/testdata/picture/school.png");    //加载学校
    osg::ref_ptr<osg::Node> mNode = CreateBillboard(mImage);
    mPosAttTrsf->addChild(mNode);
    root->addChild(mPosAttTrsf);

    mNode->setName("School");   //Node必须要有值，不然直接设置Name会报错
    legendroot->addChild(mNode);

    //读取shp添加布告板图片
    list<Point3D> pPoint;
    const char* testpointshp="E:/ChuanJuDisasterModel/testdata/School/School_prj.shp";
    osg::ref_ptr<osg::Node> Hospital;   //用于创建图例
    pPoint=gdal_read_pointshp(testpointshp);  //保存shp坐标点
    list<Point3D>::iterator it;
    for ( it=pPoint.begin(); it != pPoint.end(); it++)
    {
        BuildBillBoard *board=new BuildBillBoard();
        osg::ref_ptr<osg::PositionAttitudeTransform> mPosAttTrsf = new osg::PositionAttitudeTransform;
        mPosAttTrsf->setPosition(osg::Vec3(it->X, it->Y, it->Z));  //设置布告板位置
        mPosAttTrsf->setScale(osg::Vec3(50.0f,50.0f,50.0f));

        //读取图片，用于贴图（osg自带的资源）
        osg::ref_ptr<osg::Image> mImage = osgDB::readImageFile("E:/ChuanJuDisasterModel/testdata/picture/Hospital.png");   //加载医院
        osg::ref_ptr<osg::Node> School_prjnode = board->CreateBillboard(mImage);
        School_prjnode->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);
        mPosAttTrsf->addChild(School_prjnode);
        root->addChild(mPosAttTrsf);

        Hospital=board->CreateBillboard(mImage);   //Node必须要有值，不然直接设置Name会报错

    }

    Hospital->setName("Hospital");  //Node必须要有值，不然直接设置Name会报错
    legendroot->addChild(Hospital);
	
	//创建图例
    osg::ref_ptr<osg::Node> LegendNode=CreateLegend(legendroot);
    root->addChild(LegendNode);
	
	return returnroot;
}
	

