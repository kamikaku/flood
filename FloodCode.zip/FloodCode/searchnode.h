﻿#ifndef SEARCHNODE_H
#define SEARCHNODE_H

#include <osg/Node>
#include <osg/Group>
#include <iostream>
class SearchNode
{
public:
    SearchNode();
    int return_Nodeindex(osg::Group* group,std::string name);
};

#endif // SEARCHNODE_H
