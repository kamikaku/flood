#ifndef GETCAMERAPOSE_H
#define GETCAMERAPOSE_H

#include <QDialog>
#include "mainwindow.h"

#include <QTextEdit>

using namespace std;

namespace Ui {
class GetCameraPose;
}

class GetCameraPose : public QDialog
{
    Q_OBJECT

public:
    explicit GetCameraPose(QWidget *parent = 0);
    ~GetCameraPose();

private:
    vector<double> pvector;

public slots:
    void Getagrv(vector<double> pVectorParameters);   //其他窗体需要调用因此需要设置为公有信号槽

private:
    Ui::GetCameraPose *ui;
};

#endif // GETCAMERAPOSE_H
