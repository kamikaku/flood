﻿#include "createscalarbar.h"

CreateScalarBar::CreateScalarBar()
{

}

//std::string string_To_UTF8(const std::string & str)
//{
//int nwLen = MultiByteToWideChar(CP_ACP, 0, str.c_str(), -1, NULL, 0);

//wchar_t * pwBuf = new wchar_t[nwLen + 1];//一定要加1，不然会出现尾巴
//ZeroMemory(pwBuf, nwLen * 2 + 2);

//::MultiByteToWideChar(CP_ACP, 0, str.c_str(), str.length(), pwBuf, nwLen);

//int nLen = ::WideCharToMultiByte(CP_UTF8, 0, pwBuf, -1, NULL, NULL, NULL, NULL);

//char * pBuf = new char[nLen + 1];
//ZeroMemory(pBuf, nLen + 1);

//::WideCharToMultiByte(CP_UTF8, 0, pwBuf, nwLen, pBuf, nLen, NULL, NULL);

//std::string retStr(pBuf);

//delete []pwBuf;
//delete []pBuf;

//pwBuf = NULL;
//pBuf  = NULL;

//return retStr;
//}

//创建自定义颜色集
osg::ref_ptr<osg::Node> CreateScalarBar::createScalarBar(osg::Vec4 shallowColor, osg::Vec4 deepColor,int minValue,int maxValue)
{
    bool vertical=false;   //false：表示图例水平布局；  true：表示图例垂直布局
    vector<osg::Vec4> cs;
//    cs.push_back(osg::Vec4(1.0f, 0.89f, 0.76f, 1.0f));   // 浅
//    cs.push_back(osg::Vec4(0.94f, 0.46f, 0.02f, 1.0f));   // 深

    cs.push_back(shallowColor);   // 浅
    cs.push_back(deepColor);   // 深
    float mRange = maxValue;
    float minR = minValue;
    ColorRange* cr = new ColorRange(minR, mRange, cs);
    ScalarBar* sb = new ScalarBar(30, 6, cr, "",
            vertical ? ScalarBar::VERTICAL : ScalarBar::HORIZONTAL,
            0.1f);

    if (!vertical)
    {
        sb->setPosition(osg::Vec3(0.5f, 0.5f, 0));
    }

    osgSim::ScalarBar::TextProperties tp;
    tp._characterSize=0.04;
    tp._fontFile = "fonts/times.ttf";

//    std::string s= string_To_UTF8("泥深");
//    sb->setTitle(s);
    sb->setWidth(0.8);
    osg::StateSet * stateset = sb->getOrCreateStateSet();
    stateset->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

    stateset->setMode(GL_DEPTH_TEST, osg::StateAttribute::OFF);
    stateset->setRenderBinDetails(11, "RenderBin");

    osg::MatrixTransform * modelview = new osg::MatrixTransform;
    modelview->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
    osg::Matrixd matrix(osg::Matrixd::scale(700, 650, 600) * osg::Matrixd::translate(300, -350, 0));
    modelview->setMatrix(matrix);
    modelview->addChild(sb);

    osg::Projection * projection = new osg::Projection;
    projection->setMatrix(osg::Matrix::ortho2D(0, 1280, 0, 1024)); // or whatever the OSG window res is
    projection->addChild(modelview);

    return projection; //make sure you delete the return sb line


}

//创建颜色集HUD
osg::ref_ptr<osg::Node> CreateScalarBar::createScalarBar_HUD()
{
    osgSim::ScalarBar * geode = new osgSim::ScalarBar;
    osgSim::ScalarBar::TextProperties tp;
    tp._fontFile = "fonts/times.ttf";
    geode->setTextProperties(tp);
    osg::StateSet * stateset = geode->getOrCreateStateSet();
    stateset->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

    stateset->setMode(GL_DEPTH_TEST, osg::StateAttribute::OFF);
    stateset->setRenderBinDetails(11, "RenderBin");  // 表示绘制文字显示在屏幕最前端

    osg::MatrixTransform * modelview = new osg::MatrixTransform;
    modelview->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
    osg::Matrixd matrix(osg::Matrixd::scale(1000, 1000, 1000) * osg::Matrixd::translate(120, 10, 0));
    modelview->setMatrix(matrix);
    modelview->addChild(geode);

    osg::Projection * projection = new osg::Projection;
    projection->setMatrix(osg::Matrix::ortho2D(0, 1280, 0, 1024)); // or whatever the OSG window res is
    projection->addChild(modelview);

    return projection; //make sure you delete the return sb line
}



