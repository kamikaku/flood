﻿#include "blinkingdisplay.h"

BlinkingDisplay::BlinkingDisplay()
{

}

//创建Sharder
void BlinkingDisplay::createShader(osg::StateSet &ss)
{
    osg::ref_ptr<osg::Shader> vertShader = new osg::Shader(osg::Shader::VERTEX, vertSource);
    osg::ref_ptr<osg::Shader> fragShader = new osg::Shader(osg::Shader::FRAGMENT, fragSource);

    osg::ref_ptr<osg::Program> program = new osg::Program;
    program->addShader(vertShader.get());
    program->addShader(fragShader.get());

    osg::ref_ptr<osg::Uniform> mainColor = new osg::Uniform("mainColor", osg::Vec4(1.0, 0.0, 0.0, 1.0));//这个部分的颜色是闪烁部分的颜色值。
    mainColor->setUpdateCallback(new ColorCallback);

    ss.addUniform(mainColor.get());
    ss.setAttributeAndModes(program.get());
}
