﻿#ifndef XMLDOC_H
#define XMLDOC_H

#include <QtXml/QDomDocument>
#include <QFile>
#include <QTextStream>
#include <QTextCodec>

#include <iostream>
#include "filemanagement.h"
#include "globalvar.h"

extern std::list<FileManage> BindingFiles;
extern QString NOW_NODENAME;

using namespace std;

class XMLDoc
{
public:
    XMLDoc();

    vector<string> readXml(string str);

    vector<string> readXmlFnD(string str);


private:
    QString fileName;

};

#endif // XMLDOC_H
