﻿#ifndef PICKHANDLE_H
#define PICKHANDLE_H
#include <osgDB/ReadFile>
#include <osgViewer/Viewer>
#include <osg/Node>
#include <QDebug>
#include <iostream>
#include <osg/MatrixTransform>
#include <osg/PositionAttitudeTransform>
extern std::vector<float> coord;
class PickHandle:public osgGA::GUIEventHandler
{
public:
    virtual bool handle(const osgGA::GUIEventAdapter& ea, osgGA::GUIActionAdapter& aa);
    osgViewer::View* view;
    void pick(float x,float y);
public:
    float Wx;
    float Wy;
    float Wz;



};


#endif // PICKHANDLE_H
