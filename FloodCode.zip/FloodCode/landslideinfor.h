﻿#ifndef LANDSLIDEINFOR_H
#define LANDSLIDEINFOR_H
#define NOMINMAX
#include "landslideform.h"
#include <osgFX/Outline>
#pragma once

#include <osg/Node>
#include <osg/Geode>
#include <osg/Geometry>
#include <osg/Group>
#include <osg/Camera>
#include <osg/MatrixTransform>
#include <osg/PositionAttitudeTransform>
#include <osg/Sequence>
#include <osgParticle/ParticleSystem>
#include <osgParticle/Particle>
#include <osgParticle/ModularEmitter>
#include <osgParticle/MultiSegmentPlacer>
#include <osgParticle/ModularProgram>
#include <osgParticle/AccelOperator>
#include <osgParticle/FluidFrictionOperator>
#include <osgParticle/ParticleSystemUpdater>
#include <osgParticle/PrecipitationEffect>

#include "gdal.h"
#include "gdal_priv.h"
#include "ogrsf_frmts.h"
#include "gdal_version.h"

#include "DamageDescription.h"  //付林
#include "drawgeometry.h"  //小郭
#include "globalvar.h"
#include "xmldoc.h"
extern std::list<FileManage> BindingFiles;
extern QString NOW_NODENAME;

class LandslideInfor
{
public:
    LandslideInfor();

    void createText(osgText::Text& textObject,float size, const osg::Vec3& pos,const osg::Vec4& color);  //创建字体
    osg::ref_ptr<osg::Node> eventDescription();  //灾害事件描述
    osg::ref_ptr<osg::Geode> causeDescription();  //灾害成因描述
    osg::ref_ptr<osg::Node> historyDescription(int num);  //历史灾害描述
    osg::ref_ptr<osg::Node> inforDescription();  //滑坡信息描述
    osg::ref_ptr<osg::Node> rainEffect();  //使整个场景下雨

    //创建箭头的路径动画
    osg::ref_ptr<osg::AnimationPath> createAnimationPath(const osg::Vec3& ptStart,const osg::Vec3 &ptEnd,float timeBegin, float timeEnd);
    osg::ref_ptr<osg::Node> CreateArrow(); //创建箭头
    osg::ref_ptr<osg::Node> arrowDisplay(int num); //滑坡箭头展示，返回滑坡箭头

    osg::ref_ptr<osg::Group> infoDisplay(int num); //滑坡信息展示：滑坡高度、宽度、土方量等
    osg::ref_ptr<osg::Group> damageDescription(int index);  //受损情况描述,包括建筑物、河流、道路等

    Point3D gdal_read_polylineshp(const char *path); //读取线的范围坐标

    osg::ref_ptr<osg::Camera> CreateInfoHUD();
    osg::ref_ptr<osg::Camera> CreateInfoHUD(int num);
    osg::ref_ptr<osg::Node> CreateInfoPos(int num);
    osg::ref_ptr<osg::Node> CreateInfoPos_withline(int number,osg::Vec3 posline);
    //string2UTF-8
    std::wstring string_To_wstring(string pStr);
};

#endif // LANDSLIDEINFOR_H
