﻿#include "shapemark.h"

TextMark::TextMark(float X,float Y,float Z,std::string t,osg::Vec4 c,float S){
    x = X;
    y = Y;
    z = Z;
    text = t;
    color = c;
    size = S;
}

TextMark::TextMark(void){

}

//读xml文件存入数组
void ShapeMark::read_text(std::string path){

    QString qpath = QString::fromStdString(path);
    //打开或创建文件
        QFile file(qpath);
        if(!file.open(QFile::ReadOnly)){
            return;
        }
        QDomDocument doc;
        if(!doc.setContent(&file))
        {
            file.close();
            return;
        }
        file.close();

        QDomElement root=doc.documentElement(); //返回根节点
//        qDebug()<<root.nodeName();
        QDomNode node=root.firstChild(); //获得第一个子节点

        while(!node.isNull())  //如果节点不空
        {
            QDomElement element = node.toElement();

            if(!element.isNull()){
                QDomNode childnode = element.firstChild();
                TextMark *tk = new TextMark();
                int inx=0;
                while(!childnode.isNull()){
                    QDomElement e = childnode.toElement();

                    if(!e.isNull()){
                        if(element.tagName().toStdString()=="Mark"){
                            std::string txt="";
                            if(e.tagName().toStdString()=="text"){
//                            QString qs = e.attributeNode("textstr").value();
//                            txt = std::string((const char *)qs.toLocal8Bit().constData());
                            tk->text = e.attributeNode("textstr").value().toStdString();
                            }
//                          std::string txt = e.attributeNode("textstr").value().toStdString();
                            float x=0;
                            float y=0;
                            float z=0;
                           if(e.tagName().toStdString()=="pos"){
                           x = e.attributeNode("X").value().toFloat();
                           y = e.attributeNode("Y").value().toFloat();
                           z = e.attributeNode("Z").value().toFloat();
                           tk->x=x;
                           tk->y=y;
                           tk->z=z;
                            }

                           osg::Vec4 col;
                           if(e.tagName().toStdString()=="color"){
                          col = osg::Vec4(e.attributeNode("r").value().toFloat(),e.attributeNode("g").value().toFloat(),e.attributeNode("b").value().toFloat(),e.attributeNode("a").value().toFloat());
                          tk->color=col;
                        }
                           float s;
                           if(e.tagName().toStdString()=="size"){
                           s = e.attributeNode("S").value().toFloat();
                           tk->size=s;
                           }
                        inx++;
                        }
                    }
                    if(inx==4){
                        allMarks.push_back(*tk);
                        inx=1;
                    }
                    childnode = childnode.nextSibling();
                }
            }
            node = node.nextSibling();
        }

}


osg::ref_ptr<osg::Node> ShapeMark::retrun_text(){

    osg::ref_ptr<osg::Group> group = new osg::Group;
//    osg::ref_ptr<osg::Geode> geode = new osg::Geode;
     if(!this->allMarks.empty()){

         for(int i=0;i<allMarks.size();i++){
             osg::ref_ptr<osg::Geode> geode = new osg::Geode;
             //展示信息
             osg::ref_ptr<osgText::Text> text = new osgText::Text;
             //设置字体
             text->setFont("fonts/simhei.ttf");
             //设置文字显示的位置
             text->setPosition(osg::Vec3(allMarks[i].x,allMarks[i].y,allMarks[i].z+200));
             //文字颜色
             text->setColor(allMarks[i].color);
             text->setCharacterSize(allMarks[i].size);
            //文字内容
             std::string info = allMarks[i].text;
             const char* infoc = info.c_str();
             QTextCodec* code = QTextCodec::codecForName("UTF-8");
             QString qstr = QObject::tr(infoc);
             std::string str = code->fromUnicode(qstr).data();
             text->setText(str, osgText::String::ENCODING_UTF8);
             text->setAxisAlignment(osgText::Text::SCREEN);

             geode->addDrawable(text.get());
             group->addChild(geode.get());

         }
     }

     return group.get();
}
