﻿#ifndef DEBRISFLOWFEATURE_H
#define DEBRISFLOWFEATURE_H

#pragma execution_character_set("utf-8")

#include <QtCore/QTextStream>
#include <QtCore/QFile>
#include <QtCore/QIODevice>
#include <QColor>


#include <osgDB/ReadFile>
#include <osgViewer/Viewer>
#include <osg/Geode>
#include <osg/Depth>
#include <osgText/Text>
#include <osgGA/TrackballManipulator>
#include <osg/Camera>
#include <QTextCodec>
#include <osg/Group>
#include <QString>
#include <QObject>

#include "shapemark.h"
#include "shpclass.h"
#include "readshpdialog.h"

class Debrisflowfeature
{
public:
    Debrisflowfeature();
//    float discharge = 0.0f;//流量
    float velocity = 0.0f; //流速
    float runTime = 0.0f; //演进时间
//    float depth = 0.0f; //泥深
    int shallow=0;//最浅
    int deep = 10;//最深
public:
    osg::ref_ptr<osg::Camera> CreateHUD(); //创建HUD进行显示

    void output_TO_TXT(std::string path); //输出为txt文件

    void input_from_TXT(std::string path); //读取txt文件

    osg::ref_ptr<osg::Group> return_Signs();
    osg::ref_ptr<osg::Camera> CreateSD();
};

#endif // DEBRISFLOWFEATURE_H
