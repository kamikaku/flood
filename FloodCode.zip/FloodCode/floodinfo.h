﻿#ifndef FLOODINFO_H
#define FLOODINFO_H

#include <osg/Node>
#include <osg/Geode>
#include <osg/Geometry>
#include <osg/Group>
#include <osg/Camera>
#include <osg/MatrixTransform>
#include <osg/PositionAttitudeTransform>
#include <osg/Sequence>
#include <osgParticle/ParticleSystem>
#include <osgParticle/Particle>
#include <osgParticle/ModularEmitter>
#include <osgParticle/MultiSegmentPlacer>
#include <osgParticle/ModularProgram>
#include <osgParticle/AccelOperator>
#include <osgParticle/FluidFrictionOperator>
#include <osgParticle/ParticleSystemUpdater>
#include <osgParticle/PrecipitationEffect>
#include <osgText/Text>
#include <osg/Material>
#include <osgDB/ReadFile>
#include <osg/Billboard>

class floodInfo
{
public:
    floodInfo();
    osg::ref_ptr<osg::Node> rainEffect();  //使整个场景下雨
    osg::ref_ptr<osg::Geode> showText(std::string strt,osg::Vec3 pos,float size);
    void createText(osgText::Text &textObject, float size, const osg::Vec3 &pos, const osg::Vec4 &color);
    osg::ref_ptr<osg::Camera> CreateInfoHUD(std::string strt);
    std::wstring string_To_wstring(std::string pStr);
    osg::ref_ptr<osg::Node> drawImage(std::string path);
    osg::ref_ptr<osg::Node> turn_Billboard(osg::Node* node,osg::Vec3 position,osg::Vec3 scale);


};

#endif // FLOODINFO_H
