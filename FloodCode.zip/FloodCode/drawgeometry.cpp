﻿#include "drawgeometry.h"
#include "renderclass.h"

DrawGeometry::DrawGeometry()
{

}

osg::ref_ptr<osg::Node> DrawGeometry::turn_Billboard(osg::Node* node,osg::Vec3 position,osg::Vec3 scale){

    osg::ref_ptr<osg::Group> g= new osg::Group();
    osg::ref_ptr<osg::Billboard> billboard = new osg::Billboard();
    billboard->setMode(osg::Billboard::POINT_ROT_EYE);
    billboard->addDrawable(node->asDrawable());

    g->addChild(billboard.get());
    osg::ref_ptr<osg::PositionAttitudeTransform> trans =new osg::PositionAttitudeTransform();
    trans->setPosition(position);
    trans->setScale(scale);
    trans->addChild(g.get());
//    osg::ref_ptr<osg::AutoTransform> at = new osg::AutoTransform();
//    at->setPosition(position);
//    at->setAutoRotateMode(osg::AutoTransform::ROTATE_TO_SCREEN);
//    at->addChild(g.get());
    return trans.get();

}


osg::ref_ptr<osg::Node> DrawGeometry::AutoTrans(osg::Node* node,osg::Vec3 position)
{
    osg::ref_ptr<osg::AutoTransform> at = new osg::AutoTransform();
    at->setAutoRotateMode(osg::AutoTransform::ROTATE_TO_SCREEN);
    at->setPosition(position);
    at->addChild(node);
    return at.get();

}



osg::ref_ptr<osg::Node> DrawGeometry::Background(float dx,float dz,osg::Vec3 center){


     osg::Vec4Array* colors= new osg::Vec4Array;              //创建一个Vec4Array对象，存放颜色信息
    osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry();
    osg::ref_ptr<osg::Vec3Array> points = new osg::Vec3Array();
//    points->push_back(osg::Vec3(0.0f,0.0f,0.0f));
//    points->push_back(osg::Vec3(dz,0.0f,0.0f));
//    points->push_back(osg::Vec3(dz,0.0f,dx));
//    points->push_back(osg::Vec3(0.0f,0.0f,dx));
    points->push_back(osg::Vec3(-dz/2,0.0f,-dx/2));
    points->push_back(osg::Vec3(dz/2,0.0f,-dx/2));
    points->push_back(osg::Vec3(dz/2,0.0f,dx/2));
    points->push_back(osg::Vec3(-dz/2,0.0f,dx/2));
//    points->push_back(osg::Vec3(0.0f,-dz/2,-dx/2));
//    points->push_back(osg::Vec3(0.0f,dz/2,-dx/2));
//    points->push_back(osg::Vec3(0.0f,dz/2,dx/2));
//    points->push_back(osg::Vec3(0.0f,-dz/2,dx/2));

    colors->push_back(osg::Vec4f(1.0f, 0.0f, 0.0f, 0.5f));
    colors->push_back(osg::Vec4f(1.0f, 0.0f, 0.0f, 0.5f));
    colors->push_back(osg::Vec4f(1.0f, 0.0f, 0.0f, 0.5f));
    colors->push_back(osg::Vec4f(1.0f, 0.0f, 0.0f, 0.5f));

    geometry->setVertexArray((points.get()));
    geometry->setColorArray(colors);//设置颜色数组
    geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS, 0, 4));
    osg::Vec3 p(center.x()-10,center.y()-20,center.z()-10);

    osg::ref_ptr<osg::Group> gp = turn_Billboard(geometry.get(),p,osg::Vec3(1.0f,1.0f,1.0f))->asGroup();//AutoTrans(geometry.get(),p)->asGroup();

    return gp.get();

}


osg::ref_ptr<osg::Node> DrawGeometry::Drawtext(const char* info,osg::Vec3 position){

    osg::ref_ptr<osgText::Text> text = new osgText::Text; //设置text
    osg::ref_ptr<osgText::Font> font = new osgText::Font();//设置字体
//    font = osgText::readFontFile("fonts/simhei.ttf");
    font = osgText::readFontFile("fonts/msyh.ttc");
    text->setFont(font);
    //转换字符格式，使中文不再是乱码
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("GBK"));  //setCodecForTr(QTextCodec::codecForName("GBK"));
    //const char* xxx = "堆积体最大厚度100米\n 平均厚度40米\n 堆积面积78万平方米";
    QTextCodec* code = QTextCodec::codecForName("UTF-8");
    QString qstr = QObject::tr(info);
    std::string str = code->fromUnicode(qstr).data();
    text->setText(str, osgText::String::ENCODING_UTF8);

    //text->setAutoRotateToScreen(true);
    text->setAxisAlignment(osgText::Text::SCREEN);
    int num = std::count(str.begin(),str.end(),'\n')+1;//获取换行符个数，以自动设置边框宽度

    float tsize = 50.0f;
    text->setCharacterSize(tsize);
    text->setAlignment(osgText::Text::CENTER_CENTER); //设置居中

    osg::BoundingBox textBox = text->getBoundingBox(); //获取包围盒，用来画矩形
    osg::Vec3 pos;
    pos.set(textBox.xMax() - textBox.xMin(), textBox.yMax() - textBox.yMin(), textBox.zMax() - textBox.zMin());


    //text->setBackdropColor(osg::Vec4(1.0f,0.0f,0.0f,1.0f));
    text->setPosition(position);//(osg::Vec3(472173.895f, 3438822.291f, 4300.00f));设置文字位置
    //osg::Vec3 wordMark = text->getBound().center()*osg::computeLocalToWorld(text->getParentalNodePaths()[0]);  //滑坡文字外包矩形
    text->setColor(osg::Vec4(0.0f,0.0f,0.0f,1.0f));//设置文字颜色

    osg::BoundingBox textBox1 = text->getBoundingBox();
    osg::Vec3 center = textBox1.center();

//    text->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//    text->setBoundingBoxColor(osg::Vec4(1.0f, 1.0f, 0.0f, 0.5f));
//    text->setBoundingBoxMargin(2.0f);


     //text->setAxisAlignment(osgText::Text::SCREEN);



    osg::ref_ptr<osg::Geode> geode = new osg::Geode();
    geode->addDrawable(text.get());
    osg::ComputeBoundsVisitor boundVisitor;
    geode->accept(boundVisitor);

    osg::ref_ptr<osg::Group> gp = new osg::Group();
    gp->addChild(geode.get());
    gp->addChild(Background(num*tsize*1.5,pos.z()*1.2,center));

    return gp.get();
}


void TextStyle(osgText::Text &textObject){

//    textObject.setColor(osg::Vec4( 1, 1, 1, 1));  //字体颜色
//    textObject.setBackdropType(osgText::Text::OUTLINE);//对文字进行描边
//    textObject.setBackdropColor(osg::Vec4(1.0,0.0,0.0,1.0));//描边颜色
    textObject.setColor(osg::Vec4( 1.0, 1.0, 0.0, 1.0));  //字体颜色
    textObject.setBackdropType(osgText::Text::OUTLINE);//对文字进行描边
    textObject.setBackdropColor(osg::Vec4(1.0,0.0,0.0,0.5));//描边颜色
    textObject.setAutoRotateToScreen(true);
}

void TextType(osgText::Text &textObject, float size, const osg::Vec3 &pos, const osg::Vec4 &color,osgText::Text::Layout lay)
{
    textObject.setFont("fonts/msyh.ttc");//设置字体格式
    textObject.setCharacterSize(size);//字体大小
//    textObject.setColor( osg::Vec4( 0, 0, 0, 1));  //字体颜色
    textObject.setColor(color);  //字体颜色
    textObject.setPosition(pos);
    textObject.setLayout(lay);//文字显示方向
    //textObject.setAutoRotateToScreen(true);//跟随视角不断变化

}

void TextType(osgText::Text &textObject, float size, const osg::Vec3 &pos, const osg::Vec4 &color)
{
    textObject.setFont("fonts/msyh.ttc");//设置字体格式
    textObject.setCharacterSize(size);//字体大小
//    textObject.setColor( osg::Vec4( 0, 0, 0, 1));  //字体颜色
    textObject.setColor(color);  //字体颜色
    textObject.setPosition(pos);
    //textObject.setAutoRotateToScreen(true);//跟随视角不断变化

}

void TextStyle_Bound(osgText::Text &textObject){

//    textObject.setColor(osg::Vec4( 1, 1, 1, 1));
//    textObject.setBackdropType(osgText::Text::OUTLINE);//对文字进行描边
//    textObject.setBackdropColor(osg::Vec4(1.0f,0.0f,0.0f,1.0f));//描边颜色

    textObject.setColor(osg::Vec4( 1.0, 1.0, 1.0, 1.0));
    textObject.setBackdropType(osgText::Text::OUTLINE);//对文字进行描边
    textObject.setBackdropColor(osg::Vec4(1.0f,0.7f,0.3f,0.5f));//描边颜色

    //textObject.setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
    textObject.setDrawMode(osgText::Text::TEXT | osgText::Text::BOUNDINGBOX);//添加文字边框
    textObject.setBoundingBoxColor(osg::Vec4(0.0f,238.0f,238.0f,1.0f));


}


std::string Return_str(const char* c){
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("GBK"));

    QTextCodec* code = QTextCodec::codecForName("UTF-8");
    QString qstr = QObject::tr(c);
    std::string str = code->fromUnicode(qstr).data();
    return str;
}


osg::ref_ptr<osg::Node> DrawGeometry::Textinfo(const char* c,osg::Vec3 pos,osg::Quat quat,osgText::Text::Layout lay,float scale){

    osg::ref_ptr<osgText::Text> text = new osgText::Text();
    //const char* xxx = "平均高度 40米";
    text->setText(Return_str(c), osgText::String::ENCODING_UTF8);
    TextType(*text,scale,pos,osg::Vec4(0.0f,0.0f,1.0f,1.0f),lay);
//    osg::Quat quat( (osg::PI/3), osg::Vec3d(1.0, 0.0, 0.0),
//                    -(osg::PI)/18, osg::Vec3d(0.0, 1.0, 0.0),
//                    (osg::PI)/12, osg::Vec3d(0.0, 0.0, 1.0));

    text->setRotation(quat);
    TextStyle(*text);

    osg::ref_ptr<osg::Geode> geode = new osg::Geode();
    geode->addDrawable(text.get());
    return geode.get();


}

osg::ref_ptr<osg::Node> DrawGeometry::Textinfo(const char* c,osg::Vec3 pos,osg::Quat quat,float scale,bool isBound ){

    osg::ref_ptr<osgText::Text> text = new osgText::Text();

    text->setText(Return_str(c), osgText::String::ENCODING_UTF8);
    TextType(*text,scale,pos,osg::Vec4(0.0f,0.0f,1.0f,1.0f));
    text->setRotation(quat);
    if(!isBound){
    TextStyle(*text);
    }
    else{
        TextStyle_Bound(*text);
    }

    osg::ref_ptr<osg::Geode> geode = new osg::Geode();
    geode->addDrawable(text.get());
    return geode.get();

}

osg::ref_ptr<osg::Node> DrawGeometry::Textinfo(string c, osg::Vec3 pos, osg::Quat quat, float scale, bool isBound)
{
    osg::ref_ptr<osgText::Text> text = new osgText::Text();
    wstring str=string_To_wstring(c);
    text->setText(str.c_str());
    TextType(*text,scale,pos,osg::Vec4(1.0f,1.0f,0.0f,1.0f));
//    text->setRotation(quat);
//    text->setAutoRotateToScreen(true);
    if(!isBound){
    TextStyle(*text);
    }
    else{
        TextStyle_Bound(*text);
    }

    osg::ref_ptr<osg::Geode> geode = new osg::Geode();
    geode->addDrawable(text.get());
    return geode.get();
}
//=====================双向箭头=============================
osg::ref_ptr<osg::Node> DrawGeometry::DoubleArrow(osg::Vec3 pos,osg::Quat quat,osg::Vec3 scale){

//       QString EPath =  QCoreApplication::applicationDirPath();
//       std::string path = EPath.toStdString()+"/Data/images/doublearrow.png";
//       std::string path = return_ViewTree_Path(NOW_NODENAME).toStdString();
//       path += "/images/doublearrow.png";

    XMLDoc *pXmlDoc=new XMLDoc();
    vector<string> pVectorDoubleArrowPicture=pXmlDoc->readXml("DoubleArrowPicture");
    std::string path=pVectorDoubleArrowPicture[0];

       osg::ref_ptr<osg::Image> image =osgDB::readImageFile(path);
            //创建四边形
            osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry();
            osg::ref_ptr<osg::Geode> geode = new osg::Geode();

            //设置顶点
            osg::ref_ptr<osg::Vec3Array> v = new osg::Vec3Array();
//            v->push_back(osg::Vec3(0.0f,-0.5f,-0.5f));
//            v->push_back(osg::Vec3(0.0f,0.5f,-0.5f));
//            v->push_back(osg::Vec3(0.0f,0.5f,0.5f));
//            v->push_back(osg::Vec3(0.0f,-0.5f,0.5f));
            v->push_back(osg::Vec3(0.0f,-0.25f,-0.5f));
            v->push_back(osg::Vec3(0.0f,0.25f,-0.5f));
            v->push_back(osg::Vec3(0.0f,0.25f,0.5f));
            v->push_back(osg::Vec3(0.0f,-0.25f,0.5f));

            geometry->setVertexArray(v.get());

            //设置法线
            osg::ref_ptr<osg::Vec3Array> normal = new osg::Vec3Array();
            normal->push_back(osg::Vec3(1.0f,0.0f,0.0f)^osg::Vec3(0.0f,0.0f,1.0f));
//            normal->push_back(osg::Vec3(0.0f,1.0f,0.0f)^osg::Vec3(0.0f,0.0f,1.0f));

            geometry->setNormalArray(normal.get());
            geometry->setNormalBinding(osg::Geometry::BIND_OVERALL);

            //设置纹理坐标
            osg::ref_ptr<osg::Vec2Array> vt = new osg::Vec2Array();
            vt->push_back(osg::Vec2(0.0f,0.0f));
            vt->push_back(osg::Vec2(1.0f,0.0f));
            vt->push_back(osg::Vec2(1.0f,1.0f));
            vt->push_back(osg::Vec2(0.0f,1.0f));


            geometry->setTexCoordArray(0,vt.get());
            geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS,0,4));

            if(image.get()){
                //属性对象
                osg::ref_ptr<osg::StateSet> stateset = new osg::StateSet();

                //创建一个Texture2D属性对象
                osg::ref_ptr<osg::Texture2D> texture = new osg::Texture2D();

                //关联image
                texture->setImage(image.get());


                //关联Texture2D纹理对象，第三个参数默认为ON
                stateset->setTextureAttributeAndModes(0,texture,osg::StateAttribute::ON);

                //启用混合
                stateset->setMode(GL_BLEND,osg::StateAttribute::ON);
                //关闭光照
                stateset->setMode(GL_LIGHTING,osg::StateAttribute::OFF);


                geometry->setStateSet(stateset.get());
            }
            osg::Material *material = new osg::Material;
            material->setDiffuse(osg::Material::FRONT, osg::Vec4(1.0, 1.0, 1.0, 1.0));
            material->setAmbient(osg::Material::FRONT, osg::Vec4(1.0, 1.0, 1.0, 1.0));
            material->setShininess(osg::Material::FRONT, 90.0);
            geode->getOrCreateStateSet()->setAttribute(material);

            geode->addDrawable(geometry.get());

//            geode->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::OFF| osg::StateAttribute::OVERRIDE);
//            geode->getOrCreateStateSet()->setMode(GL_RESCALE_NORMAL, osg::StateAttribute::ON);

       return geode.get();

}


//创建缩放动画
osg::ref_ptr<osg::AnimationPath> DrawGeometry::createScaleAni(osg::Vec3 pos,osg::Quat quat,osg::Vec3 scale){

    osg::ref_ptr<osg::AnimationPath> animationpath = new osg::AnimationPath();

    animationpath->setLoopMode(osg::AnimationPath::NO_LOOPING);

    animationpath->insert(0,osg::AnimationPath::ControlPoint(pos,quat,osg::Vec3(1,1,0.5)));

    animationpath->insert(1,osg::AnimationPath::ControlPoint(pos,quat,scale));

 return animationpath.get();
}


osg::ref_ptr<osg::Node> DrawGeometry::return_DArrow(osg::Vec3 pos,osg::Quat quat,osg::Vec3 scale){

     osg::ref_ptr<osg::Node> Darrow = DoubleArrow(pos,quat,scale);

     osg::ref_ptr<osg::PositionAttitudeTransform> pat = new osg::PositionAttitudeTransform();
     osg::ref_ptr<osg::AnimationPath> ap = createScaleAni(pos,quat,scale);
     pat->setUpdateCallback(new osg::AnimationPathCallback(ap.get()));
     pat->addChild(Darrow);

     return pat.get();
}


osg::ref_ptr<osg::Node> DrawGeometry::Return_G(int num){

    osg::ref_ptr<osg::Group> group = new osg::Group();

    XMLDoc *pXmlDoc=new XMLDoc();


    //标注堰塞湖信息
    osg::ref_ptr<osg::Node> Ytext;
    vector<string> pVectorCamera2BarrierLake=pXmlDoc->readXml("Camera2");
    if(pVectorCamera2BarrierLake.size()==0)
    {
        return NULL;
    }
    if(pVectorCamera2BarrierLake[15]!="" && pVectorCamera2BarrierLake[9]!="")    //判断如果写入了堰塞湖信息则添加文字信息
    {
            osg::Vec3 infoy_pos(atof(const_cast<const char *>(pVectorCamera2BarrierLake[9].c_str())), atof(const_cast<const char *>(pVectorCamera2BarrierLake[10].c_str())), atof(const_cast<const char *>(pVectorCamera2BarrierLake[11].c_str())));
        osg::Quat infoy_quat( osg::DegreesToRadians(atof(const_cast<const char *>(pVectorCamera2BarrierLake[12].c_str()))), osg::Vec3d(1.0, 0.0, 0.0),
                osg::DegreesToRadians(atof(const_cast<const char *>(pVectorCamera2BarrierLake[13].c_str()))), osg::Vec3d(0.0, 1.0, 0.0),
                osg::DegreesToRadians(atof(const_cast<const char *>(pVectorCamera2BarrierLake[14].c_str()))), osg::Vec3d(0.0, 0.0, 1.0));
            Ytext = Textinfo(pVectorCamera2BarrierLake[15],infoy_pos,infoy_quat,50.0f);
    }


    //高度落差
    vector<string> pVectorDoubleArrows3=pXmlDoc->readXml("DoubleArrow3");
    if(pVectorDoubleArrows3.size()==0)
    {
        return NULL;
    }

    //画横着的线
    vector<string> pVectorDoubleArrows4=pXmlDoc->readXml("DoubleArrow4");
    if(pVectorDoubleArrows4.size()==0)
    {
        return NULL;
    }
        osg::Vec3 pos4(atof(const_cast<const char *>(pVectorDoubleArrows4[1].c_str())), atof(const_cast<const char *>(pVectorDoubleArrows4[2].c_str())), atof(const_cast<const char *>(pVectorDoubleArrows4[3].c_str())));

    //改为画线并标注信息
    osg::Vec3 pos3_1(atof(const_cast<const char *>(pVectorDoubleArrows3[2].c_str())), atof(const_cast<const char *>(pVectorDoubleArrows3[3].c_str())), atof(const_cast<const char *>(pVectorDoubleArrows3[4].c_str())));
//    float len = atof(const_cast<const char *>(pVectorDoubleArrows3[5].c_str()));
   std::string len = pVectorDoubleArrows3[5];
    osg::Vec3 pos3_2(pos3_1._v[0],pos3_1._v[1],pos4._v[2]);
    osg::ref_ptr<osg::Node> arrow3 = DrawinfoLine(pos3_1,pos3_2,osg::Vec4(1.0f,0.0f,0.0f,1.0f));
    osg::Vec3 pos3_text(pos3_2.x(),pos3_2.y(),(pos3_2.z()-pos3_1.z())/2 + pos3_1.z());
    osg::ref_ptr<osg::Node> arrow_text3 = WB_BT(pVectorDoubleArrows3[6],pos3_text,55.0f);//Textinfo(pVectorDoubleArrows3[6],pos3_text,quat3,45.0f);
    //宽度
     int wid_2 = (int)pow(pos4.x()-pos3_2.x(),2) + pow(pos4.y()-pos3_2.y(),2);
    int width = (int)sqrt(wid_2);
    std::string text3_2 = len;//std::to_string(width)+"米";
    std::string text_mid =std::to_string(width)+"米";
//    std::cout<<text3_2<<std::endl;


//    //画第四个箭头
//    vector<string> pVectorDoubleArrows4=pXmlDoc->readXml("DoubleArrow4");
//    if(pVectorDoubleArrows4.size()==0)
//    {
//        return NULL;
//    }
//    //改为画线
//        osg::Vec3 pos4(atof(const_cast<const char *>(pVectorDoubleArrows4[1].c_str())), atof(const_cast<const char *>(pVectorDoubleArrows4[2].c_str())), pos3_2._v[2]);
        osg::ref_ptr<osg::Node> arrow4 = DrawinfoLine(pos3_2,pos4,osg::Vec4(1.0f,0.0f,0.0f,1.0f));
//         osg::Vec3 pos_wid(arrow4.get()->getBound().center().x(),arrow4.get()->getBound().center().y(),arrow4.get()->getBound().center().z()+5);
        osg::Vec3 pos_mid(arrow4.get()->getBound().center().x(),arrow4.get()->getBound().center().y(),arrow4.get()->getBound().center().z()+5);
        osg::Vec3 pos_wid(pos4.x(),pos4.y(),pos4.z()+5);
        osg::ref_ptr<osg::Node> arrow_text3_2 = WB_BT(text3_2.c_str(),pos_wid,55.0f);//Textinfo(text3_2.c_str(),pos_wid,quat3,45.0f);
        osg::ref_ptr<osg::Node> midtext = WB_BT(text_mid.c_str(),pos_mid,55.0f);

        //动画测试
        osg::ref_ptr<osg::PositionAttitudeTransform> pat = new osg::PositionAttitudeTransform();
        pat->addChild(arrow3.get());
        osg::Vec3 pos = pat->getPosition();
        osg::Quat quat = pat->getAttitude();
        osg::Vec3 scale = pat->getScale();
        osg::ref_ptr<osg::AnimationPath> ap = createScaleAni(pos,quat,scale);
        pat->setUpdateCallback(new osg::AnimationPathCallback(ap.get()));

    RenderClass *rc = new RenderClass;
    if(num==3){
        //显示落差
//     group->addChild(arrow3.get());
     group->addChild(pat.get());
//     group->addChild(arrow4.get());
     group->addChild(arrow_text3.get());
//     group->addChild(arrow_text3_2.get());

    }else if(num==4){
     group->addChild(Ytext.get());
    }
    else if(num==5){
        group->addChild(arrow4.get());
        group->addChild(arrow_text3_2.get());
        group->addChild(midtext.get());
    }


//    rc->closeZbuffer(*group);
    delete rc;

     return group.get();


}


osg::ref_ptr<osg::Node> DrawGeometry::Reason(){


    XMLDoc *pXmlDoc=new XMLDoc();
    vector<string> pVectorSingleArrow=pXmlDoc->readXml("SingleArrow");
    osg::ref_ptr<osgText::Font> font=osgText::readFontFile("fonts/msyh.ttc");
    osg::ref_ptr<osgText::Text> text = new osgText::Text();
    text->setFont(font);
    if(pVectorSingleArrow.size()>=16)
    {
    std::wstring str=string_To_wstring(pVectorSingleArrow[16]);
    text->setText(str.c_str());
    osg::Vec3 pos(atof(const_cast<const char *>(pVectorSingleArrow[10].c_str())),atof(const_cast<const char *>(pVectorSingleArrow[11].c_str())),atof(const_cast<const char *>(pVectorSingleArrow[12].c_str())));
    osg::Quat quat( osg::DegreesToRadians(atof(const_cast<const char *>(pVectorSingleArrow[13].c_str()))), osg::Vec3d(1.0, 0.0, 0.0),
                    osg::DegreesToRadians(atof(const_cast<const char *>(pVectorSingleArrow[14].c_str()))), osg::Vec3d(0.0, 1.0, 0.0),
                    osg::DegreesToRadians(atof(const_cast<const char *>(pVectorSingleArrow[15].c_str()))), osg::Vec3d(0.0, 0.0, 1.0));
    TextType(*text,100,pos,osg::Vec4(1.0f,1.0f,1.0f,1.0f));
    text->setRotation(quat);
//    text->setBackdropType(osgText::Text::OUTLINE);//对文字进行描边
//    text->setBackdropColor(osg::Vec4(1.0f,1.0f,1.0f,1.0f));//描边颜色
    text->setAlignment(osgText::Text::CENTER_CENTER);
   }

    osg::ref_ptr<osg::Geode> geode = new osg::Geode();
    geode->addDrawable(text.get());

    return geode.get();

}



//画线
osg::ref_ptr<osg::Node> DrawGeometry::DrawinfoLine(osg::Vec3 pos1, osg::Vec3 pos2,osg::Vec4 color){

    osg::ref_ptr<osg::Geode> geode = new osg::Geode;
    osg::ref_ptr<osg::Vec3Array> vecarry1 = new osg::Vec3Array();
    osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry();
    {
    vecarry1->push_back(pos1);
    vecarry1->push_back(pos2);
    geometry->setVertexArray(vecarry1.get());
    geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, 2));
    }
    osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth(3.0);
    geometry->getOrCreateStateSet()->setAttribute(lw,osg::StateAttribute::ON);
    osg::Material *material = new osg::Material;
    material->setDiffuse(osg::Material::FRONT,color);
    material->setAmbient(osg::Material::FRONT, color);
    material->setShininess(osg::Material::FRONT, 90.0);
    geode->getOrCreateStateSet()->setAttribute(material);
//    RenderClass *rc = new RenderClass;
//    rc->setNodeRender(*geode,50.0);
//    delete rc;

    geode->addDrawable(geometry.get());
    return geode.get();
}


wstring DrawGeometry::string_To_wstring(string pStr)
{
    //不能识别转义字符(但是将xml中的换行符修改为&#x000A;即可识别换行符)
    unsigned len = pStr.size() * 2;// 预留字节数
    setlocale(LC_CTYPE, "");     //必须调用此函数
    wchar_t *p = new wchar_t[len];// 申请一段内存存放转换后的字符串
    mbstowcs(p,pStr.c_str(),len);// 转换
    std::wstring str1(p);
    delete[] p;// 释放申请的内存
    return str1;
}



osg::ref_ptr<osg::Node> DrawGeometry::WB_BT(string c, osg::Vec3 pos, float scale,osg::Vec4 tcolor,osg::Vec4 bcolor)
{
    osg::ref_ptr<osgText::Text> text = new osgText::Text();
    wstring str=string_To_wstring(c);
    text->setText(str.c_str());
    text->setFont("fonts/msyh.ttc");
    text->setColor(tcolor);
    text->setPosition(pos);
    text->setCharacterSize(scale);
//    text->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//    text->setBoundingBoxColor(bcolor);
    text->setBackdropType(osgText::Text::OUTLINE);//文件描边
    text->setBackdropColor(bcolor);//文字描边
    text->setAutoRotateToScreen(true);
    osg::ref_ptr<osg::Geode> geode = new osg::Geode();
    geode->addDrawable(text.get());

    RenderClass *rc = new RenderClass;
    rc->closeZbuffer(*geode);
    delete rc;
    return geode.get();
}

osg::ref_ptr<osg::Node> DrawGeometry::WB_BT(const char* c, osg::Vec3 pos, float scale,osg::Vec4 tcolor,osg::Vec4 bcolor)
{
    osg::ref_ptr<osgText::Text> text = new osgText::Text();
    text->setText(Return_str(c), osgText::String::ENCODING_UTF8);
    text->setFont("fonts/msyh.ttc");
    text->setColor(tcolor);
    text->setPosition(pos);
    text->setCharacterSize(scale);
//    text->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//    text->setBoundingBoxColor(bcolor);
    text->setBackdropType(osgText::Text::OUTLINE);//文件描边
    text->setBackdropColor(bcolor);//文字描边
    text->setAutoRotateToScreen(true);
    osg::ref_ptr<osg::Geode> geode = new osg::Geode();
    geode->addDrawable(text.get());

    RenderClass *rc = new RenderClass;
    rc->closeZbuffer(*geode);
    delete rc;

    return geode.get();
}

osg::ref_ptr<osg::Node> DrawGeometry::WB_BT_AutoScreen(const char* c, osg::Vec3 pos, float scale,bool withline,osg::Vec4 tcolor,osg::Vec4 bcolor)
{
    osg::ref_ptr<osgText::Text> text = new osgText::Text();
    wstring str=string_To_wstring(c);
    text->setText(str.c_str());
    text->setFont("fonts/msyh.ttc");
    text->setColor(tcolor);
    text->setPosition(pos);
    text->setCharacterSize(scale);
//    text->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//    text->setBoundingBoxColor(bcolor);
    text->setBackdropType(osgText::Text::OUTLINE);//文件描边
    text->setBackdropColor(bcolor);//文字描边
    text->setAutoRotateToScreen(true);
    text->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
    osg::ref_ptr<osg::Geode> geode = new osg::Geode();
    geode->addDrawable(text.get());
    osg::ref_ptr<osg::Group> gp = new osg::Group;
    gp->addChild(geode.get());

    if(withline){
        osg::ref_ptr<osg::Geode> geodeline = new osg::Geode;
        osg::ref_ptr<osg::Vec3Array> vecarry1 = new osg::Vec3Array();
        osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry();
        osg::Vec3 posd = osg::Vec3(pos.x(),pos.y(),pos.z()+300);
        text->setPosition(posd);
        {
        vecarry1->push_back(pos);
        vecarry1->push_back(posd);
        geometry->setVertexArray(vecarry1.get());
        geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, 2));
        }
        osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth(4.0);
        geometry->getOrCreateStateSet()->setAttribute(lw,osg::StateAttribute::ON);
        osg::Material *material = new osg::Material;
        material->setDiffuse(osg::Material::FRONT,osg::Vec4(0,0,1,1));
        material->setAmbient(osg::Material::FRONT, osg::Vec4(0,0,1,1));
        material->setShininess(osg::Material::FRONT, 90.0);
        geodeline->getOrCreateStateSet()->setAttribute(material);
        geodeline->addDrawable(geometry.get());
        gp->addChild(geodeline.get());
    }

    RenderClass *rc = new RenderClass();
    rc->setNodeRender(*gp,10);


    return gp.get();
}

osg::ref_ptr<osg::Node> DrawGeometry::WB_BT_AutoScreen(string c, osg::Vec3 pos, float scale,bool withline,osg::Vec4 tcolor,osg::Vec4 bcolor)
{

    osg::ref_ptr<osgText::Text> text = new osgText::Text();
    wstring str=string_To_wstring(c);
    text->setText(str.c_str());
    text->setFont("fonts/msyh.ttc");
    text->setColor(tcolor);
    text->setPosition(pos);
    text->setCharacterSize(scale);
//    text->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//    text->setBoundingBoxColor(bcolor);
    text->setBackdropType(osgText::Text::OUTLINE);//文件描边
    text->setBackdropColor(bcolor);//文字描边
    text->setAutoRotateToScreen(true);
    text->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
    osg::ref_ptr<osg::Geode> geode = new osg::Geode();
    geode->addDrawable(text.get());
    osg::ref_ptr<osg::Group> gp = new osg::Group;
    gp->addChild(geode.get());

    if(withline){
        osg::ref_ptr<osg::Geode> geodeline = new osg::Geode;
        osg::ref_ptr<osg::Vec3Array> vecarry1 = new osg::Vec3Array();
        osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry();
        osg::Vec3 posd = osg::Vec3(pos.x(),pos.y(),pos.z()+300);
        text->setPosition(posd);
        {
        vecarry1->push_back(pos);
        vecarry1->push_back(posd);
        geometry->setVertexArray(vecarry1.get());
        geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, 2));
        }
        osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth(4.0);
        geometry->getOrCreateStateSet()->setAttribute(lw,osg::StateAttribute::ON);
        osg::Material *material = new osg::Material;
        material->setDiffuse(osg::Material::FRONT,osg::Vec4(0,0,1,1));
        material->setAmbient(osg::Material::FRONT, osg::Vec4(0,0,1,1));
        material->setShininess(osg::Material::FRONT, 90.0);
        geodeline->getOrCreateStateSet()->setAttribute(material);
        geodeline->addDrawable(geometry.get());
        gp->addChild(geodeline.get());
    }

    RenderClass *rc = new RenderClass();
    rc->setNodeRender(*gp,10);


    return gp.get();
}

osg::ref_ptr<osg::Node> DrawGeometry::Word_Side(string c, osg::Vec3 pos, float scale, osg::Vec4 tcolor, osg::Vec4 scolor)
{
    osg::ref_ptr<osgText::Text> text = new osgText::Text();
    wstring str=string_To_wstring(c);
    text->setText(str.c_str());
    text->setFont("fonts/msyh.ttc");
    text->setColor(tcolor);
    text->setPosition(pos);
    text->setCharacterSize(scale);
//    text->setDrawMode(osgText::Text::TEXT | osgText::Text::BOUNDINGBOX);
    text->setBackdropType(osgText::Text::OUTLINE);
//    text->setBoundingBoxColor(scolor);
    text->setBackdropColor(scolor);
    text->setAutoRotateToScreen(true);
    text->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
    osg::ref_ptr<osg::Geode> geode = new osg::Geode();
    geode->addDrawable(text.get());

    RenderClass *rc = new RenderClass;
    rc->closeZbuffer(*geode);
    delete rc;

    return geode.get();

}


osg::ref_ptr<osg::Vec3Array> calcaulate(osg::Vec3 v1,osg::Vec3 v2,float width){

    float k = (v2.x()-v1.x())/(v2.y()-v1.y());
    float x1 = v1.x()+sqrt(width*width/(1+k*k));
    float y1 = v1.y()-k*(x1-v1.x());
    osg::Vec3 a1(x1,y1,v1.z());

    float x4 = v1.x()-sqrt(width*width/(1+k*k));
    float y4 = v1.y()-k*(x4-v1.x());
    osg::Vec3 a4(x4,y4,v1.z());

    float x2 = v2.x()+sqrt(width*width/(1+k*k));
    float y2 = v2.y()-k*(x2-v2.x());
    osg::Vec3 a2(x2,y2,v2.z());

    float x3 = v2.x()-sqrt(width*width/(1+k*k));
    float y3 = v2.y()-k*(x3-v2.x());
    osg::Vec3 a3(x3,y3,v2.z());

    osg::ref_ptr<osg::Vec3Array> v = new osg::Vec3Array();
    v->push_back(a1);
    v->push_back(a2);
    v->push_back(a3);
    v->push_back(a4);

return v;
}

//弯曲的箭头
osg::ref_ptr<osg::Node> DrawGeometry::drawBendarrow(osg::Vec3 v1, osg::Vec3 v2, float width,std::string imagepath ,int drawtype){

//    XMLDoc *pXmlDoc=new XMLDoc();
//    vector<string> pBendArrow=pXmlDoc->readXml("BendArrow");
//    int num = pBendArrow.size();
//    std::string path="";
//    if(num>0){
//      path=pBendArrow[0];
//    }
    osg::ref_ptr<osg::Image> image =osgDB::readImageFile(imagepath);
         //创建四边形
         osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry();
         osg::ref_ptr<osg::Geode> geode = new osg::Geode();

         //设置顶点
         osg::ref_ptr<osg::Vec3Array> v = calcaulate(v1,v2,width);


         geometry->setVertexArray(v.get());

         osg::Vec3 n1 = v.get()->at(0);
         osg::Vec3 n2 = v.get()->at(1);;
         osg::Vec3 n3 = v.get()->at(2);;
         osg::Vec3 n4 = v.get()->at(3);;

         osg::Vec3 l1 = n4-n1;
         osg::Vec3 l2 = n2-n1;

         //设置法线
         osg::ref_ptr<osg::Vec3Array> normal = new osg::Vec3Array();
//         normal->push_back(osg::Vec3(1.0f,0.0f,0.0f)^osg::Vec3(0.0f,0.0f,1.0f));
         normal->push_back(l1^l2);
//            normal->push_back(osg::Vec3(0.0f,1.0f,0.0f)^osg::Vec3(0.0f,0.0f,1.0f));

         geometry->setNormalArray(normal.get());
         geometry->setNormalBinding(osg::Geometry::BIND_OVERALL);

         //设置纹理坐标
         osg::ref_ptr<osg::Vec2Array> vt = new osg::Vec2Array();
        if(drawtype==1){
            vt->push_back(osg::Vec2(1.0f,0.0f));
            vt->push_back(osg::Vec2(1.0f,1.0f));
            vt->push_back(osg::Vec2(0.0f,1.0f));
            vt->push_back(osg::Vec2(0.0f,0.0f));
        }
        if(drawtype==2){
            vt->push_back(osg::Vec2(0.0f,0.0f));
            vt->push_back(osg::Vec2(0.0f,1.0f));
            vt->push_back(osg::Vec2(1.0f,1.0f));
            vt->push_back(osg::Vec2(1.0f,0.0f));
        }

         geometry->setTexCoordArray(0,vt.get());
         geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS,0,4));

         if(image.get()){
             //属性对象
             osg::ref_ptr<osg::StateSet> stateset = new osg::StateSet();

             //创建一个Texture2D属性对象
             osg::ref_ptr<osg::Texture2D> texture = new osg::Texture2D();

             //关联image
             texture->setImage(image.get());


             //关联Texture2D纹理对象，第三个参数默认为ON
             stateset->setTextureAttributeAndModes(0,texture,osg::StateAttribute::ON);

             //启用混合
             stateset->setMode(GL_BLEND,osg::StateAttribute::ON);
             //关闭光照
             stateset->setMode(GL_LIGHTING,osg::StateAttribute::OFF);


             geometry->setStateSet(stateset.get());
         }


         geode->addDrawable(geometry.get());

         RenderClass *rc = new RenderClass;
         rc->setNodeRender(*geode,2);

         delete rc;
        return geode.get();
}
