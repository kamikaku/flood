﻿#include "floodform.h"
#include "ui_floodform.h"

FloodForm::FloodForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FloodForm)
{
    ui->setupUi(this);

    viewer = new ViewerQT;
    pushButton = ui->pushButton_3;

    lineEdit1=ui->lineEdit;  //库容值
    lineEdit2=ui->lineEdit_2;  //最浅 //坝宽
    lineEdit3=ui->lineEdit_3;  //最深 //坝高
    lineEdit4=ui->lineEdit_4; //用于展示打开的场景或文件路径
    lineEdit5=ui->lineEdit_5;
    lineEdit6=ui->lineEdit_6;
    lineEdit7=ui->lineEdit_7;
    lineEdit8=ui->lineEdit_8;

//    lineEdit1->setText("20000001");  //设置库容默认值
    lineEdit1->setText("100000000");  //设置库容默认值
//    lineEdit2->setText("133"); //设置坝宽默认值
//    lineEdit3->setText("102.5"); //设置坝高默认值
    lineEdit2->setText("0");
    lineEdit3->setText("20");

    doubleSpinBox1=ui->doubleSpinBox; //设置溃口宽度默认值
    doubleSpinBox1->setRange(0,200);
    doubleSpinBox1->setSingleStep(0.5); //设置singlesetp为0.5
    doubleSpinBox1->setValue(133);
    doubleSpinBox2=ui->doubleSpinBox_2; //设置溃口高度默认值
    doubleSpinBox2->setSingleStep(0.5);
    doubleSpinBox2->setValue(47.5);

//    spinBox5=ui->spinBox_5;
//    spinBox5->setRange(0,200);
//    spinBox5->setValue(100); //设置时空比率默认值


    //添加溃决方式
    ui->comboBox->addItem("全溃");
    ui->comboBox->addItem("二分之一溃");
    ui->comboBox->addItem("三分之一溃");
    ui->comboBox->addItem("五分之一溃");
    ui->comboBox->addItem("十分之一溃");
    //文件格式
    ui->comboBox_2->addItem(".ive");
    ui->comboBox_2->addItem(".3ds");
    ui->comboBox_2->addItem(".tif");
}

FloodForm::~FloodForm()
{
    delete ui;
}

//设置洪水顶点的颜色
osg::Vec4 FloodForm::floodColor(float ZValue, float D_value)
{
    //===第一种通过计算，设置步长然后计算出相应颜色
    //    float D_value;  //洪水深度最大差值
    int runNum=5; //要分的步数
    osg::Vec4 color;

//    osg::Vec4 color1=osg::Vec4(0.69,0.93,0.93,1.0f);  //浅颜色  颜色与水相似
//    osg::Vec4 color2=osg::Vec4(0.27,0.51,0.71,1.0f);  //深颜色

//    osg::Vec4 color1=osg::Vec4(1,0.89,0.76,1.0f);  //浅颜色
//    osg::Vec4 color2=osg::Vec4(0.94,0.46,0.02,1.0f);  //深颜色

    float everyNum=D_value/runNum; //每步长
    int flag=ZValue/everyNum+1;  //传入的水深属于哪个区间

    float rc=color1[0]+(color2[0]-color1[0])*flag/runNum;
    float gc=color1[1]+(color2[1]-color1[1])*flag/runNum;
    float bc=color1[2]+(color2[2]-color1[2])*flag/runNum;
    color=osg::Vec4(rc, gc, bc, 1.0f);  //相应水深对应的颜色值

    //第二种，直接将颜色分成三种，分别代表低、中、高
//    float temp1=D_value/5.0;
//    float temp2=D_value*2.0/5.0;
//    if(ZValue<=temp1)
//    {
//        color =osg::Vec4(1,0.89,0.76,1.0f);
//    }else if(ZValue<=temp2)
//    {
//        color = osg::Vec4(0.97,0.675,0.39,1.0f);
//    }else{
//        color = osg::Vec4(0.94,0.46,0.02,1.0f);
//    }
    return color;

}

//创建图例，主要显示各种灾害颜色代表意义
osg::ref_ptr<osg::Node> FloodForm::createLegend(int minValue,int maxValue)
{
    CreateScalarBar*cs=new CreateScalarBar();//添加图例

    return cs->createScalarBar(color1,color2,minValue,maxValue);
}

//===按钮事件，开始计算
void FloodForm::on_pushButton_3_clicked()
{

    if(ui->lineEdit_4->text()=="" || ui->lineEdit_5->text()=="" ||ui->label_6->text()==""){
        QMessageBox::information(NULL, "Warning", "未填写文件", QMessageBox::Yes );
        return;
    }
    QString fm = ui->comboBox_2->currentText();
    Fformat = fm.toStdString();
    vector<QString> floodValues;  //存储洪水界面的参数值
    QString damVolume=lineEdit1->text();  //库容
    QString damWidth=doubleSpinBox1->text();//lineEdit2->text(); //坝宽
    QString damHeight=doubleSpinBox2->text(); //lineEdit3->text(); //坝高
    QString breakWidth=doubleSpinBox1->text();  //溃口宽度
    QString breakHeight=doubleSpinBox2->text();  //溃口高度
    float sto = 100.0;

    QString spatialTimeRatio=QString("%1").arg(sto);//spinBox5->text(); //时空比率
    QString damModel=ui->comboBox->currentText();  //溃口模式
    QString shallowDep = lineEdit2->text();
    QString deepDep = lineEdit3->text();
    //判断必须参数是否输入
    if(damVolume==NULL || damWidth==NULL ||damHeight==NULL || breakWidth==NULL || breakHeight==NULL || spatialTimeRatio==NULL)
    {//必要参数中有为空值时,则弹出提示框
         QMessageBox::information(NULL, "Warning", "Please input parameters", QMessageBox::Yes );
    }
    else{
        floodValues.push_back(damVolume);
        floodValues.push_back(damWidth);
        floodValues.push_back(damHeight);
        floodValues.push_back(breakWidth);
        floodValues.push_back(breakHeight);
        floodValues.push_back(spatialTimeRatio);
        floodValues.push_back(damModel);
        floodValues.push_back(shallowDep);
        floodValues.push_back(deepDep);
        this->close();  //关闭当前窗体
        emit sendURL(urlStr);  //传送需要计算的信息,必须要先传数据才能计算
        emit sendfloodValues(floodValues);  //传输界面的参数值
        emit transmitSignals(true);
    }

}

//洪水演进按钮
void FloodForm::on_pushButton_4_clicked()
{
    //发送信号
    this->close();
    emit sendStart(1);
}

//打开计算文件，洪水的计算文件为20m文件夹（包含dem、cao糙率、InputRiver文件）
//加载洪水信息--加载糙率文件
void FloodForm::on_pushButton_6_clicked()
{
    //获取文件夹路径
     QString fileName = QFileDialog::getOpenFileName(this);
     if(fileName.isEmpty()){ //选择文件是否存在
         QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
     }else{
         if(lineEdit4->text().isEmpty()){ //是否已经有选择过路径了
             lineEdit4->setText(fileName);
             urlStr.push_back(fileName.toStdString());
         }else{ //若之前选择过，现只需修改即可
             urlStr[0]=fileName.toStdString();
             lineEdit4->setText(fileName);
         }
     }

}

//加载洪水信息--加载dem
void FloodForm::on_pushButton_7_clicked()
{
    if(lineEdit4->text().isEmpty()){ //是否已经有选择过路径了
        QMessageBox::information(NULL, "Warning", "请先加载糙率文件", QMessageBox::Yes );
    }else{
        //获取文件夹路径
         QString fileName = QFileDialog::getOpenFileName(this);
         if(fileName.isEmpty()){ //选择文件是否存在
             QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
         }else{
             if(lineEdit5->text().isEmpty()){ //是否已经有选择过路径了
                 lineEdit5->setText(fileName);
                 urlStr.push_back(fileName.toStdString());
             }else{ //若之前选择过，现只需修改即可
                 urlStr[1]=fileName.toStdString();
                 lineEdit5->setText(fileName);
             }
         }
    }
}

//加载洪水信息--加载溃口信息
void FloodForm::on_pushButton_8_clicked()
{
    if(lineEdit5->text().isEmpty()){ //是否已经有选择过路径了
        QMessageBox::information(NULL, "Warning", "请先加载dem文件", QMessageBox::Yes );
    }else{
        //获取文件夹路径
         QString fileName = QFileDialog::getOpenFileName(this);
         if(fileName.isEmpty()){ //选择文件是否存在
             QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
         }else{
             if(lineEdit6->text().isEmpty()){ //是否已经有选择过路径了
                 lineEdit6->setText(fileName);
                 urlStr.push_back(fileName.toStdString());
             }else{ //若之前选择过，现只需修改即可
                 urlStr[2]=fileName.toStdString();
                 lineEdit6->setText(fileName);
             }
         }
          QString pathStr=fileName.left(fileName.lastIndexOf("/"));
          QString HNWstr = pathStr + "/HNW.txt";
           QFile file(HNWstr);
           if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
           QByteArray t = file.readAll();
           QString length =QString(t);
           float flh= length.toFloat();
           ui->doubleSpinBox->setValue(flh);
           }
    }
}




//打开场景,支持osg场景显示的文件都可以（如：.ive、.osg）
void FloodForm::on_pushButton_5_clicked()
{
    //获取文件夹路径
    string scenePath; //场景路径
     QString fileName = QFileDialog::getOpenFileName(this);
     if(fileName.isEmpty()){ //选择文件是否存在
         QMessageBox::information(NULL, "Warning", "请选择正确文件", QMessageBox::Yes );
     }else{
         if(lineEdit7->text().isEmpty()){ //是否已经有选择过路径了
             lineEdit7->setText(fileName);
             scenePath=fileName.toStdString();
         }else{ //若之前选择过，现只需修改即可
             scenePath=fileName.toStdString();
         }
         emit sendScenePath(scenePath);  //用于传送选择的场景
         lineEdit7->setText(fileName);
     }
}

//清空界面参数设置
void FloodForm::on_pushButton_2_clicked()
{
    lineEdit1->setText("");  //设置库容默认值
//    lineEdit2->setText(""); //设置坝宽默认值
//    lineEdit3->setText(""); //设置坝高默认值
    floodValues.clear();  //清空容器

    urlStr.clear();  //清空容器
    lineEdit4->setText("");
    lineEdit5->setText("");
    lineEdit6->setText("");
    lineEdit7->setText("");
    lineEdit8->setText("");

}



//加载监测站

void FloodForm::on_pushButton_9_clicked()
{

    QString fileName = QFileDialog::getOpenFileName(this);
    if(fileName.isEmpty()){
        return;
    }
    else{
     if(lineEdit8->text().isEmpty()){
         lineEdit8->setText(fileName);
         urlStr.push_back(fileName.toStdString());
     }
     else{
         urlStr[3]=fileName.toStdString();
         lineEdit8->setText(fileName);
     }
    }

}
