﻿#ifndef READSHPDIALOG_H
#define READSHPDIALOG_H
#pragma execution_character_set("utf-8")
#pragma once
#include <QDialog>
#include <QColorDialog>
#include <QFileDialog>
#include <QMessageBox>
#include <osgUtil/Tessellator>
#include <osg/Depth>

#include "shpclass.h"
#include "DamageDescription.h"
#include <iostream>
#include "gdal.h"
#include "gdal_priv.h"
#include "ogrsf_frmts.h"
#include "gdal_version.h"



namespace Ui {
class ReadshpDialog;
}


class shapeFormat{

public:
    std::string shpPath;
    QColor txcolor;
    QColor color;
    int txsize;
public:
    shapeFormat(std::string path,QColor c1=QColor(255,0,0), QColor c2=QColor(0,0,0), int size=20);
};

class ReadshpDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ReadshpDialog(QWidget *parent = 0);
    ~ReadshpDialog();

private slots:
    void on_pushButton_2_clicked();

    void on_choosefile_clicked();

    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::ReadshpDialog *ui;

public:
    QColor color = QColor(255,0,0); //shp的颜色
    std::string filep;
    std::vector<Point3D> shp_Point;
    std::vector<Line3D> shp_Line;
    std::vector<Polygon3D> shp_Polygon;
    int type = 0; //1为点 2为线 3为多边形
    int line_stipple=0; //1为虚线 0为实线

    QColor txcolor = QColor(0,0,0);//字体颜色
    int txsize = 30;//字体大小
    float alpha = 1.0f; //设置透明度

    float linew = 3.0f;//设置画线时的宽度
    float renderrank = 3.0f;
    void read_shp(const char* path);
    osg::ref_ptr<osg::Group> draw_SHP();
    osg::ref_ptr<osg::Group> draw_text(int text=1);
private:
    bool drawable=true;

signals:
//    void sendGroup(osg::ref_ptr<osg::Group>);
    void sendGroup(shapeFormat*);
};



#endif // READSHPDIALOG_H
