﻿#include "pickhandle.h"

void PickHandle::pick(float x, float y){
    osgUtil::LineSegmentIntersector::Intersections intersections;
    if(view->computeIntersections(x,y,intersections)){
        osgUtil::LineSegmentIntersector::Intersections::iterator hitr = intersections.begin();
        osg::NodePath getNodePath = hitr->nodePath;
        for(int i = getNodePath.size()-1; i>=0; --i){
//            osg::MatrixTransform *mt = dynamic_cast<osg::MatrixTransform*>(getNodePath[i]);
//            osg::PositionAttitudeTransform *pt = dynamic_cast<osg::PositionAttitudeTransform*>(getNodePath[i]);
//            if(mt == NULL){
//                continue;
//            }
//            else
//            {
//                std::cout<<hitr->getLocalIntersectPoint().x()<<" "<<hitr->getLocalIntersectPoint().y()<<""<<hitr->getLocalIntersectPoint().z()<<std::endl;
                Wx = hitr->getWorldIntersectPoint().x();
                Wy = hitr->getWorldIntersectPoint().y();
                Wz = hitr->getWorldIntersectPoint().z();
                std::cout<<" wx:"<<hitr->getWorldIntersectPoint().x()<<" wy:"<<hitr->getWorldIntersectPoint().y()<<" wz:"<<hitr->getWorldIntersectPoint().z()<<std::endl;
                std::vector<float> p;
                p.push_back(Wx);
                p.push_back(Wy);
                p.push_back(Wz);
                coord=p;
//            }
        }
    }

}


bool PickHandle::handle(const osgGA::GUIEventAdapter &ea, osgGA::GUIActionAdapter &aa){

    view = dynamic_cast<osgViewer::View*>(&aa);
    if(!view) return false;

    switch(ea.getEventType()){
    case osgGA::GUIEventAdapter::PUSH:
    {
        if(view){
            int button = ea.getButton();
            if(button == osgGA::GUIEventAdapter::LEFT_MOUSE_BUTTON){
                pick(ea.getX(),ea.getY());
            }
        }
        return false;
    }

    default:
        return false;

    }
}
