﻿#include "DamageDescription.h"
#include <QCoreApplication>

DamageDescription::DamageDescription()
{

}

//改变shp颜色(会受环境影响)
//***改变shp的大小和颜色，步骤1
osg::Image *DamageDescription::createImage(int width, int height, osg::Vec3 color)
{
    osg::ref_ptr<osg::Image> image = new osg::Image;
    image->allocateImage( width, height, 1, GL_RGB, GL_UNSIGNED_BYTE );
    unsigned char* data = image->data();
    for ( int y=0; y<height; ++y )
    {
        for ( int x=0; x<width; ++x )
        {
            *(data++) = color.x();
            *(data++) = color.y();
            *(data++) = color.z();
        }
    }
    return image.release();
}

//***改变shp的大小和颜色，步骤2
void DamageDescription::ChangeSHP(osg::ref_ptr<osg::Node> node, osg::Vec4 color, float size, bool IsPoint)
{
    osg::ref_ptr<osg::Image> image= createImage(256,256,osg::Vec3(color.x(),color.y(),color.z()));
    if (image.get())
    {
        osg::ref_ptr<osg::Texture2D> texture=new osg::Texture2D();
        texture->setImage(image.get());

        //设置自动生成纹理坐标
        osg::ref_ptr<osg::TexGen> texgen=new osg::TexGen();
        texgen->setMode(osg::TexGen::NORMAL_MAP);

        //设置纹理环境，模式为BLEND
        osg::ref_ptr<osg::TexEnv> texenv=new osg::TexEnv;
        texenv->setMode(osg::TexEnv::ADD);
        texenv->setColor(color);

        //启动单元一自动生成纹理坐标，并使用纹理
        osg::ref_ptr<osg::StateSet> state=new osg::StateSet;

        state->setTextureAttributeAndModes(1,texture.get(),osg::StateAttribute::ON);
        state->setTextureAttributeAndModes(1,texgen.get(),osg::StateAttribute::ON);

         if(IsPoint)
             {
                 osg::ref_ptr<osg::Point> pointsize = new osg::Point;
                 pointsize->setSize(size);
                 state->setAttributeAndModes(pointsize,osg::StateAttribute::ON);
                 state->setMode(GL_POINT_SPRITE_ARB,osg::StateAttribute::ON); //点精灵效果(需要添加osg/PointSprite引用)
             }
             else
             {
                 osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth;
                 lw->setWidth(size);
                 state->setAttributeAndModes(lw,osg::StateAttribute::ON);
             }
         node->setStateSet(state.get());
    }
}


//读取shp数据
list<list<Point3D>> DamageDescription::gdal_read_polygonshp(const char* path)   //函数前必须要加上类名（VS中可以不加）
{
    list<list<Point3D>>* p_list2=new list<list<Point3D>>;

    //判断文件是否存在
    QFileInfo file(path);
    if(file.exists()==false)
    {
        cout<<"文件不存在!"<<endl;
        return *p_list2;
    }


    GDALAllRegister();
    GDALDataset   *poDS;
    CPLSetConfigOption("SHAPE_ENCODING", "");  //解决中文乱码问题
    //读取shp文件
    poDS = (GDALDataset*)GDALOpenEx(path, GDAL_OF_VECTOR, NULL, NULL, NULL);

    if (poDS == NULL)
    {
        cout << "Open failed.\n%s" << endl;

    }

    int nLayerCnt = poDS->GetLayerCount();
    int nLayerIdx = 0;

    for (; nLayerIdx < nLayerCnt; ++nLayerIdx)
    {
        OGRLayer* curLayer = poDS->GetLayer(nLayerIdx);
        GIntBig nFtrCount = curLayer->GetFeatureCount();

        if (NULL != curLayer->GetName())
        {
            std::cout << curLayer->GetName() << " 's FeatureCount :" << nFtrCount << std::endl;
        }
        OGRFeature * ftr = curLayer->GetNextFeature();
        double height;
        while (ftr)
        {
//            double height = ftr->GetFieldAsDouble("Height");  //获取属性表值
            height=ftr->GetFieldAsDouble("Height");  //获取属性表值
            if(height==0.0)
                height=50.0;
            OGRGeometry * poGeom = ftr->GetGeometryRef();
            switch (wkbFlatten(poGeom->getGeometryType()))
            {
//            case wkbLineString:
//            {
//                OGRLineString* poLS = static_cast<OGRLineString*>(poGeom);
//                const char* pGeoName = poLS->getGeometryName();
//                if (NULL != pGeoName)
//                {
//                    std::cout << " Geo name:" << pGeoName << std::endl;
//                }
//                int iPnum = poLS->getNumPoints();
//                std::cout << " Point Count:" << iPnum;
//                double iLen = poLS->get_Length();
//                std::cout << " Len :" << iLen;
//                for (int i = 0; i < iPnum; i++)
//                {
//                    Point3D p_Point3D;
//                    p_Point3D.X = poLS->getX(i);
//                    p_Point3D.Y = poLS->getY(i);
//                    p_Point3D.Z = poLS->getZ(i);
//                    p_list->push_back(p_Point3D);
//                    std::cout << " X : " << p_Point3D.X << " , Y : " << p_Point3D.Y<<" , Z : "<<p_Point3D.Z;
//                }
//                std::cout << std::endl;
//            }
//            break;
            case wkbPolygon:  //多边形
            {
                list<Point3D>* p_list= new list<Point3D>;
                OGRPolygon* poPoly = static_cast<OGRPolygon*>(poGeom);
                //cout << "poPoly->getNumInteriorRings():" << "  " << poPoly->getNumInteriorRings(); //获取的是内环个数，非坐标
                poPoly->closeRings();       //闭合环，使起点与终点重合
//                OGREnvelope3D* poEnvelop3D = new OGREnvelope3D;    //获取该要素的三维范围
//                poPoly->getEnvelope(poEnvelop3D);

                OGRLinearRing* poLR=poPoly->getExteriorRing();
                int Num=poLR->getNumPoints(); //获取内环点个数(起点与终点重合)

//                cout<<"Num: "<<Num<<endl;
//                poLR->getX(0);
//                cout<<"X: "<<poLR->getX(0)<<" X5: "<<poLR->getX(4)<<endl;

                for(int i=0;i<Num;i++)
                {
                    Point3D p_Point3D;
                    p_Point3D.X = poLR->getX(i);
                    p_Point3D.Y = poLR->getY(i);
                    p_Point3D.Z = poLR->getZ(i);
                    p_Point3D.height=height;
                    p_list->push_front(p_Point3D);
                }
                p_list2->push_front(*p_list);
            }
            default:
                break;
            }

            ftr = curLayer->GetNextFeature();
        }

        delete curLayer;
    }
    return *p_list2;
    GDALClose(poDS);  //不注释掉会报错

}

list<Point3D> DamageDescription::gdal_read_pointshp(const char *path)
{
    list<Point3D>* p_list=new list<Point3D>;

    //判断文件是否存在
    QFileInfo file(path);
    if(file.exists()==false)
    {
        cout<<"文件不存在!"<<endl;
        return *p_list;
    }

    GDALAllRegister();
    GDALDataset   *poDS;
    CPLSetConfigOption("SHAPE_ENCODING", "");  //解决中文乱码问题
    //读取shp文件
    poDS = (GDALDataset*)GDALOpenEx(path, GDAL_OF_VECTOR, NULL, NULL, NULL);

    if (poDS == NULL)
    {
        cout << "Open failed.\n%s" << endl;
    }

    int nLayerCnt = poDS->GetLayerCount();
    int nLayerIdx = 0;

    for (; nLayerIdx < nLayerCnt; ++nLayerIdx)
    {
        OGRLayer* curLayer = poDS->GetLayer(nLayerIdx);
        GIntBig nFtrCount = curLayer->GetFeatureCount();

        if (NULL != curLayer->GetName())
        {
            std::cout << curLayer->GetName() << " 's FeatureCount :" << nFtrCount << std::endl;
        }
        OGRFeature * ftr = curLayer->GetNextFeature();
        while (ftr)
        {
            OGRGeometry * poGeom = ftr->GetGeometryRef();
            switch (wkbFlatten(poGeom->getGeometryType()))
            {
            case wkbPoint:
                case wkbPoint25D:
                {
                    OGRPoint* poPS = static_cast<OGRPoint*>(poGeom);
                    Point3D p_Point3D;
                    p_Point3D.X = poPS->getX();
                    p_Point3D.Y = poPS->getY();
                    p_Point3D.Z = poPS->getZ();
                    p_list->push_back(p_Point3D);
                }
                break;
            default:
                break;
            }

            ftr = curLayer->GetNextFeature();
        }

        delete curLayer;
    }
    return *p_list;
    GDALClose(poDS);  //不注释掉会报错
}

//绘制建筑物
osg::ref_ptr<osg::Geometry> DamageDescription::Drawhousehall(std::list<Point3D> plist,osg::ref_ptr<osg::Vec4Array> colors)
{
    std::list<Point3D>::iterator it;
    //创建顶点数组，逆时针添加
    osg::ref_ptr<osg::Vec3Array> verticeshall = new osg::Vec3Array;
    int i=0;
    for ( it=plist.begin() ; it != plist.end(); it++ )
    {
        verticeshall->push_back(osg::Vec3(it->X, it->Y, it->Z)); //0
        i++;
        verticeshall->push_back(osg::Vec3(it->X, it->Y, it->Z+it->height)); //1
        i++;
    }
    //创建一个几何对象
    osg::ref_ptr<osg::Geometry> samplehousehall = new osg::Geometry;
    //设置顶点数据、纹理坐标、法线数组
    samplehousehall->setVertexArray(verticeshall.get());
    samplehousehall->setColorArray(colors.get());

    //设置颜色的绑定方式为一个属性与所有顶点绑定
    samplehousehall->setColorBinding(osg::Geometry::BIND_OVERALL);
    //添加图元，多段四边形条带，即一系列四边形
    samplehousehall->addPrimitiveSet(new osg::DrawArrays(osg::DrawArrays::QUAD_STRIP, 0, i));

    return samplehousehall;

}

osg::ref_ptr<osg::Geometry> DamageDescription::Drawhouseroof(std::list<Point3D> plist,osg::ref_ptr<osg::Vec4Array> colors)
{
    std::list<Point3D>::iterator it;
    //创建顶点数组，逆时针添加
    osg::ref_ptr<osg::Vec3Array> verticesroof = new osg::Vec3Array;
    int t=0;
    for ( it=plist.begin() ; it != plist.end(); it++ )
    {
        verticesroof->push_back(osg::Vec3(it->X, it->Y, it->Z+it->height)); //1
        t++;
    }

//    //创建颜色数组
//    osg::ref_ptr<osg::Vec4Array> colors = new osg::Vec4Array;
//    //添加数据
//    colors->push_back(osg::Vec4(255.0, 0.0, 0.0, 1.0));
    //创建一个几何对象
    osg::ref_ptr<osg::Geometry> samplehouseroof = new osg::Geometry;
    //设置顶点数据、纹理坐标、法线数组
    samplehouseroof->setVertexArray(verticesroof.get());
    samplehouseroof->setColorArray(colors.get());

    //设置颜色的绑定方式为一个属性与所有顶点绑定
    samplehouseroof->setColorBinding(osg::Geometry::BIND_OVERALL);
    //添加图元，多段四边形条带，即一系列四边形
    samplehouseroof->addPrimitiveSet(new osg::DrawArrays(osg::DrawArrays::QUADS, 0, t));

    return samplehouseroof;

}

//用Geode加载
osg::ref_ptr<osg::Geode> DamageDescription::Drawsamplehouse(std::list<Point3D> plist,osg::ref_ptr<osg::Vec4Array> colors)
{
    osg::ref_ptr<osg::Geode> samplehouse=new osg::Geode;
    osg::ref_ptr<osg::Geometry> househall= new osg::Geometry;
    osg::ref_ptr<osg::Geometry> houseroof=new osg::Geometry;

    househall=Drawhousehall(plist,colors);
    houseroof=Drawhouseroof(plist,colors);

    samplehouse->addDrawable(househall.get());
    samplehouse->addDrawable(houseroof.get());

    return samplehouse;

}


//绘制直线
osg::ref_ptr<osg::Geometry> DamageDescription::DrawLine(osg::Vec3 startvec3, osg::Vec3 endvec3, osg::ref_ptr<osg::Vec4Array> colors,double linewidth)
{
    osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;

    osg::ref_ptr<osg::Vec3Array> vecarry1 = new osg::Vec3Array();
    vecarry1->push_back(startvec3);
    vecarry1->push_back(endvec3);
    geometry->setVertexArray(vecarry1.get());
    geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, 2));
    osg::ref_ptr<osg::StateSet> stateset = geometry->getOrCreateStateSet();
    osg::ref_ptr<osg::LineWidth> lineWid = new osg::LineWidth(linewidth);
    stateset->setAttribute(lineWid);
    geometry->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源

    geometry->setColorArray(colors.get());
    geometry->setColorBinding(osg::Geometry::BIND_OVERALL);
    return geometry;
}

//绘制虚线
osg::ref_ptr<osg::Geometry> DamageDescription::DrawStippleLine(osg::Vec3 startvec3, osg::Vec3 endvec3, osg::ref_ptr<osg::Vec4Array> colors, double linewidth)
{
    osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;

    osg::ref_ptr<osg::Vec3Array> vecarry1 = new osg::Vec3Array();
    vecarry1->push_back(startvec3);
    vecarry1->push_back(endvec3);
    geometry->setVertexArray(vecarry1.get());
    geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, 2));
    osg::ref_ptr<osg::StateSet> stateset = geometry->getOrCreateStateSet();
    osg::ref_ptr<osg::LineWidth> lineWid = new osg::LineWidth(linewidth);
    stateset->setAttribute(lineWid);
    osg::ref_ptr<osg::LineStipple> linestipple=new osg::LineStipple(1,0xf0f0);  //设置虚线模式
    stateset->setAttribute(linestipple);
    geometry->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源
    geometry->setColorArray(colors.get());
    geometry->setColorBinding(osg::Geometry::BIND_OVERALL);
    return geometry;
}

//绘制图片
osg::ref_ptr<osg::Geometry> DamageDescription::DrawPicture1(string filepath,osg::Vec3 position)
{
    osg::ref_ptr<osg::Geometry>geometry3=new osg::Geometry;
    geometry3=osg::createTexturedQuadGeometry(position,osg::Vec3(20.0f,0.0f,0.0f),osg::Vec3(0.0f,20.0f,0.0f)); //绘制矩形框（中心、宽、高）

    //读取图片，用于贴图（osg自带的资源）
    osg::ref_ptr<osg::Image> mImage = osgDB::readImageFile(filepath);

    if (mImage.get())
    {
        //关联image
        osg::ref_ptr<osg::Texture2D> texture=new osg::Texture2D();
        texture->setImage(mImage.get());

        //设置自动生成纹理坐标
        osg::ref_ptr<osg::TexGen> texgen=new osg::TexGen();
        texgen->setMode(osg::TexGen::SPHERE_MAP);

        //设置纹理环境，模式为BLEND
        osg::ref_ptr<osg::TexEnv> texenv=new osg::TexEnv;
        texenv->setMode(osg::TexEnv::Mode::ADD);
        texenv->setColor(osg::Vec4(0.6,0.6,0.6,0.0));

        //启动单元一自动生成纹理坐标，并使用纹理
        osg::ref_ptr<osg::StateSet> state=new osg::StateSet;
        //关联Texture2D纹理对象，第三个参数默认为ON(一定要注意下面三个函数参数的设置)
        state->setTextureAttributeAndModes(0,texture.get(),osg::StateAttribute::ON);
        state->setTextureAttributeAndModes(1,texgen.get(),osg::StateAttribute::ON);
        state->setTextureAttribute(1,texenv.get());
        //启用混合
        state->setMode(GL_BLEND, osg::StateAttribute::ON);
        //关闭光源
        state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

        geometry3->setStateSet(state.get());

    }
    return geometry3;
}

//绘制矩形
osg::ref_ptr<osg::Geometry> DamageDescription::DrawRectangle(osg::Vec3 position, osg::ref_ptr<osg::Vec4Array> colorArray)
{
    osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
    geometry=osg::createTexturedQuadGeometry(position,osg::Vec3(20.0f,0.0f,0.0f),osg::Vec3(0.0f,15.0f,0.0f));
    geometry->setColorArray(colorArray.get());
    geometry->setColorBinding(osg::Geometry::BIND_OVERALL);
    return geometry;
}

//布告板技术
//创建树木（使用布告板技术）
osg::ref_ptr<osg::Node> DamageDescription::CreateBillboard(osg::ref_ptr<osg::Image> mImage)
{
    //创建四边形
    osg::ref_ptr<osg::Geometry> mGeometry = new osg::Geometry;

    //设置顶点
    osg::ref_ptr<osg::Vec3Array> mVertexArray = new osg::Vec3Array;
    mVertexArray->push_back(osg::Vec3(-0.5f, 0.0f, -0.5f));
    mVertexArray->push_back(osg::Vec3(0.5f, 0.0f, -0.5f));
    mVertexArray->push_back(osg::Vec3(0.5f, 0.0f, 0.5f));
    mVertexArray->push_back(osg::Vec3(-0.5f, 0.0f, 0.5f));
    mGeometry->setVertexArray(mVertexArray);

    //设置法线
    osg::ref_ptr<osg::Vec3Array> mNormal = new osg::Vec3Array;
    mNormal->push_back(osg::Vec3(1.0f, 0.0f, 0.0f) ^ osg::Vec3(0.0f, 0.0f, 1.0f));
    mGeometry->setNormalArray(mNormal);
    mGeometry->setNormalBinding(osg::Geometry::BIND_OVERALL);

    //设置纹理坐标（没看懂）
    osg::ref_ptr<osg::Vec2Array> mTextureArray = new osg::Vec2Array;
    mTextureArray->push_back(osg::Vec2(0.0f, 0.0f));
    mTextureArray->push_back(osg::Vec2(1.0f, 0.0f));
    mTextureArray->push_back(osg::Vec2(1.0f, 1.0f));
    mTextureArray->push_back(osg::Vec2(0.0f, 1.0f));
    mGeometry->setTexCoordArray(0, mTextureArray);

    //绘制四边形
    mGeometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS, 0, 4));

    if (mImage)
    {
        //状态属性对象
        osg::ref_ptr<osg::StateSet> mStateSet = new osg::StateSet;
        //创建一个Texture2D属性对象
        osg::ref_ptr<osg::Texture2D> mTexture = new osg::Texture2D;
        //关联image
        mTexture->setImage(mImage);
        //关联Texture2D纹理对象，第三个参数默认为ON
        mStateSet->setTextureAttributeAndModes(0, mTexture, osg::StateAttribute::ON);
        //启用混合
        mStateSet->setMode(GL_BLEND, osg::StateAttribute::ON);
        //关闭光源
        mStateSet->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
        mGeometry->setStateSet(mStateSet);
    }

    //创建Billboard对象1
    osg::ref_ptr<osg::Billboard> mBillboard1 = new osg::Billboard;
    //设置旋转模式为绕视点
    mBillboard1->setMode(osg::Billboard::POINT_ROT_EYE);
    //添加Drawable, 并设置位置
    mBillboard1->addDrawable(mGeometry, osg::Vec3(0.0f, 0.0f, 0.0f));

    osg::ref_ptr<osg::Group> mBillboardGroup = new osg::Group;
    mBillboardGroup->addChild(mBillboard1);

    return mBillboardGroup.get();
}

//勾选不安全建筑
osg::ref_ptr<osg::Geometry> DamageDescription::DrawSelectRectangle(osg::Vec3 pos1, osg::Vec3 pos2)
{
//    osg::ref_ptr<osg::Geometry>geom=new osg::Geometry;

//    //创建顶点数组，注意顶点的添加顺序是逆时针的
//    osg::ref_ptr<osg::Vec3Array> v = new osg::Vec3Array();
//    //添加数据
//    v->push_back(osg::Vec3(pos1._v[0], pos1._v[1], pos1._v[2]));
//    v->push_back(osg::Vec3(pos2._v[0], pos1._v[1], pos1._v[2]));
//    v->push_back(osg::Vec3(pos2._v[0], pos2._v[1], pos1._v[2]));
//    v->push_back(osg::Vec3(pos1._v[0], pos2._v[1], pos1._v[2]));
//    geom->setVertexArray(v.get());

//    geom->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_LOOP, 0, 4));
//    geom->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS, 0, 4));

//    osg::ref_ptr<osg::StateSet> stateset = geom->getOrCreateStateSet();
//    osg::ref_ptr<osg::LineWidth> lineWid = new osg::LineWidth(10.0);
//    stateset->setAttribute(lineWid);
//    osg::ref_ptr<osg::LineStipple> linestipple=new osg::LineStipple(2,0xf0f0);  //设置虚线模式
//    stateset->setAttribute(linestipple);
//    geom->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源
//    geom->setColorBinding(osg::Geometry::BIND_OVERALL);

//    return geom;

    osg::ref_ptr<osg::Vec4Array> colors = new osg::Vec4Array;
        //添加数据
//    colors->push_back(osg::Vec4(0.1, 0.6, 1.0, 0.3));
    colors->push_back(osg::Vec4(0.0, 0.0, 1.0, 0.3));
    osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
    osg::Vec3 width=osg::Vec3(pos2._v[0]-pos1._v[0],0.0f,0.0f);
    osg::Vec3 height=osg::Vec3(0.0f,pos2._v[1]-pos1._v[1],0.0f);

    cout<<"Width: "<<pos2._v[0]-pos1._v[0]<<" "<<"Height: "<<pos2._v[1]-pos1._v[1]<<endl;

    geometry=osg::createTexturedQuadGeometry(pos1,width,height);
    geometry->setColorArray(colors.get());
    geometry->setColorBinding(osg::Geometry::BIND_OVERALL);

    //开启融合操作
    geometry ->getOrCreateStateSet()->setMode(GL_BLEND, osg::StateAttribute::ON);
    //设置渲染模式
    geometry ->getOrCreateStateSet()->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
    //关闭光照，这样任意面，都可以看到半透明效果。
    geometry ->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

    return geometry;
}


//修改节点rgb值
void DamageDescription::modifyNodeRGB(osg::ref_ptr<osg::Node> node, osg::Vec4 rgb)
{
    osg::Material *material = new osg::Material;
    material->setDiffuse(osg::Material::FRONT, rgb);
    material->setAmbient(osg::Material::FRONT, rgb);
    material->setShininess(osg::Material::FRONT, 90.0);
    //geode->getOrCreateStateSet()->setAttribute(material);
    node->getOrCreateStateSet()->setAttribute(material);
}

//展示
osg::ref_ptr<osg::Group> DamageDescription::newroot(int index)
{
//    QString EPath =  QCoreApplication::applicationDirPath();

    ReadshpDialog *rdg = new ReadshpDialog();

//    std::string path = return_ViewTree_Path(NOW_NODENAME).toStdString();
    osg::ref_ptr<osg::Group> root = new osg::Group;


    XMLDoc *pXmlDoc=new XMLDoc();
    vector<string> pVectorMaskBuilding=pXmlDoc->readXml("MaskBuilding");
    vector<string> pVectorMaskRiver=pXmlDoc->readXml("MaskRiver");
    vector<string> pVectorMaskRoad=pXmlDoc->readXml("MaskRoad");
    std::string maskriverpath,uspath,maskbuildingpath="";
    osg::ref_ptr<osg::Node> maskriver = new osg::Node;
    osg::ref_ptr<osg::Node> unsaferoad = new osg::Node;

    if(pVectorMaskBuilding.size()!=0)
    {
        maskbuildingpath = pVectorMaskBuilding[0];
    }
    if(pVectorMaskRiver.size()!=0)
    {
       maskriverpath = pVectorMaskRiver[0];
    }
    if(pVectorMaskRoad.size()!=0)
    {
        uspath = pVectorMaskRoad[0];
    }

     //场景地物
//    osg::ref_ptr<osg::Node> maskriver =osgDB::readNodeFile(pVectorMaskRiver[0]);//淹没河道
    if(maskriverpath!="")
    {
    rdg->color = QColor(34,221,221);
    rdg->read_shp(maskriverpath.c_str());    
    maskriver = rdg->draw_SHP()->asNode();

    }


//    osg::ref_ptr<osg::Node> unsaferoad =osgDB::readNodeFile(pVectorMaskRoad[0]); //受损道路
    if(uspath!=""){
    rdg->line_stipple=1;
//    rdg->color = QColor(204,204,51);
    rdg->color = QColor(207,89,25);
    rdg->linew = 3.0f;
    rdg->read_shp(uspath.c_str());
    unsaferoad = rdg->draw_SHP()->asNode();
    rdg->line_stipple=0;
    }

     if(index==1)
     {
         //=====1.河流
         if(maskriverpath!=""){
             root->addChild(maskriver);
         }
     }else if(index==2){
         //=====2.道路
         if(uspath!=""){

             root->addChild(unsaferoad);
         }
     }else if(index==3){
         if(maskbuildingpath!=""){
         maskbuildingpath+="maskbuilding/";
         }
         //获取文件夹下某类文件的数目
         QDir *dir=new QDir(QString::fromStdString(maskbuildingpath));
         QStringList filter;
         filter<<"*.shp";
         dir->setNameFilters(filter);
         QList<QFileInfo> *fileInfo=new QList<QFileInfo>(dir->entryInfoList(filter));
         cout<<"fileInfo:  "<<fileInfo->count();

         for(int i=1;i<fileInfo->count()+1;i++){
             //=====3.房屋
             //推高建筑物
             //读取不安全建筑shp(用Geode添加)
             //加载受损房屋
             std::string path = maskbuildingpath+"maskbuilding"+std::to_string(i)+".shp";

            rdg->color = QColor(230,148,26);
            rdg->read_shp(path.c_str());
            root->addChild(rdg->draw_SHP()->asNode());
             list2=gdal_read_polygonshp(path.c_str());  //保存shp坐标点
             std::list<std::list<Point3D>>::iterator it2;
             //设置颜色
             osg::ref_ptr<osg::Vec4Array> housecolors = new osg::Vec4Array;
             //添加数据
             housecolors->push_back(osg::Vec4(255, 0.0, 0.0, 1.0));
             for ( it2=list2.begin() ; it2 != list2.end(); it2++ )
             {
                 plist=*it2;
                 osg::ref_ptr<osg::Geode> building1_prjnode=Drawsamplehouse(plist,housecolors);
                 //关闭光源(必须添加，不然会影响加载的其他shp，导致光线变黑)
                 building1_prjnode->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);//关闭光源
                 root->addChild(building1_prjnode.get());
             }
             osg::Depth* dep = new osg::Depth;     //case中有定义，必须加{}，不然直接会跳到default
             dep->setFunction(osg::Depth::Function::ALWAYS);
             root->getOrCreateStateSet()->setAttribute(dep, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
             root->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
             // 设置渲染系数，哪个模型要显示在前面，就调大该模型的渲染系数
             root->getOrCreateStateSet()->setRenderBinDetails(10, "RenderBin");


         }
     }

     delete rdg;
     return root;


}

osg::ref_ptr<osg::Camera> DamageDescription::CreateDamHUD(){
    //图例面板背景颜色
      osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
      osg::ref_ptr<osg::Vec4Array>colorArray=new osg::Vec4Array;
      geometry=osg::createTexturedQuadGeometry(osg::Vec3(620.0f,500.0f,0.0f),
                                               osg::Vec3(180.0f,0.0f,0.0f),osg::Vec3(0.0f,100.0f,0.0f));

      colorArray->push_back(osg::Vec4(0.8,0.8,0.8,0.5f));
      geometry->setColorArray(colorArray.get());
      geometry->setColorBinding(osg::Geometry::BIND_OVERALL);

      //文字

      //房屋
      osgText::Text *text2=new osgText::Text;
      //设置字体
      text2->setFont("fonts/simhei.ttf");
      //设置文字显示的位置
      text2->setPosition(osg::Vec3(640.0f,570.0f,0.0f));
      text2->setColor(osg::Vec4( 0, 0, 0, 1));
      std::string dhouse = "受损房屋约: 103栋 ";//+std::to_string(runTime)+" 秒";

      const char* housec = dhouse.c_str();
      QTextCodec* code2 = QTextCodec::codecForName("UTF-8");
      QString qstr2 = QObject::tr(housec);
      std::string str2 = code2->fromUnicode(qstr2).data();
      text2->setText(str2, osgText::String::ENCODING_UTF8);
      text2->setCharacterSize(12);  //设置字体大小


      //公路

      osgText::Text *text3=new osgText::Text;
      //设置字体
      text3->setFont("fonts/simhei.ttf");
      //设置文字显示的位置
      text3->setPosition(osg::Vec3(640.0f,540.0f,0.0f));
      text3->setColor(osg::Vec4( 0, 0, 0, 1));
      std::string road = "损坏公路约: 2.1千米";//+std::to_string(vol)+" 立方米";

      const char* roadc = road.c_str();
      QTextCodec* code3 = QTextCodec::codecForName("UTF-8");
      QString qstr3 = QObject::tr(roadc);
      std::string str3 = code3->fromUnicode(qstr3).data();
      text3->setText(str3, osgText::String::ENCODING_UTF8);
      text3->setCharacterSize(12);  //设置字体大小


      //河道

      osgText::Text *text4=new osgText::Text;
      //设置字体
      text4->setFont("fonts/simhei.ttf");
      //设置文字显示的位置
      text4->setPosition(osg::Vec3(640.0f,510.0f,0.0f));
      text4->setColor(osg::Vec4( 0, 0, 0, 1));
      std::string river = "掩埋河道约: 2千米";

      const char* riverc = river.c_str();
      QTextCodec* code4 = QTextCodec::codecForName("UTF-8");
      QString qstr4 = QObject::tr(riverc);
      std::string str4 = code4->fromUnicode(qstr4).data();
      text4->setText(str4, osgText::String::ENCODING_UTF8);
      text4->setCharacterSize(12);  //设置字体大小

      //耕地

      osgText::Text *text1=new osgText::Text;
      //设置字体
      text1->setFont("fonts/simhei.ttf");
      //设置文字显示的位置
      text1->setPosition(osg::Vec3(640.0f,490.0f,0.0f));
      text1->setColor(osg::Vec4( 0, 0, 0, 1));
      std::string farmland = "灭失耕地约: 38亩";//+std::to_string(vol)+" 立方米";

      const char* farmlandc = farmland.c_str();
      QTextCodec* code1 = QTextCodec::codecForName("UTF-8");
      QString qstr1 = QObject::tr(farmlandc);
      std::string str1 = code1->fromUnicode(qstr1).data();
      text1->setText(str1, osgText::String::ENCODING_UTF8);
      text1->setCharacterSize(12);  //设置字体大小


      //几何体节点
      osg::Geode*geode=new osg::Geode();
      geode->addChild(geometry);

      //将文字Text作这drawable加入到Geode节点中
//      geode->addDrawable(text);
      geode->addDrawable(text1); //将文字Text作这drawable加入到Geode节点中
      geode->addDrawable(text2); //将文字Text作这drawable加入到Geode节点中
      geode->addDrawable(text3); //将文字Text作这drawable加入到Geode节点中
      geode->addDrawable(text4);



      //设置状态
      osg::StateSet* stateset = geode->getOrCreateStateSet();
      stateset->setMode(GL_LIGHTING,osg::StateAttribute::OFF);//关闭灯光
      stateset->setMode(GL_DEPTH_TEST,osg::StateAttribute::OFF);//关闭深度测试
      //打开GL_BLEND混合模式（以保证Alpha纹理正确）
      stateset->setMode(GL_BLEND,osg::StateAttribute::ON);

      //相机
      osg::Camera* camera = new osg::Camera;
      //设置透视矩阵
      camera->setProjectionMatrix(osg::Matrix::ortho2D(0,800,0,600));//正交投影
      //设置绝对参考坐标系，确保视图矩阵不会被上级节点的变换矩阵影响
      camera->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
      //视图矩阵为默认的
      camera->setViewMatrix(osg::Matrix::identity());
      //设置背景为透明，否则的话可以设置ClearColor
      camera->setClearMask(GL_DEPTH_BUFFER_BIT);
      camera->setAllowEventFocus( false);//不响应事件，始终得不到焦点
      //设置渲染顺序，必须在最后渲染
      camera->setRenderOrder(osg::Camera::POST_RENDER);
      camera->addChild(geode);//将要显示的Geode节点加入到相机
      return camera;
}
