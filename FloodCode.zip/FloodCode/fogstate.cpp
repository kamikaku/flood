﻿#include "fogstate.h"

FogState::FogState()
{

}

FogCallBack::FogCallBack()
{

}

FogCallBack::~FogCallBack()
{

}

void FogCallBack::operator()(osg::StateSet *ss, osg::NodeVisitor *nv)
{
    osg::Fog* fog = dynamic_cast<osg::Fog*>(ss->getAttribute(osg::StateAttribute::FOG));
    if (fog){
        float start = fog->getStart();
        if (start<fog->getEnd()){
            fog->setStart(start + 2.0);
        }
    }
}

//创建烟雾
osg::ref_ptr<osg::Fog> FogState::createFog()
{
    osg::ref_ptr<osg::Fog> fog = new osg::Fog;
    fog->setColor(osg::Vec4(1.0, 1.0, 1.0, 0.5));//设置颜色
    fog->setStart(1.0);//设置雾效的近距离
    fog->setEnd(2000.0);//设置雾效的远距离
    fog->setDensity(10.0);//设置雾效的密度
    fog->setMode(osg::Fog::LINEAR);//设置雾效的类型-线型

    return fog;
}


