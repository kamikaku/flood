﻿#include "renderclass.h"


RenderClass::RenderClass()
{

}

void RenderClass::setNodeRender(osg::Node &node, float sequence)
{
    osg::Depth* dep = new osg::Depth;     //case中有定义，必须加{}，不然直接会跳到default
    dep->setFunction(osg::Depth::Function::ALWAYS);
    node.getOrCreateStateSet()->setAttribute(dep, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
    node.getOrCreateStateSet()->setMode(GL_DEPTH_TEST, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
    // 设置渲染系数，哪个模型要显示在前面，就调大该模型的渲染系数
    node.getOrCreateStateSet()->setRenderBinDetails(sequence, "RenderBin");
//    dep = nullptr;

}

void RenderClass::closeZbuffer(osg::Node &node)
{
    osg::StateSet* states =node.getOrCreateStateSet();
    osg::Depth* depth = dynamic_cast<osg::Depth*> (states->getAttribute(osg::StateAttribute::DEPTH));
    if( depth == NULL )
    {
    depth = new osg::Depth;
    states->setAttributeAndModes(depth, osg::StateAttribute::ON );
    }

    depth->setFunction(osg::Depth::ALWAYS);
    depth->setRange(100.0,1.0);
}
