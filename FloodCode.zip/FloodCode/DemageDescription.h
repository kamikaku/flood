﻿#ifndef SHPCLASS_H
#define SHPCLASS_H
#pragma execution_character_set("utf-8")

#include <osg/Image>
#include <osg/Node>
#include <osg/Texture2D>
#include <osg/TexGen>
#include <osg/TexEnv>
#include <osg/StateSet>
#include <osg/Point>
#include <osg/LineWidth>
#include <osg/LineStipple>
#include <osg/PointSprite>
#include <osg/Geometry>
#include <osgUtil/SmoothingVisitor>
#include <osg/Geode>
#include <osgText/Text>
#include <osg/StateAttribute>
#include <osg/PositionAttitudeTransform>
#include <osgDB/ReadFile>
#include <osg/Drawable>
#include <osgViewer/Viewer>
#include <osg/Group>
#include <osg/Geometry>
#include <osgGA/NodeTrackerManipulator>
#include <osgGA/AnimationPathManipulator>

#include "gdal_priv.h"
#include "gdal.h"
#include <iostream>
#include "ogrsf_frmts.h"
#include <iostream>
#include <fstream>
#include <list>
#include <iomanip>
#include "gdal_version.h"

#include <list>

#include <Windows.h>
#include <QTextCodec>
#include <QString>
#include <QObject>

//opengl的头文件和库文件
#include <gl/gl.h>
#include <gl/glu.h>

#pragma comment( lib, "osgd.lib") //.在Debug版本下的库名都加d,如"osgd.lib"
#pragma comment( lib, "osgDBd.lib")
#pragma comment( lib, "osgViewerd.lib")
#pragma comment( lib, "osgUtild.lib")

#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glu32.lib")

using namespace std;

class Point3D
{
public:
    double X; //X
    double Y; //Y
    double Z; //Z
    double height; //属性值
};

class DemageDescription
{
public:
    DemageDescription();

	//修改shp颜色
    void ChangeSHP(osg::ref_ptr<osg::Node> node, osg::Vec4 color, float size, bool IsPoint);
    osg::Image *createImage(int width, int height, osg::Vec3 color);
	
	//读取shp数据
	list<list<Point3D>> gdal_read_polygonshp(const char* path);
    list<Point3D> gdal_read_pointshp(const char* path);
	
	//绘制建筑物
	osg::ref_ptr<osg::Geometry> Drawhousehall(std::list<Point3D> plist,osg::ref_ptr<osg::Vec4Array> colors);
    osg::ref_ptr<osg::Geometry> Drawhouseroof(std::list<Point3D> plist,osg::ref_ptr<osg::Vec4Array> colors);
    osg::ref_ptr<osg::Geometry> Drawhousebuttom(std::list<Point3D> plist,osg::ref_ptr<osg::Vec4Array> colors);
    osg::ref_ptr<osg::Geode> Drawsamplehouse(std::list<Point3D> plist,osg::ref_ptr<osg::Vec4Array> colors);   //用Geode加载
	
	//创建图例
	osg::ref_ptr<osg::Node> CreateLegend(osg::ref_ptr<osg::Group> legendroot);  //传入需要绘制图例的Node
    //绘制直线
    osg::ref_ptr<osg::Geometry> DrawLine(osg::Vec3 startvec3,osg::Vec3 endvec3,osg::ref_ptr<osg::Vec4Array> colors, double linewidth);
    //绘制虚线
    osg::ref_ptr<osg::Geometry> DrawStippleLine(osg::Vec3 startvec3,osg::Vec3 endvec3,osg::ref_ptr<osg::Vec4Array> colors, double linewidth);
    //绘制图片(方法一)
    osg::ref_ptr<osg::Geode> DrawPicture(string filepath,osg::Vec3 position);
    //绘制图片(方法二效果更好)
    osg::ref_ptr<osg::Geometry> DrawPicture1(string filepath,osg::Vec3 position);
    //绘制矩形
    osg::ref_ptr<osg::Geometry> DrawRectangle(osg::Vec3 position,osg::ref_ptr<osg::Vec4Array> colorArray);
	
	
	//创建布告板
	osg::ref_ptr<osg::Node> CreateBillboard(osg::ref_ptr<osg::Image> mImage);
	
	//展示
	osg::ref_ptr<osg::Group> returnroot();


};

class DrawCallback : public osg::Drawable::DrawCallback  //全局回调
{
    virtual void drawImplementation(osg::RenderInfo& renderInfo,const osg::Drawable* drawable) const
    {
       static double dColor= 255;//颜色
       drawable->drawImplementation(renderInfo);
       glEnable(GL_LINE_STIPPLE);
       glLineWidth(100);  //必须设置在glBegin(GL_LINES)前面
       glBegin(GL_LINES);
       glEnd();
    }
};






#endif // SHPCLASS_H
