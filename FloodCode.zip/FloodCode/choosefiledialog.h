﻿#ifndef CHOOSEFILEDIALOG_H
#define CHOOSEFILEDIALOG_H
#pragma execution_character_set("utf-8")
#include <QFileDialog>
#include <QDialog>
#include <QMessageBox>
#include <QDialog>
#include <QDebug>
#include "filemanagement.h"

extern std::list<FileManage> BindingFiles;
namespace Ui {
class ChooseFileDialog;
}

class ChooseFileDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ChooseFileDialog(QWidget *parent = 0);
    ~ChooseFileDialog();

private slots:
    void on_chooseButton_clicked();

    void on_ConfirmButton_clicked();

private:
    Ui::ChooseFileDialog *ui;

public:
    QString path;
    QString nodename;
    QString nodetype;
};

#endif // CHOOSEFILEDIALOG_H
