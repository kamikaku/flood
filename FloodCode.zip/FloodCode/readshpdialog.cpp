﻿#include "readshpdialog.h"
#include "ui_readshpdialog.h"



std::string UtfToString(std::string strValue)

{

    int nwLen = ::MultiByteToWideChar(CP_ACP, 0, strValue.c_str(), -1, NULL, 0);
    wchar_t * pwBuf = new wchar_t[nwLen + 1];//加上末尾'\0'
    ZeroMemory(pwBuf, nwLen * 2 + 2);
    ::MultiByteToWideChar(CP_ACP, 0, strValue.c_str(), strValue.length(), pwBuf, nwLen);
    int nLen = ::WideCharToMultiByte(CP_UTF8, 0, pwBuf, -1, NULL, NULL,     NULL, NULL);
    char * pBuf = new char[nLen + 1];
    ZeroMemory(pBuf, nLen + 1);
    ::WideCharToMultiByte(CP_UTF8, 0, pwBuf, nwLen, pBuf, nLen, NULL, NULL);
    std::string retStr(pBuf);
    delete []pwBuf;
    delete []pBuf;
    pwBuf = NULL;
    pBuf = NULL;
    return retStr;
}

std::string StringToUtf(std::string strValue)

{

    int nwLen = MultiByteToWideChar(CP_UTF8, 0, strValue.c_str(), -1, NULL, 0);
    wchar_t * pwBuf = new wchar_t[nwLen + 1];//加上末尾'\0'
    memset(pwBuf, 0, nwLen * 2 + 2);
    MultiByteToWideChar(CP_UTF8, 0, strValue.c_str(), strValue.length(), pwBuf, nwLen);
    int nLen = WideCharToMultiByte(CP_ACP, 0, pwBuf, -1, NULL, NULL, NULL, NULL);
    char * pBuf = new char[nLen + 1];
    memset(pBuf, 0, nLen + 1);
    WideCharToMultiByte(CP_ACP, 0, pwBuf, nwLen, pBuf, nLen, NULL, NULL);
    std::string retStr = pBuf;
    delete []pBuf;
    delete []pwBuf;
    return retStr;

}




ReadshpDialog::ReadshpDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ReadshpDialog)
{
    ui->setupUi(this);
    ui->colorshow->clear();
    QPalette palette;
    palette.setColor(QPalette::Background, QColor(255,0,0));
    ui->colorshow->setAutoFillBackground(true);  //一定要这句，否则不行
    ui->colorshow->setPalette(palette);
    QPalette palettet;
    palettet.setColor(QPalette::Background,QColor(0,0,0));
    ui->textcolor->setAutoFillBackground(true);
    ui->textcolor->setPalette(palettet);

    QRegExp regx("[0-9]+$");
    QValidator *validator = new QRegExpValidator(regx,ui->txsize);
    ui->txsize->setValidator(validator);

}

ReadshpDialog::~ReadshpDialog()
{
    delete ui;
}

void ReadshpDialog::on_pushButton_2_clicked()
{
    color = QColorDialog::getColor(Qt::red,this,"选择你要的颜色");
    ui->colorshow->clear();
    QPalette palette;
    palette.setColor(QPalette::Background, color);
    ui->colorshow->setAutoFillBackground(true);  //一定要这句，否则不行
    ui->colorshow->setPalette(palette);

}

void ReadshpDialog::on_choosefile_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(
        this,
        tr("打开shapefile."),
        ".",
        tr("shapefile(*.shp);;All files(*.*)"));
    if (fileName.isEmpty()) {
//        QMessageBox::warning(this, "警告!", "打开文件失败");
    }
    else {
        ui->filepath->setPlaceholderText(fileName);
        filep = fileName.toStdString();
    }

}

void ReadshpDialog::on_pushButton_clicked()
{

    //清空三个vector
    shp_Line.clear();
    shp_Point.clear();
    shp_Polygon.clear();
    type=0;
    //字体
    txsize = ui->txsize->text().toInt();
    //判断文件是否存在
    const char* path = filep.c_str();

    QFileInfo f(path);
    if(f.exists()==false)
    {
        QMessageBox::warning(this, "警告!", "文件不存在");
        return;
    }
//    read_shp(path);

//    osg::ref_ptr<osg::Group> group = draw_SHP();
    shapeFormat* sft = new shapeFormat(filep,color,txcolor,txsize);


    emit(sendGroup(sft));


}




void ReadshpDialog::read_shp(const char* path){

        GDALAllRegister();
        GDALDataset *poDS;
        CPLSetConfigOption("GDAL_FILENAME_IS_UTF8","NO");
//        CPLSetConfigOption("SHAPE_ENCODING","UTF-8");//解决中文乱码
        poDS = (GDALDataset*)GDALOpenEx(path,GDAL_OF_VECTOR,NULL,NULL,NULL);
        if(poDS == NULL){
            std::cout<<"Open failed"<<std::endl;
            drawable = false;
            return;
        }
        int nLayerCnt = poDS->GetLayerCount();
        int nLayerIdx = 0;
        for(;nLayerIdx<nLayerCnt;++nLayerIdx){

            OGRLayer* curLayer = poDS->GetLayer(nLayerIdx);
            GIntBig nFtrCount = curLayer->GetFeatureCount();
            if(curLayer->GetName() != NULL){
              std::cout << curLayer->GetName() << " 's FeatureCount :" << nFtrCount << std::endl;
            }

            OGRFeature* ftr = curLayer->GetNextFeature();
            double height;
            std::string gname;
            while(ftr){
                height = ftr->GetFieldAsDouble("Height");
                if(height==0.0)
                {
                    height = 50.0;
                }
                gname = ftr->GetFieldAsString("NAME1");
//                gname = StringToUtf(gname);

                if(gname==""){
                    gname = "";
                }
                else{
//                    std::cout<<gname<<std::endl;
                }
                //读取每个要素这里分类分为 点，线，面
                OGRGeometry* poGem = ftr->GetGeometryRef();
                switch(wkbFlatten(poGem->getGeometryType())){
                    case wkbPoint:
                    {

                        OGRPoint* poPS = static_cast<OGRPoint*>(poGem);
                        Point3D p_Point3D;
                        p_Point3D.X = poPS->getX();
                        p_Point3D.Y = poPS->getY();
                        p_Point3D.Z = poPS->getZ();
                        p_Point3D.Name = gname;
                        shp_Point.push_back(p_Point3D);
                        type = 1;
                    }
                    break;
                    case wkbLineString:
                    {
                       Line3D* line = new Line3D;
//                       line->color = osg::Vec4(color.redF(),color.greenF(),color.blueF(),color.alphaF());
                       line->color = osg::Vec4(color.redF(),color.greenF(),color.blueF(),alpha);
                       line->Name = gname;
                       OGRLineString* poLS = static_cast<OGRLineString*>(poGem);
                       int iPnum = poLS->getNumPoints();
                       for(int i=0;i<iPnum;i++){
                           Point3D p3d;
                           p3d.X = poLS->getX(i);
                           p3d.Y = poLS->getY(i);
                           p3d.Z = poLS->getZ(i);
                           line->line.push_back(p3d);

                       }
                       shp_Line.push_back(*line);
                       type = 2;
                       delete line;
                    }
                    break;
                    case wkbPolygon:
                    {
                        Polygon3D* polygon = new Polygon3D;
//                        polygon->color = osg::Vec4(color.redF(),color.greenF(),color.blueF(),color.alphaF());
                        polygon->color = osg::Vec4(color.redF(),color.greenF(),color.blueF(),alpha);
                        polygon->Name = gname;
                        OGRPolygon* poPoly = static_cast<OGRPolygon*>(poGem);
                        poPoly->closeRings();
                        OGRLinearRing* poLR = poPoly->getExteriorRing();
                        int Num = poLR->getNumPoints();
                        for(int i=0;i<Num;i++){
                            Point3D p3d;
                            p3d.X = poLR->getX(i);
                            p3d.Y = poLR->getY(i);
                            p3d.Z = poLR->getZ(i);
                            polygon->ploygon.push_back(p3d);
                        }
                        shp_Polygon.push_back(*polygon);
                        type = 3;
                        delete polygon;
                    }
                    break;
                default:
                    break;
                }

                ftr = curLayer->GetNextFeature();
            }


        }
}



//把读取的shp画出来，并标上文字
osg::ref_ptr<osg::Group> ReadshpDialog::draw_SHP(){



    osg::ref_ptr<osg::Group> gp = new osg::Group;

    if(!drawable){
        drawable = true;
        return gp.get();
    }
    if(shp_Point.begin()==shp_Point.end()&&shp_Line.begin()==shp_Line.end()&&shp_Polygon.begin()==shp_Polygon.end()){
        return gp.get();
    }

    if(shp_Point.size()==0&&shp_Line.size()==0&&shp_Polygon.size()==0)
    {
        return gp.get();
    }
    osg::StateSet* states = new osg::StateSet;
    osg::Depth* depth = new osg::Depth;
    //如果是点，只把文字标记上去
    if(type==1){
        osg::ref_ptr<osg::Geode> geode = new osg::Geode;
        for(unsigned i=0;i<shp_Point.size();i++){
            osg::ref_ptr<osgText::Text> text = new osgText::Text;
           Point3D p3d = shp_Point[i];
           const char* str = p3d.Name.c_str();
           QTextCodec* code = QTextCodec::codecForName("UTF-8");
           text->setFont("fonts/simhei.ttf");
           QString qstr = QObject::tr(str);
           std::string strt = code->fromUnicode(qstr).data();

           text->setText(strt,osgText::String::ENCODING_UTF8);
//           text->setColor(osg::Vec4(0.0f,0.0f,0.0f,1.0f));
           text->setColor(osg::Vec4(txcolor.redF(),txcolor.greenF(),txcolor.blueF(),txcolor.alphaF()));
//           text->setColor(osg::Vec4(0.8,0.8,0.8,1));
           text->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
           text->setAutoRotateToScreen(true);
           text->setCharacterSize(txsize);
           text->setPosition(osg::Vec3(p3d.X,p3d.Y,p3d.Z+5));
//           text->getOrCreateStateSet()->setRenderBinDetails(4,"RenderBin");
           text->setDataVariance(osg::Object::DYNAMIC);
//           text->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//           text->setBoundingBoxColor(osg::Vec4(1,1,0.6,1));
           text->setBackdropType(osgText::Text::OUTLINE);//文件描边
           text->setBackdropColor(osg::Vec4(0.0,0.0,0.0,1));//文字描边
           geode->addDrawable(text.get());
            states = geode->getOrCreateStateSet();
            depth = dynamic_cast<osg::Depth*> (states->getAttribute(osg::StateAttribute::DEPTH));
           if( depth == NULL )
           {
                   depth = new osg::Depth;
                   states->setAttributeAndModes(depth, osg::StateAttribute::ON );
           }
           depth->setFunction(osg::Depth::ALWAYS);
           depth->setRange(100.0,1.0);

        }
//        geode->getOrCreateStateSet()->setRenderBinDetails(-7,"RenderBin");
        gp->addChild(geode.get());
    }

    //如果是线，osg画线
    else if(type==2){
        osg::ref_ptr<osg::Geode> geode = new osg::Geode;
        osg::ref_ptr<osg::Geode> geodeT = new osg::Geode;
        for(unsigned i=0;i<shp_Line.size();i++){
            Line3D l3d= shp_Line[i];
            osg::ref_ptr<osg::Geometry> geometry=new osg::Geometry;
            osg::ref_ptr<osg::Vec3Array> vecarry1 = new osg::Vec3Array();
            for(unsigned j=0;j<l3d.line.size();j++){

                Point3D p3d = l3d.line[j];
                vecarry1->push_back(osg::Vec3(p3d.X,p3d.Y,p3d.Z));
            }
            if(line_stipple==0){
            geometry->setVertexArray(vecarry1.get());
            geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, vecarry1->getNumElements()));
            geode->addDrawable(geometry.get());
            //设定颜色,线的宽度
            osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth(linew);
            geometry->getOrCreateStateSet()->setAttribute(lw,osg::StateAttribute::ON);
            osg::ref_ptr<osg::Vec4Array> colors = new osg::Vec4Array;
            colors->push_back(l3d.color);
            geometry->setColorArray(colors, osg::Array::BIND_OVERALL);
            }
            if(line_stipple==1){
                geometry->setVertexArray(vecarry1.get());
                osg::ref_ptr<osg::LineStipple> linestipple(new osg::LineStipple(3,0x3F07));
                geometry->getOrCreateStateSet()->setAttributeAndModes(linestipple.get(),osg::StateAttribute::ON|osg::StateAttribute::OVERRIDE);
                geometry->addPrimitiveSet(new osg::DrawArrays(GL_LINE_STRIP,0,vecarry1->size()));
                osg::ref_ptr<osg::Vec4Array> colors = new osg::Vec4Array;
                colors->push_back(l3d.color);
                osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth(linew);
                geometry->getOrCreateStateSet()->setAttribute(lw,osg::StateAttribute::ON);
                geometry->setColorArray(colors, osg::Array::BIND_OVERALL);
                geode->addDrawable(geometry.get());

            }
//            osg::Material *material = new osg::Material;
//            material->setDiffuse(osg::Material::FRONT,l3d.color);
//            material->setAmbient(osg::Material::FRONT, l3d.color);
//            material->setShininess(osg::Material::FRONT, 90.0);
//            geode->getOrCreateStateSet()->setAttribute(material);

//            gp->addChild(geode.get());

            //画完先后写文字 不用同一个geode是因为上面的用材质染色了
            if(l3d.Name!=""){
//                osg::ref_ptr<osg::Geode> geodeT = new osg::Geode;
                const char* str = l3d.Name.c_str();
                QTextCodec* code = QTextCodec::codecForName("UTF-8");
                QString qstr = QObject::tr(str);
                std::string strt = code->fromUnicode(qstr).data();
                osg::ref_ptr<osgText::Text> text = new osgText::Text;
                text->setFont("fonts/simhei.ttf");
                text->setText(strt,osgText::String::ENCODING_UTF8);
//                text->setColor(osg::Vec4(0.0f,1.0f,0.0f,1.0f));
//                text->setColor(osg::Vec4(txcolor.redF(),txcolor.greenF(),txcolor.blueF(),txcolor.alphaF()));
                text->setColor(osg::Vec4(0.8,0.8,0.8,1));
//                text->setColor(l3d.color);
                text->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
                text->setAutoRotateToScreen(true);
                text->setCharacterSize(txsize);
                osg::Vec3 v3 = geometry->getBound().center();
                text->setPosition(osg::Vec3(v3._v[0],v3._v[1],v3._v[2]+5));
                text->setDataVariance(osg::Object::DYNAMIC);
//                text->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//                text->setBoundingBoxColor(osg::Vec4(1,1,1,1));
                text->setBackdropType(osgText::Text::OUTLINE);//文件描边
                text->setBackdropColor(osg::Vec4(0.3,0.0,0.8,1));//文字描边
                geodeT->addDrawable(text.get());
                states = geodeT->getOrCreateStateSet();
                depth = dynamic_cast<osg::Depth*> (states->getAttribute(osg::StateAttribute::DEPTH));
                if( depth == NULL )
                {
                        depth = new osg::Depth;
                        states->setAttributeAndModes(depth, osg::StateAttribute::ON );
                }
                depth->setFunction(osg::Depth::ALWAYS);
                depth->setRange(100.0,1.0);
//                gp->addChild(geodeT.get());

            }
        }
        osg::Depth* dep = new osg::Depth;
        dep->setFunction(osg::Depth::Function::ALWAYS);
        geode->getOrCreateStateSet()->setAttribute(dep, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        geode->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        // 设置渲染系数，哪个模型要显示在前面，就调大该模型的渲染系数
        geode->getOrCreateStateSet()->setRenderBinDetails(renderrank, "RenderBin");
        gp->addChild(geodeT.get());
        gp->addChild(geode.get());

    }

    //如果是多边形，osg画多边形
    else if(type==3){
        osg::ref_ptr<osg::Geode> geode = new osg::Geode;
        osg::ref_ptr<osg::Geode> geodeT = new osg::Geode;
        for(unsigned i=0;i<shp_Polygon.size();i++){
            Polygon3D po3d = shp_Polygon[i];
            osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry;
            osg::ref_ptr<osg::Vec3Array> vecarry = new osg::Vec3Array();
            for(unsigned j=0;j<po3d.ploygon.size();j++){
                Point3D p3d = po3d.ploygon[j];
                vecarry->push_back(osg::Vec3(p3d.X,p3d.Y,p3d.Z));
            }
            geometry->setVertexArray(vecarry.get());
            geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::POLYGON, 0, vecarry->getNumElements()));
            //优化多边形
            osgUtil::Tessellator* tessellator = new osgUtil::Tessellator();
            tessellator->setTessellationType(osgUtil::Tessellator::TESS_TYPE_GEOMETRY);
//            tessellator->setBoundaryOnly(true);
            tessellator->setWindingType( osgUtil::Tessellator::TESS_WINDING_ODD);
            tessellator->retessellatePolygons(*geometry);
            osg::ref_ptr<osg::Vec4Array> colors = new osg::Vec4Array;
            osg::Vec4d col1(po3d.color._v[0],po3d.color._v[1],po3d.color._v[2],po3d.color._v[3]);
//            colors->push_back(po3d.color);
            colors->push_back(col1);
            geometry->setColorArray(colors, osg::Array::BIND_OVERALL);
        if(alpha!=1.0)
        {
            //设置透明度
                osg::StateSet* state_p = geometry->getOrCreateStateSet();
                state_p->setMode(GL_BLEND, osg::StateAttribute::ON);
        }
            geode->addDrawable(geometry.get());
            //设定颜色
            osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth(3.0);
            geometry->getOrCreateStateSet()->setAttribute(lw,osg::StateAttribute::ON);
//            osg::Material *material = new osg::Material;
//            material->setDiffuse(osg::Material::FRONT,po3d.color);
//            material->setAmbient(osg::Material::FRONT, po3d.color);
//            material->setShininess(osg::Material::FRONT, 90.0);
//            geode->getOrCreateStateSet()->setAttribute(material);

//            states = geode->getOrCreateStateSet();
//            depth = dynamic_cast<osg::Depth*> (states->getAttribute(osg::StateAttribute::DEPTH));
//            if( depth == NULL )
//            {
//                    depth = new osg::Depth;
//                    states->setAttributeAndModes(depth, osg::StateAttribute::ON );
//            }
//            depth->setFunction(osg::Depth::ALWAYS);
//            depth->setRange(1.0,1.0);


//            gp->addChild(geode.get());

            //画完先后写文字 不用同一个geode是因为上面的用材质染色了
            if(po3d.Name!=""){
//            osg::ref_ptr<osg::Geode> geodeT = new osg::Geode;
            const char* str = po3d.Name.c_str();
            QTextCodec* code = QTextCodec::codecForName("UTF-8");
            QString qstr = QObject::tr(str);
            std::string strt = code->fromUnicode(qstr).data();
            osg::ref_ptr<osgText::Text> text = new osgText::Text;
            text->setFont("fonts/simhei.ttf");
            text->setText(strt,osgText::String::ENCODING_UTF8);
//            text->setColor(osg::Vec4(0.0f,0.0f,0.0f,1.0f));
//            text->setColor(osg::Vec4(txcolor.redF(),txcolor.greenF(),txcolor.blueF(),txcolor.alphaF()));
            text->setColor(osg::Vec4(0.8,0.8,0.8,1));
//            text->setColor(po3d.color);
            text->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
            text->setAutoRotateToScreen(true);
            text->setCharacterSize(txsize);
            osg::Vec3 v3 = geometry->getBound().center();
            text->setPosition(osg::Vec3(v3._v[0],v3._v[1],v3._v[2]+5));
//            text->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//            text->setBoundingBoxColor(osg::Vec4(0,1,0.9,1));
            text->setBackdropType(osgText::Text::OUTLINE);//文件描边
            text->setBackdropColor(osg::Vec4(0.3,0.0,0.8,1));//文字描边
            geodeT->addDrawable(text.get());
            text->setDataVariance(osg::Object::DYNAMIC);
            states = geodeT->getOrCreateStateSet();
            depth = dynamic_cast<osg::Depth*> (states->getAttribute(osg::StateAttribute::DEPTH));
            if( depth == NULL )
            {
                    depth = new osg::Depth;
                    states->setAttributeAndModes(depth, osg::StateAttribute::ON );
            }
            depth->setFunction(osg::Depth::ALWAYS);
            depth->setRange(100.0,1.0);

//            gp->addChild(geodeT.get());
//            delete str;
//            delete material;

            }

        }
        osg::Depth* dep = new osg::Depth;
        dep->setFunction(osg::Depth::Function::ALWAYS);
        geode->getOrCreateStateSet()->setAttribute(dep, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        geode->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        // 设置渲染系数，哪个模型要显示在前面，就调大该模型的渲染系数
        geode->getOrCreateStateSet()->setRenderBinDetails(renderrank, "RenderBin");
        gp->addChild(geode.get());
        gp->addChild(geodeT.get());

    }
    alpha=1.0f;
    renderrank=3.0f;
    return gp.get();

}


osg::ref_ptr<osg::Group> ReadshpDialog::draw_text(int text){



    osg::ref_ptr<osg::Group> gp = new osg::Group;

    if(!drawable){
        drawable = true;
        return gp.get();
    }
    if(shp_Point.begin()==shp_Point.end()&&shp_Line.begin()==shp_Line.end()&&shp_Polygon.begin()==shp_Polygon.end()){
        return gp.get();
    }

    if(shp_Point.size()==0&&shp_Line.size()==0&&shp_Polygon.size()==0)
    {
        return gp.get();
    }
    osg::StateSet* states = new osg::StateSet;
    osg::Depth* depth = new osg::Depth;
    //如果是点，只把文字标记上去
    if(type==1){
        osg::ref_ptr<osg::Geode> geode = new osg::Geode;
        for(unsigned i=0;i<shp_Point.size();i++){
            osg::ref_ptr<osgText::Text> text = new osgText::Text;
           Point3D p3d = shp_Point[i];
           const char* str = p3d.Name.c_str();
           QTextCodec* code = QTextCodec::codecForName("UTF-8");
           text->setFont("fonts/simhei.ttf");
           QString qstr = QObject::tr(str);
           std::string strt = code->fromUnicode(qstr).data();

           text->setText(strt,osgText::String::ENCODING_UTF8);
//           text->setColor(osg::Vec4(0.0f,0.0f,0.0f,1.0f));
           text->setColor(osg::Vec4(txcolor.redF(),txcolor.greenF(),txcolor.blueF(),txcolor.alphaF()));
//           text->setColor(osg::Vec4(0.8,0.8,0.8,1));
           text->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
           text->setAutoRotateToScreen(true);
           text->setCharacterSize(txsize);
           text->setPosition(osg::Vec3(p3d.X,p3d.Y,p3d.Z+5));
           text->setAlignment(osgText::Text::RIGHT_TOP);
//           text->getOrCreateStateSet()->setRenderBinDetails(4,"RenderBin");
           text->setDataVariance(osg::Object::DYNAMIC);
           text->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
           text->setBoundingBoxColor(osg::Vec4((47/255.0),(85/255.0),(151/255.0),1));
//           text->setBackdropType(osgText::Text::OUTLINE);//文件描边
//           text->setBackdropColor(osg::Vec4(0.0,0.0,0.0,1));//文字描边
           geode->addDrawable(text.get());
            states = geode->getOrCreateStateSet();
            depth = dynamic_cast<osg::Depth*> (states->getAttribute(osg::StateAttribute::DEPTH));
           if( depth == NULL )
           {
                   depth = new osg::Depth;
                   states->setAttributeAndModes(depth, osg::StateAttribute::ON );
           }
           depth->setFunction(osg::Depth::ALWAYS);
           depth->setRange(100.0,1.0);

        }
//        geode->getOrCreateStateSet()->setRenderBinDetails(-7,"RenderBin");
        gp->addChild(geode.get());
    }

    //如果是线，osg画线
    else if(type==2){
        osg::ref_ptr<osg::Geode> geode = new osg::Geode;
        osg::ref_ptr<osg::Geode> geodeT = new osg::Geode;
        for(unsigned i=0;i<shp_Line.size();i++){
            Line3D l3d= shp_Line[i];
            osg::ref_ptr<osg::Geometry> geometry=new osg::Geometry;
            osg::ref_ptr<osg::Vec3Array> vecarry1 = new osg::Vec3Array();
            for(unsigned j=0;j<l3d.line.size();j++){

                Point3D p3d = l3d.line[j];
                vecarry1->push_back(osg::Vec3(p3d.X,p3d.Y,p3d.Z));
            }
            if(line_stipple==0){
            geometry->setVertexArray(vecarry1.get());
            geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, vecarry1->getNumElements()));
            geode->addDrawable(geometry.get());
            //设定颜色,线的宽度
            osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth(linew);
            geometry->getOrCreateStateSet()->setAttribute(lw,osg::StateAttribute::ON);
            osg::ref_ptr<osg::Vec4Array> colors = new osg::Vec4Array;
            colors->push_back(l3d.color);
            geometry->setColorArray(colors, osg::Array::BIND_OVERALL);
            }
            if(line_stipple==1){
                geometry->setVertexArray(vecarry1.get());
                osg::ref_ptr<osg::LineStipple> linestipple(new osg::LineStipple(3,0x3F07));
                geometry->getOrCreateStateSet()->setAttributeAndModes(linestipple.get(),osg::StateAttribute::ON|osg::StateAttribute::OVERRIDE);
                geometry->addPrimitiveSet(new osg::DrawArrays(GL_LINE_STRIP,0,vecarry1->size()));
                osg::ref_ptr<osg::Vec4Array> colors = new osg::Vec4Array;
                colors->push_back(l3d.color);
                osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth(linew);
                geometry->getOrCreateStateSet()->setAttribute(lw,osg::StateAttribute::ON);
                geometry->setColorArray(colors, osg::Array::BIND_OVERALL);
                geode->addDrawable(geometry.get());

            }
//            osg::Material *material = new osg::Material;
//            material->setDiffuse(osg::Material::FRONT,l3d.color);
//            material->setAmbient(osg::Material::FRONT, l3d.color);
//            material->setShininess(osg::Material::FRONT, 90.0);
//            geode->getOrCreateStateSet()->setAttribute(material);

//            gp->addChild(geode.get());

            //画完先后写文字 不用同一个geode是因为上面的用材质染色了
            if(l3d.Name!=""){
//                osg::ref_ptr<osg::Geode> geodeT = new osg::Geode;
                const char* str = l3d.Name.c_str();
                QTextCodec* code = QTextCodec::codecForName("UTF-8");
                QString qstr = QObject::tr(str);
                std::string strt = code->fromUnicode(qstr).data();
                osg::ref_ptr<osgText::Text> text = new osgText::Text;
                text->setFont("fonts/simhei.ttf");
                text->setText(strt,osgText::String::ENCODING_UTF8);
//                text->setColor(osg::Vec4(0.0f,1.0f,0.0f,1.0f));
//                text->setColor(osg::Vec4(txcolor.redF(),txcolor.greenF(),txcolor.blueF(),txcolor.alphaF()));
                text->setColor(osg::Vec4(0.8,0.8,0.8,1));
//                text->setColor(l3d.color);
                text->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
                text->setAutoRotateToScreen(true);
                text->setCharacterSize(txsize);
                osg::Vec3 v3 = geometry->getBound().center();
                text->setPosition(osg::Vec3(v3._v[0],v3._v[1],v3._v[2]+5));
                text->setDataVariance(osg::Object::DYNAMIC);
//                text->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//                text->setBoundingBoxColor(osg::Vec4(1,1,1,1));
                text->setBackdropType(osgText::Text::OUTLINE);//文件描边
                text->setBackdropColor(osg::Vec4(0.3,0.0,0.8,1));//文字描边
                geodeT->addDrawable(text.get());
                states = geodeT->getOrCreateStateSet();
                depth = dynamic_cast<osg::Depth*> (states->getAttribute(osg::StateAttribute::DEPTH));
                if( depth == NULL )
                {
                        depth = new osg::Depth;
                        states->setAttributeAndModes(depth, osg::StateAttribute::ON );
                }
                depth->setFunction(osg::Depth::ALWAYS);
                depth->setRange(100.0,1.0);
//                gp->addChild(geodeT.get());

            }
        }
        osg::Depth* dep = new osg::Depth;
        dep->setFunction(osg::Depth::Function::ALWAYS);
        geode->getOrCreateStateSet()->setAttribute(dep, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        geode->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        // 设置渲染系数，哪个模型要显示在前面，就调大该模型的渲染系数
        geode->getOrCreateStateSet()->setRenderBinDetails(renderrank, "RenderBin");
        gp->addChild(geodeT.get());
        gp->addChild(geode.get());

    }

    //如果是多边形，osg画多边形
    else if(type==3){
        osg::ref_ptr<osg::Geode> geode = new osg::Geode;
        osg::ref_ptr<osg::Geode> geodeT = new osg::Geode;
        for(unsigned i=0;i<shp_Polygon.size();i++){
            Polygon3D po3d = shp_Polygon[i];
            osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry;
            osg::ref_ptr<osg::Vec3Array> vecarry = new osg::Vec3Array();
            for(unsigned j=0;j<po3d.ploygon.size();j++){
                Point3D p3d = po3d.ploygon[j];
                vecarry->push_back(osg::Vec3(p3d.X,p3d.Y,p3d.Z));
            }
            geometry->setVertexArray(vecarry.get());
            geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::POLYGON, 0, vecarry->getNumElements()));
            //优化多边形
            osgUtil::Tessellator* tessellator = new osgUtil::Tessellator();
            tessellator->setTessellationType(osgUtil::Tessellator::TESS_TYPE_GEOMETRY);
//            tessellator->setBoundaryOnly(true);
            tessellator->setWindingType( osgUtil::Tessellator::TESS_WINDING_ODD);
            tessellator->retessellatePolygons(*geometry);
            osg::ref_ptr<osg::Vec4Array> colors = new osg::Vec4Array;
            osg::Vec4d col1(po3d.color._v[0],po3d.color._v[1],po3d.color._v[2],po3d.color._v[3]);
//            colors->push_back(po3d.color);
            colors->push_back(col1);
            geometry->setColorArray(colors, osg::Array::BIND_OVERALL);
        if(alpha!=1.0)
        {
            //设置透明度
                osg::StateSet* state_p = geometry->getOrCreateStateSet();
                state_p->setMode(GL_BLEND, osg::StateAttribute::ON);
        }
            geode->addDrawable(geometry.get());
            //设定颜色
            osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth(3.0);
            geometry->getOrCreateStateSet()->setAttribute(lw,osg::StateAttribute::ON);
//            osg::Material *material = new osg::Material;
//            material->setDiffuse(osg::Material::FRONT,po3d.color);
//            material->setAmbient(osg::Material::FRONT, po3d.color);
//            material->setShininess(osg::Material::FRONT, 90.0);
//            geode->getOrCreateStateSet()->setAttribute(material);

//            states = geode->getOrCreateStateSet();
//            depth = dynamic_cast<osg::Depth*> (states->getAttribute(osg::StateAttribute::DEPTH));
//            if( depth == NULL )
//            {
//                    depth = new osg::Depth;
//                    states->setAttributeAndModes(depth, osg::StateAttribute::ON );
//            }
//            depth->setFunction(osg::Depth::ALWAYS);
//            depth->setRange(1.0,1.0);


//            gp->addChild(geode.get());

            //画完先后写文字 不用同一个geode是因为上面的用材质染色了
            if(po3d.Name!=""){
//            osg::ref_ptr<osg::Geode> geodeT = new osg::Geode;
            const char* str = po3d.Name.c_str();
            QTextCodec* code = QTextCodec::codecForName("UTF-8");
            QString qstr = QObject::tr(str);
            std::string strt = code->fromUnicode(qstr).data();
            osg::ref_ptr<osgText::Text> text = new osgText::Text;
            text->setFont("fonts/simhei.ttf");
            text->setText(strt,osgText::String::ENCODING_UTF8);
//            text->setColor(osg::Vec4(0.0f,0.0f,0.0f,1.0f));
//            text->setColor(osg::Vec4(txcolor.redF(),txcolor.greenF(),txcolor.blueF(),txcolor.alphaF()));
            text->setColor(osg::Vec4(0.8,0.8,0.8,1));
//            text->setColor(po3d.color);
            text->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
            text->setAutoRotateToScreen(true);
            text->setCharacterSize(txsize);
            osg::Vec3 v3 = geometry->getBound().center();
            text->setPosition(osg::Vec3(v3._v[0],v3._v[1],v3._v[2]+5));
//            text->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//            text->setBoundingBoxColor(osg::Vec4(0,1,0.9,1));
            text->setBackdropType(osgText::Text::OUTLINE);//文件描边
            text->setBackdropColor(osg::Vec4(0.3,0.0,0.8,1));//文字描边
            geodeT->addDrawable(text.get());
            text->setDataVariance(osg::Object::DYNAMIC);
            states = geodeT->getOrCreateStateSet();
            depth = dynamic_cast<osg::Depth*> (states->getAttribute(osg::StateAttribute::DEPTH));
            if( depth == NULL )
            {
                    depth = new osg::Depth;
                    states->setAttributeAndModes(depth, osg::StateAttribute::ON );
            }
            depth->setFunction(osg::Depth::ALWAYS);
            depth->setRange(100.0,1.0);

//            gp->addChild(geodeT.get());
//            delete str;
//            delete material;

            }

        }
        osg::Depth* dep = new osg::Depth;
        dep->setFunction(osg::Depth::Function::ALWAYS);
        geode->getOrCreateStateSet()->setAttribute(dep, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        geode->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
        // 设置渲染系数，哪个模型要显示在前面，就调大该模型的渲染系数
        geode->getOrCreateStateSet()->setRenderBinDetails(renderrank, "RenderBin");
        gp->addChild(geode.get());
        gp->addChild(geodeT.get());

    }
    alpha=1.0f;
    renderrank=3.0f;
    return gp.get();

}



void ReadshpDialog::on_pushButton_3_clicked()
{
    txcolor = QColorDialog::getColor(Qt::red,this,"选择你要的颜色");
    ui->textcolor->clear();
    QPalette palette;
    palette.setColor(QPalette::Background, txcolor);
    ui->textcolor->setAutoFillBackground(true);  //一定要这句，否则不行
    ui->textcolor->setPalette(palette);
}


shapeFormat::shapeFormat(string path, QColor c1, QColor c2, int size)
{
    this->shpPath=path;
    this->color = c1;
    this->txcolor = c2;
    this->txsize = size;
}
