﻿#ifndef GLOBALVAR_H
#define GLOBALVAR_H
#include "filemanagement.h"
#include <iostream>

extern std::list<FileManage> BindingFiles;
extern QString NOW_NODENAME;

//根据场景树的节点名称返回路径
static QString return_ViewTree_Path(QString name){
    std::list<FileManage>::iterator it;
    for(it=BindingFiles.begin();it!=BindingFiles.end();++it){
        if(it->getName()==name)
        {
            return it->getPath();
        }
    }
}


//根据场景树的节点名称返回类型
static QString return_ViewTree_Type(QString name){
    std::list<FileManage>::iterator it;
    for(it=BindingFiles.begin();it!=BindingFiles.end();++it){
        if(it->getName()==name)
        {
            return it->getType();
        }
    }
}


//将文件读入到场景树的数据结构中
static void Vol_to_Bindfile(){

    QString json = QCoreApplication::applicationDirPath();
    json+="/TreeMeta.json";

    QFile file(json);

    if(!file.open(QIODevice::ReadOnly))
    {
        return;
    }

    QByteArray data = file.readAll();
    file.close();

    QJsonParseError json_error;
    QJsonDocument jsonDoc(QJsonDocument::fromJson(data,&json_error));

    if(json_error.error != QJsonParseError::NoError)
    {
        return;
    }

    QJsonObject rootObj = jsonDoc.object();
    //把json中的数组读出来
    QJsonArray meta = rootObj.value("test").toArray();

    //把数组中路径和名称读进list中
    for(int i=0;i<meta.count();i++){
        QJsonObject obj = meta.at(i).toObject();
        FileManage fm(obj.value("name").toString(),obj.value("path").toString(),obj.value("type").toString());
        BindingFiles.push_back(fm);
    }
}

#endif // GLOBALVAR_H
