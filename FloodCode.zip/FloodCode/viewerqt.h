﻿#ifndef VIEWERQT_H
#define VIEWERQT_H

#include "adapterwidget.h"
#include <osgViewer/Viewer>
#include <QtCore/QString>
#include <QtCore/QTimer>
#include <QtGui/QKeyEvent>
#include <QtOpenGL/QGLWidget>
#include <iostream>
#include <osgViewer/ViewerEventHandlers>


class ViewerQT:public osgViewer::Viewer,public AdapterWidget
{
public:
//    ViewerQT();
    ViewerQT(QWidget *parent = 0);

    virtual void paintGL()
    {
        frame();
    }

protected:
    QTimer _timer;
};

#endif // VIEWERQT_H
