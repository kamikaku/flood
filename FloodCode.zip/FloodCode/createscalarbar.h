﻿#ifndef CREATESCALARBAR_H
#define CREATESCALARBAR_H
#include <osg/Geode>
#include <osg/ShapeDrawable>
#include <osg/Material>
#include <osg/Texture2D>
#include <osg/MatrixTransform>
#include <osg/PositionAttitudeTransform>
#include <osg/BlendFunc>
#include <osg/ClearNode>
#include <osg/Projection>

#include <osgUtil/CullVisitor>

#include <osgGA/TrackballManipulator>
#include <osgViewer/Viewer>
#include <osgDB/ReadFile>

#include <osgSim/ScalarsToColors>
#include <osgSim/ColorRange>
#include <osgSim/ScalarBar>

#include <QTextCodec>
#include <QObject>


#include <sstream>
#include <iostream>
#include <math.h>
#include <Windows.h>

using namespace osgSim;
using osgSim::ScalarBar;
using namespace std;

class CreateScalarBar
{  //创建色带
public:
    CreateScalarBar();

    osg::ref_ptr<osg::Node> createScalarBar(osg::Vec4 shallowColor,osg::Vec4 deepColor,int minValue,int maxValue);  //创建自定义颜色集
    osg::ref_ptr<osg::Node> createScalarBar_HUD(); //创建颜色集HUD



};

#endif // CREATESCALARBAR_H
