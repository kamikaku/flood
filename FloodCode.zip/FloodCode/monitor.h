﻿#ifndef MONITOR_H
#define MONITOR_H
#pragma execution_character_set("utf-8")

#include <QtCore/QTextStream>
#include <QtCore/QFile>
#include <QtCore/QIODevice>


#include <osgDB/ReadFile>
#include <osgViewer/Viewer>
#include <osg/Geode>
#include <osg/Depth>
#include <osgText/Text>
#include <osgGA/TrackballManipulator>
#include <osg/ShapeDrawable>
#include <osg/Camera>
#include <osg/Material>
#include <QTextCodec>
#include <osg/Group>
#include <QString>
#include <QObject>
#include <osgText/Text>

#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QJsonValue>
#include <QString>
#include <QDebug>
#include <QFile>
#include <QDateTime>
#include <QDir>
#include <cmath>

#include "gdal.h"
#include "gdal_priv.h"
#include "ogrsf_frmts.h"
#include "gdal_version.h"
#include <iostream>
#include <fstream>
#include <list>
#include <iomanip>
#include "globalvar.h"




class PointM
{
public:
    double X = 0.0;
    double Y = 0.0;
    double Z = 0.0;
    float Vec = 0.0; //流速
    float Flu = 0.0; //流量
    float Dep = 0.0; //水深
    float Times=0.0;//到达时间
};



class Monitor
{
public:
    std::list<PointM> *AllMonitor = new std::list<PointM>;
public:
    void Get_Monitior(std::string path); //从shapefile中获取点，shapefile只支持点和线。将点实例为仅有坐标信息的监测点，放入list
    void Write_to_Json(std::string path); //将监测点的信息输出为json文件存储
    void Read_from_Json(std::string path); //将json文件读取后实例为监测点的list
    osg::ref_ptr<osg::Node> return_M_Info(); //将list文件转换可视节点

    bool is_Match(float x, float y, float d,float vec,float flu,float dep,float times);

};

#endif // MONITOR_H
