﻿#include "adapterwidget.h"

AdapterWidget::AdapterWidget(QWidget *parent)
    : QGLWidget(parent)
{
    _gw=new osgViewer::GraphicsWindowEmbedded(0,0,width(),height());
    setFocusPolicy(Qt::ClickFocus);

}

AdapterWidget::~AdapterWidget()
{

}

void AdapterWidget::initializeGL()
{
}

void AdapterWidget::resizeGL(int width, int height)
{
    _gw->getEventQueue()->windowResize(0,0,width,height);
    _gw->resized(0,0,width,height);
}

void AdapterWidget::mousePressEvent(QMouseEvent *event)
{
    int button=0;
    switch (event->button())
    {
    case(Qt::LeftButton):
        button=1;
        break;
    case (Qt::MidButton):
        button=2;
        break;
    case (Qt::RightButton):
        button=3;
        break;
    case (Qt::NoButton):
        button=0;
        break;
    default:
        button=0;
        break;

    }
    _gw->getEventQueue()->mouseButtonPress(event->x(),event->y(),button);

}

void AdapterWidget::mouseReleaseEvent(QMouseEvent *event)
{
    int button = 0;
    switch(event->button())
    {
    case(Qt::LeftButton):
        button = 1;
        break;
    case(Qt::MidButton):
        button = 2;
        break;
    case(Qt::RightButton):
        button = 3;
        break;
    case(Qt::NoButton):
        button = 0;
        break;
    default:
        button = 0;
        break;
    }
    _gw->getEventQueue()->mouseButtonRelease(event->x(), event->y(), button);
}

void AdapterWidget::mouseMoveEvent(QMouseEvent *event)
{

    _gw->getEventQueue()->mouseMotion(event->x(),event->y());
}

void AdapterWidget::keyPressEvent(QKeyEvent *event)
{
    int key=0;

    switch (event->key()) {
    case Qt::Key_Home:
        key=osgGA::GUIEventAdapter::KEY_Home;
        break;
    case Qt::Key_W:
        key=osgGA::GUIEventAdapter::KEY_W;
        break;
    case Qt::Key_H:
        key=osgGA::GUIEventAdapter::KEY_H;
        break;
    case Qt::Key_Space:
        key=osgGA::GUIEventAdapter::KEY_Space;
        break;
    case Qt::Key_S:
        key=osgGA::GUIEventAdapter::KEY_S;
        break;
    case Qt::Key_Q:
        key=osgGA::GUIEventAdapter::KEY_Q;
        break;
    case Qt::Key_L:
        key=osgGA::GUIEventAdapter::KEY_L;
        break;
    default:
        key=0;
        break;
    }
    _gw->getEventQueue()->keyPress((osgGA::GUIEventAdapter::KeySymbol)key);
}

void AdapterWidget::keyReleaseEvent(QKeyEvent *event)
{
    int key=0;

    switch (event->key()) {
    case Qt::Key_Home:
        key=osgGA::GUIEventAdapter::KEY_Home;
        break;
    case Qt::Key_W:
        key=osgGA::GUIEventAdapter::KEY_W;
        break;
    case Qt::Key_H:
        key=osgGA::GUIEventAdapter::KEY_H;
        break;
    case Qt::Key_Space:
        key=osgGA::GUIEventAdapter::KEY_Space;
        break;
    case Qt::Key_S:
        key=osgGA::GUIEventAdapter::KEY_S;
        break;
    default:
        key=0;
        break;
    }
    _gw->getEventQueue()->keyRelease((osgGA::GUIEventAdapter::KeySymbol)key);
}


//AdapterWidget::AdapterWidget(QWidget *parent, const char *name, const QGLWidget *shareWidget, Qt::WindowFlags f)
//{

//}
