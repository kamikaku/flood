﻿#include "monitor.h"

// 获取监测点
void Monitor::Get_Monitior(std::string path){

    std::list<PointM> *Monitors = new std::list<PointM>;

    GDALAllRegister();
    CPLSetConfigOption("SHAPE_ENCODING","");
    //读取shape文件
    GDALDataset   *poDS;
    poDS = (GDALDataset*)GDALOpenEx(path.c_str(), GDAL_OF_VECTOR, NULL, NULL, NULL);
    if(poDS == NULL){
        return;
    }

    int nLayerCnt = poDS->GetLayerCount();
    int nLayerIdx = 0;

    for(;nLayerIdx < nLayerCnt; ++nLayerIdx){
        OGRLayer* curLayer = poDS->GetLayer(nLayerIdx);
        GIntBig nFtrCount = curLayer->GetFeatureCount();
        if(NULL != curLayer->GetName())
        {
          std::cout << curLayer->GetName() << " 's FeatureCount :" << nFtrCount << std::endl;
        }
        OGRFeature * ftr = curLayer->GetNextFeature();
        double height;
        while(ftr){
            height=ftr->GetFieldAsDouble("Height");  //获取属性表值
            if(height == 0.0)
                height = 50.0;

            OGRGeometry * poGeom = ftr->GetGeometryRef();

            switch (wkbFlatten(poGeom->getGeometryType())){
            case wkbPoint:
            {
                OGRPoint* poPS = static_cast<OGRPoint*>(poGeom);                               
                PointM p;
                p.X = poPS->getX();
                p.Y = poPS->getY();
                p.Z = poPS->getZ();
                Monitors->push_front(p);

                break;

            }
            case wkbLineString:
            {
                OGRLineString* poLS = static_cast<OGRLineString*>(poGeom);
                const char* pGeoName = poLS->getGeometryName();
                if (NULL != pGeoName)
                {
                    std::cout << " Geo name:" << pGeoName << std::endl;
                }
                int iPnum = poLS->getNumPoints();
                std::cout << " Point Count:" << iPnum;
                double iLen = poLS->get_Length();
                std::cout << " Len :" << iLen;
                for (int i = 0; i < iPnum; i++)
                {
                    PointM p;
                    p.X = poLS->getX(i);
                    p.Y = poLS->getY(i);
                    p.Z = poLS->getZ(i);
                    Monitors->push_back(p);
                }

                break;
            }
            default:
                break;

            }
            ftr = curLayer->GetNextFeature();
        }
        delete curLayer;
    }

    this->AllMonitor = Monitors;
}

//输出监测点
void Monitor::Write_to_Json(std::string path){
//存为json文件
    QString qpath = QString::fromStdString(path);

    QJsonArray properties;
    std::list<PointM>::iterator itr;
    if(!AllMonitor->empty()){
      //把所有点放入到json数组中
      for(itr = AllMonitor->begin(); itr!=AllMonitor->end();itr++){
           QJsonObject obj;
           obj.insert("x",itr->X);
           obj.insert("y",itr->Y);
           obj.insert("z",itr->Z);
           obj.insert("vec",itr->Vec);
           obj.insert("flu",itr->Flu);
           obj.insert("dep",itr->Dep);
           obj.insert("time",itr->Times);
           properties.append(obj);

      }

      QJsonObject AMP;
      AMP.insert("Monitors",properties);
      QString new_json = QJsonDocument(AMP).toJson();
      QFile file(qpath);
      //存在打开，不存在创建
      if(!file.open(QIODevice::ReadWrite | QIODevice::Text))
      {
          return;
      }
      //写入内容,这里需要转码，否则报错。
      QByteArray str = new_json.toUtf8();
      //清空文档
      file.flush();
      //写入QByteArray格式字符串
      file.write(str);
      //关闭文件
      file.close();

    }

}

//输入监测点
void Monitor::Read_from_Json(std::string path){

    //从json中读数据更新当前的AllMonitors
    QString qpath = QString::fromStdString(path);
    QFile file(qpath);
    if(!file.open(QIODevice::ReadOnly)){
        return;
    }
    QByteArray data = file.readAll();
    file.close();
    QJsonParseError json_error;
    QJsonDocument jsonDoc(QJsonDocument::fromJson(data,&json_error));

    if(json_error.error != QJsonParseError::NoError)
    {
        return;
    }
    QJsonObject properties = jsonDoc.object();
    //把数据从json的数组中读取出来
    QJsonArray pro = properties.value("Monitors").toArray();

    std::list<PointM> Cur_Mons;
    for(int i=0;i<pro.count();i++){
        QJsonObject obj = pro.at(i).toObject();
        PointM pm;
        pm.X = obj.value("x").toDouble();
        pm.Y = obj.value("y").toDouble();
        pm.Z = obj.value("z").toDouble();
        pm.Vec = obj.value("vec").toDouble();
        pm.Flu = obj.value("flu").toDouble();
        pm.Dep = obj.value("dep").toDouble();
        pm.Times = obj.value("time").toDouble();
        Cur_Mons.push_front(pm);
    }
    *AllMonitor = Cur_Mons;
}


//可视化
osg::ref_ptr<osg::Node> Monitor::return_M_Info(){

    osg::ref_ptr<osg::Group> allpoints = new osg::Group;

    //首先尝试画点:
    if(!AllMonitor->empty()){
        std::list<PointM>::iterator it;
        for(it = AllMonitor->begin();it!=AllMonitor->end();it++){
            osg::ref_ptr<osg::Geode> geode = new osg::Geode;
            //先画球把监测点表示出来
            float _radius = 10.0f;
            osg::ref_ptr<osg::TessellationHints> hints = new osg::TessellationHints;
            hints->setDetailRatio(1.0f);
//            osg::Material *material = new osg::Material;
//            material->setDiffuse(osg::Material::BACK, osg::Vec4(1.0, 0.0, 0.0, 1.0));
//            material->setAmbient(osg::Material::BACK, osg::Vec4(1.0, 0.0, 0.0, 1.0));
//            material->setShininess(osg::Material::BACK, 30.0);
//            geode->getOrCreateStateSet()->setAttribute(material);
//            geode->addDrawable(new osg::ShapeDrawable(new osg::Sphere(osg::Vec3(it->X, it->Y, it->Z+5), _radius)));
            osg::ref_ptr<osg::Sphere> sphere = new osg::Sphere(osg::Vec3(it->X, it->Y, it->Z+5), _radius);
            osg::ref_ptr<osg::ShapeDrawable> shapeDrawable = new osg::ShapeDrawable(sphere.get());
            shapeDrawable->setColor(osg::Vec4(0.0, 0.0, 1.0, 1.0));
            geode->addDrawable(shapeDrawable.get());

            osg::Depth* dep = new osg::Depth;
            dep->setFunction(osg::Depth::Function::ALWAYS);
            geode->getOrCreateStateSet()->setAttribute(dep, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
            geode->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
            geode->getOrCreateStateSet()->setRenderBinDetails(10.0, "RenderBin");


            //写文字把信息展示出来
            osg::ref_ptr<osg::Geode> geodeT = new osg::Geode;
            osgText::Text *text1=new osgText::Text;
            //设置字体
            text1->setFont("fonts/simhei.ttf");
            //设置文字显示的位置
            text1->setPosition(osg::Vec3((it->X),(it->Y),(it->Z)+5));
            text1->setColor(osg::Vec4(1,1,1,1));

            //保留3位小数点
            float iVec = it->Vec;
            QString sVec = QString::number(iVec,'f',3);
            float iFlu = it->Flu;
            QString sFlu = QString::number(iFlu,'f',3);
            float iDep = it->Dep;
            QString sDep = QString::number(iDep,'f',3);
            float iTime = it->Times;
            QString sTime = QString::number(iTime,'f',0);

            std::string info1 = "流速 "+sVec.toStdString()+" m/s\n";
            std::string info2= "流量 "+ sFlu.toStdString()+" m^3/s\n";
            std::string info3="深度 "+ sDep.toStdString()+" m";
            std::string info4 = "到达时间 "+sTime.toStdString()+"s\n";
            std::string info = info4+info1+info2+info3;
            const char* infoc = info.c_str();
            QTextCodec* code = QTextCodec::codecForName("UTF-8");
            QString qstr = QObject::tr(infoc);
            std::string str = code->fromUnicode(qstr).data();
            text1->setText(str, osgText::String::ENCODING_UTF8);
            text1->setCharacterSize(30);  //设置字体大小
            text1->setAxisAlignment(osgText::Text::SCREEN);
            text1->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
//            text1->setAutoRotateToScreen(true);
            text1->setBackdropType(osgText::Text::OUTLINE);//对文字进行描边
            text1->setBackdropColor(osg::Vec4(0.3,0.0,1.0,1.0));//描边颜色
            text1->setDrawMode(osgText::Text::TEXT | osgText::Text::BOUNDINGBOX);//添加文字边框
//            text1->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
            text1->setBoundingBoxColor(osg::Vec4(1,1,1,1));
            text1->setBoundingBoxMargin(3.0f);
            text1->setAlignment(osgText::Text::LEFT_TOP);
            text1->setColorGradientMode(osgText::Text::SOLID);


            if(iVec!=0.0f&&iFlu!=0.0f&&iDep!=0.0f){
            geodeT->addDrawable(text1);
            osg::StateSet* states = geodeT->getOrCreateStateSet();
            osg::Depth* depth = dynamic_cast<osg::Depth*> (states->getAttribute(osg::StateAttribute::DEPTH));
            if( depth == NULL )
            {
                    depth = new osg::Depth;
                    states->setAttributeAndModes(depth, osg::StateAttribute::ON );
            }
            depth->setFunction(osg::Depth::ALWAYS);
            depth->setRange(1.0,1.0);
//            osg::Depth* dep = new osg::Depth;     //case中有定义，必须加{}，不然直接会跳到default
//                   dep->setFunction(osg::Depth::Function::ALWAYS);
//                   geodeT->getOrCreateStateSet()->setAttribute(dep, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
//                   geodeT->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
//                   // 设置渲染系数，哪个模型要显示在前面，就调大该模型的渲染系数
//                  geodeT->getOrCreateStateSet()->setRenderBinDetails(100.0, "RenderBin");


            allpoints->addChild(geodeT);
            }

            allpoints->addChild(geode);


        }
    }

    return allpoints.get();

}


//判断洪水是否到达了监测点
bool Monitor::is_Match(float x, float y, float d,float vec,float flu,float dep,float times){

    std::list<PointM>::iterator it;
    int Mn=0;
    if(!AllMonitor->empty()){
    for(it = AllMonitor->begin(); it!=AllMonitor->end();it++){
        float dnx = fabs(it->X - x);
        float dny = fabs(it->Y - y);
        if(dnx<d && dny<d){
            PointM pm;
            pm.X = it->X;
            pm.Y = it->Y;
            pm.Z = it->Z;

            pm.Vec = vec;
            pm.Flu = flu;
            pm.Dep = dep;
            pm.Times = it->Times;
            if(pm.Times==0.0)
            {
                pm.Times=times;
            }
            *it = pm;
            Mn++;
        }
    }

    }
    if(Mn!=0){
        return true;
    }
    else{
        return false;
    }

}
