﻿#ifndef LANDSLIDEFORM_H
#define LANDSLIDEFORM_H
#pragma execution_character_set("utf-8")


#include <QWidget>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <time.h>

#include <QDebug>
#include <QPushButton>
#include <QFileDialog>
#include <QString>
#include <QLineEdit>
#include <QMessageBox>

#include <osgUtil/DelaunayTriangulator>
#include <osgUtil/TriStripVisitor>
#include <osg/Drawable>
#include <osg/ShapeDrawable>
#include <osg/Texture2D>
#include <osg/TexEnv>
#include <osg/TexGen>

#include<osg/LineWidth>
#include<osg/Point>

#include "adapterwidget.h"
#include "viewerqt.h"

#include "gdal_priv.h"
#include "gdal_version.h"
#include "ogrsf_frmts.h"

#include "gdal.h"

#include "windows.h"

using namespace std;


namespace Ui {
class LandslideForm;
}

class LandslideForm : public QWidget
{
    Q_OBJECT

public:
    explicit LandslideForm(QWidget *parent = 0);
    ~LandslideForm();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_11_clicked();

private:
    Ui::LandslideForm *ui;

    QLineEdit *lineEdit;
    QLineEdit *lineEdit2;
    QLineEdit *lineEdit3;
    QLineEdit *lineEdit4;
    QLineEdit *lineEdit5;
    QLineEdit *lineEdit6;
    QLineEdit *lineEdit7;
    QLineEdit *lineEdit8;

public:
    vector<string> split(string *str, string *pattern);  //字符串分割函数
    osg::ref_ptr<osg::Geode> addLabel(); //添加滑坡标注信息
    osg::ref_ptr<osg::Geode> addInformation();  //添加符号化信息

    //改变shp的大小和颜色（针对点和线）
    osg::Image* createImage( int width, int height,osg::Vec3 color );
    void ChangeSHP(osg::ref_ptr<osg::Node> node,osg::Vec4 color,float size,bool IsPoint );

    void writeRaster(char* savePath, GDALDataset* dataSet, float* bufferData);  //写出滑坡时刻文件（彭琪代码）

    //粒子系统中添加纹理方法
    bool GetPixValByGeoPos(GDALDataset *pDataset, const double GeoX, const double GeoY,
                           std::vector<float>& pixelValues, int xSize = 1, int ySize = 1); //在附近地方找表面纹理
    bool Projection2ImageRowCol(double *adfGeoTransform, double dProjX, double dProjY, int &iCol, int &iRow);//由地理坐标得到图像行列号


public:
//    float **landDem;
//    float landDem[930][1530];
//    float landDem1[930][1530];
//    float landDem2[930][1530];
//    float landDem3[930][1530];
//    float landDem4[930][1530];
//    float landDem5[930][1530];
//    float landDem6[930][1530];
//    float landDem7[930][1530];
//    float landDem8[930][1530];
//    float landDem9[930][1530];
//    float landDem10[930][1530];

    vector<string> urlStr; //用于存储选择场景和计算文件路径


signals:
    void sendLandSlide(bool flag);
    void sendStart(int flag); //开始演进
    void sendURL(vector<string> UrlStr);  //用于传送选择的计算需要的文件路径
    void sendScenePath(string sceneUrl);  //用于传送选择的场景


};

#endif // LANDSLIDEFORM_H
