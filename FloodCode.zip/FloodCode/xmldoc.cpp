﻿#include "xmldoc.h"

XMLDoc::XMLDoc()
{
}

vector<string> XMLDoc::readXml(string str)
{
//    fileName="C:/Users/gyk81/Desktop/landslidetest1114/maoxianXML.xml";
    std::string path = return_ViewTree_Path(NOW_NODENAME).toStdString();
    path+="/LandslideXML.xml";//"C:/Users/gyk81/Desktop/landslidetest1114/jinshajiangXML.xml";
    fileName = QString::fromStdString(path);

    vector<string> strVector;

    QDomDocument doc;
    QFile file(fileName);
    QString error = "";
    int row = 0, column = 0;
//    if (!file.open(QIODevice::ReadOnly)) return NULL;

    if(!doc.setContent(&file, false, &error, &row, &column)){
        cout << "parse file failed:" << row << "---" << column <<":" <<error.toStdString()<<endl;
        file.close();
//        return NULL;
    }
    file.close();
    QDomElement root = doc.documentElement();
    QDomNode node = root.firstChild();

    while(!node.isNull()){
        QDomElement element = node.toElement(); // try to convert the node to an element.
        if(!element.isNull()){
//            cout<<element.tagName().toStdString() << ":" << element.text().toStdString()<<endl;
            QDomNode nodeson = element.firstChild();
            while(!nodeson.isNull()){
                QDomElement elementson = nodeson.toElement();
                if(!elementson.isNull()){
                    //容器存储数据
                    if(element.tagName().toStdString()==str  && str=="Path"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="Camera1"){
                        if(elementson.tagName().toStdString()=="eye"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="center"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="up"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="Camera3"){
                        if(elementson.tagName().toStdString()=="eye"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="center"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="up"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="DiZhiXian"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="lishizaihai"){
                        if(elementson.tagName().toStdString()=="text"){
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="dizhijiegou"){
                        if(elementson.tagName().toStdString()=="location"){
                            strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="text"){
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="SingleArrow"){
                        if(elementson.tagName().toStdString()=="path"){
                            strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="posd"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="attitude"){
                            strVector.push_back(elementson.attributeNode("X_axis").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y_axis").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z_axis").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="text"){
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="boundary"){
                        if(elementson.tagName().toStdString()=="location"){
                            strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="text"){
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                        else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="landslide"){
                        if(elementson.tagName().toStdString()=="path"){
                            strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="location"){
                            strVector.push_back(elementson.attributeNode("LocationFile").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="BarrierLake"){
                        if(elementson.tagName().toStdString()=="path"){
                            strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="text"){
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="Camera2"){
                        if(elementson.tagName().toStdString()=="eye"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="center"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="up"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="attitude"){
                            strVector.push_back(elementson.attributeNode("X_axis").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y_axis").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z_axis").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="text"){
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="DoubleArrowPicture"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="DoubleArrow1"){
                        if(elementson.tagName().toStdString()=="location"){
                            strVector.push_back(elementson.attributeNode("Arrow1Location").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="attitude"){
                            strVector.push_back(elementson.attributeNode("X_axis").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y_axis").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z_axis").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="text"){
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="DoubleArrow2"){
                        if(elementson.tagName().toStdString()=="location"){
                            strVector.push_back(elementson.attributeNode("Arrow2Location").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="pos1"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="pos2"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="text"){
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="DoubleArrow3"){
                        if(elementson.tagName().toStdString()=="location"){
                            strVector.push_back(elementson.attributeNode("Arrow3Location").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="Len"){
                            strVector.push_back(elementson.attributeNode("Length").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="text"){
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="DoubleArrow4"){
                        if(elementson.tagName().toStdString()=="location"){
                            strVector.push_back(elementson.attributeNode("Arrow4Location").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="attitude"){
                            strVector.push_back(elementson.attributeNode("X_axis").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y_axis").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z_axis").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="text"){
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="BarrierRiver"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="MaskRiver"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="NormalRiver"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="MaskRoad"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="NormalRoad"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="MaskBuilding"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="NormalBuilding"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str && str=="DamageInfo"){
                        if(elementson.tagName().toStdString()=="text")
                        {
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }
                    }
                    if(element.tagName().toStdString()==str && str=="OtherFeature"){
                        if(elementson.tagName().toStdString()=="path"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                        }
                    }
                    if(element.tagName().toStdString()==str && str=="rainDescribe")
                    {
                        if(elementson.tagName().toStdString()=="text")
                        {
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }
                    }

                    if(element.tagName().toStdString()==str && str=="BendArrow")
                    {
                        if(elementson.tagName().toStdString()=="path")
                        {
                            strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                        }
                        else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }
                        else if(elementson.tagName().toStdString()=="type"){
                            strVector.push_back(elementson.attributeNode("T").value().toStdString());
                        }
                    }

                    if(element.tagName().toStdString()==str && str=="LandslideDescribe")
                    {
                        if(elementson.tagName().toStdString()=="text")
                        {
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                        else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }
                    }
                    if(element.tagName().toStdString()==str && str=="Landslidearea")
                    {
                        if(elementson.tagName().toStdString()=="path")
                        {
                            strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                        }
                    }
                    if(element.tagName().toStdString()==str && str=="Risk")
                    {
                        if(elementson.tagName().toStdString()=="path")
                        {
                            strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                        }
                        else if(elementson.tagName().toStdString()=="text")
                        {
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                    }
                    if(element.tagName().toStdString()==str && str=="Threat")
                    {
                        if(elementson.tagName().toStdString()=="path")
                        {
                            strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                        }
                        else if(elementson.tagName().toStdString()=="text")
                        {
                            strVector.push_back(elementson.attributeNode("textstr").value().toLocal8Bit().constData());
                        }
                        else if(elementson.tagName().toStdString()=="pos"){
                            strVector.push_back(elementson.attributeNode("X").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("Z").value().toStdString());
                        }
                    }

                }
                nodeson = nodeson.nextSibling();
            }
        }
        node = node.nextSibling();
    }


    //因为有的vector没加判断，直接运行，所以会导致空值(下面是为了删除空值)
//    for(int i=0;i<strVector.size();i++){
//        if(strVector[i].empty()){
//            strVector.erase(strVector.begin()+i);
//        }
//    }

    return strVector;
}



vector<string> XMLDoc::readXmlFnD(string str){

    std::string path = return_ViewTree_Path(NOW_NODENAME).toStdString();
    path+="/configXML.xml";
    fileName = QString::fromStdString(path);
    vector<string> strVector;

    QDomDocument doc;
    QFile file(fileName);
    QString error = "";
    int row = 0, column = 0;
    if(!doc.setContent(&file, false, &error, &row, &column)){
        cout << "parse file failed:" << row << "---" << column <<":" <<error.toStdString()<<endl;
        file.close();
    }

    file.close();
    QDomElement root = doc.documentElement();
    QDomNode node = root.firstChild();

    while(!node.isNull()){
        QDomElement element = node.toElement();
        if(!element.isNull()){
            QDomNode nodeson = element.firstChild();
            while(!nodeson.isNull()){
                QDomElement elementson = nodeson.toElement();
                if(!elementson.isNull()){
                    if(element.tagName().toStdString()==str  && str=="Path"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="Camera"){
                        if(elementson.tagName().toStdString()=="eye"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="center"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }else if(elementson.tagName().toStdString()=="up"){
                            strVector.push_back(elementson.attributeNode("x").value().toStdString());
                            strVector.push_back(elementson.attributeNode("y").value().toStdString());
                            strVector.push_back(elementson.attributeNode("z").value().toStdString());
                        }
                    }
                    if(element.tagName().toStdString()==str  && str=="House"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="Road"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="River"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="Play"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="BarrierLake"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str  && str=="PlayH"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                    }
                    if(element.tagName().toStdString()==str && str=="Othershp"){
                        if(elementson.tagName().toStdString()=="path"){
                        strVector.push_back(elementson.attributeNode("strPath").value().toStdString());
                        }
                    }
                }
                nodeson = nodeson.nextSibling();
            }
        }
    node = node.nextSibling();
    }
return strVector;
}
