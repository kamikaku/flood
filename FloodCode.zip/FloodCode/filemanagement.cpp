﻿#include "filemanagement.h"

FileManage::FileManage(QString n, QString p,QString t){
    name = n;
    path = p;
    dtype = t;
}

