﻿#include "viewerqt.h"

//ViewerQT::ViewerQT()
//{
//}


ViewerQT::ViewerQT(QWidget *parent):AdapterWidget(parent)
{
    getCamera()->setViewport(new osg::Viewport(0,0,width(),height()));
    getCamera()->setProjectionMatrixAsPerspective(30.0f, static_cast<double>(width())/static_cast<double>(height()), 1.0f, 10000.0f);
    getCamera()->setGraphicsContext(getGraphicsWindow());
    getCamera()->setClearColor(osg::Vec4f(1.0f,1.0f,1.0f,1.0f));  //white
    addEventHandler(new osgViewer::WindowSizeHandler);   //window's size event
    addEventHandler(new osgViewer::StatsHandler);  //帧率S(s)键等控制
    addEventHandler(new osgViewer::HelpHandler);
    addEventHandler(new osgViewer::ScreenCaptureHandler);

    setThreadingModel(osgViewer::Viewer::SingleThreaded);
    connect(&_timer,SIGNAL(timeout()),this,SLOT(updateGL()));//并且把它的timeout()连接到适当的槽。当这段时间过去了，它将会发射timeout()信号

    _timer.start(10);//使用start()来开始
}
