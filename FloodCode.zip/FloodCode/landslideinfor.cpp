﻿#include "landslideinfor.h"
#include "renderclass.h"

LandslideInfor::LandslideInfor()
{

}

//创建字体样式库
void LandslideInfor::createText(osgText::Text &textObject, float size, const osg::Vec3 &pos, const osg::Vec4 &color)
{
    textObject.setFont("fonts/msyh.ttc");//设置字体格式
    textObject.setCharacterSize(size);//字体大小
//    textObject.setColor( osg::Vec4( 0, 0, 0, 1));  //字体颜色
    textObject.setColor(color);  //字体颜色
    textObject.setPosition(pos);
    textObject.setAlignment(osgText::Text::LEFT_CENTER);//文字显示方向
    textObject.setAutoRotateToScreen(true);//跟随视角不断变化，但离物体越远，文字越小，和现实当中像类似
}

//添加描述信息，灾害发生时间、地点、事件
osg::ref_ptr<osg::Node> LandslideInfor::eventDescription()
{
//    std::string path = return_ViewTree_Path(NOW_NODENAME).toStdString();
//    Point3D pos;
//    pos=gdal_read_polylineshp("E:/ChuanJuDisasterModel/testdata/huadao_WithZ/huadao_Line.shp");
//    path+="/huadao_WithZ/huadao_Line.shp";
//    pos=gdal_read_polylineshp(path.c_str());//("E:/LandslideData/huadao_WithZ/huadao_Line.shp");

//    osg::ref_ptr<osg::Geode> geo=new osg::Geode;

//    osg::ref_ptr<osgText::Font> font_1 = osgText::readFontFile("fonts/msyh.ttc");
//    osg::ref_ptr<osgText::Text> text_1 = new osgText::Text;
//    text_1->setFont(font_1);
//    text_1->setText(L"时间：2018.10.11\n\n地点：江达县波罗乡\n\n坐标：98°41′57″E，31°4′56″N\n\n事件：山体滑坡");

    XMLDoc *pXmlDoc=new XMLDoc();
    vector<string> pVectorboundery;
    pVectorboundery=pXmlDoc->readXml("boundary");
//    pos=gdal_read_polylineshp(pVectorboundery[0].c_str());
    if(pVectorboundery.size()==0)
    {
        return NULL;
    }
    osg::Vec3 posv(atof(const_cast<const char *>(pVectorboundery[2].c_str())), atof(const_cast<const char *>(pVectorboundery[3].c_str())), atof(const_cast<const char *>(pVectorboundery[4].c_str())));
    osg::ref_ptr<osg::Geode> geo=new osg::Geode;
    osg::ref_ptr<osgText::Font> font_1 = osgText::readFontFile("fonts/msyh.ttc");
    osg::ref_ptr<osgText::Text> text_1 = new osgText::Text;
    text_1->setFont(font_1);
    std::wstring str=string_To_wstring(pVectorboundery[1]);
    text_1->setText(str.c_str());

    text_1->setCharacterSize(80);
    text_1->setAutoRotateToScreen(true);
    text_1->setBackdropType(osgText::Text::OUTLINE);//文件描边
    text_1->setBackdropColor(osg::Vec4(0.3,0.6,0.7,1));//文字描边的颜色
//    text_1->setPosition(osg::Vec3(pos.X, pos.Y, pos.Z));
    text_1->setPosition(posv);

    text_1->setColor(osg::Vec4(1.0, 1.0, 1.0, 1.0));//字体颜色
    text_1->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);  //设置场景光线,关闭光源
//    text_1->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//    text_1->setBoundingBoxColor(osg::Vec4(0.7,0.5,0,1));
//    text_1->setBoundingBoxColor(osg::Vec4(0.3,0.6,0.7,1));
    geo->addDrawable(text_1.get());
    geo->setName("landslideEvent");

    return geo;
}


//灾害成因描述
osg::ref_ptr<osg::Geode> LandslideInfor::causeDescription()
{
//    osg::ref_ptr<osg::Geode> geode = new osg::Geode;  //节点
//    //**文字
//    osg::ref_ptr<osgText::Text>text=new osgText::Text;
//    //设置字体
//    text->setText(L"地\n质\n结\n构\n松\n动");//设置显示的文字
//    text->setText(L"地质结构松动");//设置显示的文字
//    createText(*text,180,osg::Vec3(472069.68f,3438806.168f,3500.0f),osg::Vec4( 0.86f, 0.86f, 0.86f, 1));

    XMLDoc *pXmlDoc=new XMLDoc();
    vector<string> pVectordizhijiegou;
    pVectordizhijiegou=pXmlDoc->readXml("dizhijiegou");
    if(pVectordizhijiegou.size()==0)
    {
        return NULL;
    }
    osg::ref_ptr<osg::Geode> geode = new osg::Geode;  //节点
    //**文字
    osg::ref_ptr<osgText::Text>text=new osgText::Text;
    //设置字体
    if(pVectordizhijiegou[3]!=""){
    std::wstring str=string_To_wstring(pVectordizhijiegou[3]);
    text->setText(str.c_str());
    createText(*text,100,osg::Vec3(atof(const_cast<const char *>(pVectordizhijiegou[0].c_str())), atof(const_cast<const char *>(pVectordizhijiegou[1].c_str())), atof(const_cast<const char *>(pVectordizhijiegou[2].c_str()))),osg::Vec4( 1.0f, 1.0f, 0.0f, 1));
    osg::ref_ptr<osgText::Font> font = osgText::readFontFile("fonts/msyh.ttc");
    text->setFont(font);

    text->setBackdropType(osgText::Text::OUTLINE);//对文字进行描边
    text->setBackdropColor(osg::Vec4(1.0, 0.0, 0.0, 0.7));//描边颜色
//    text->setLayout(osgText::Text::VERTICAL);   //设置格式为VERTICAL，垂直
    geode->addDrawable(text.get());
    }
    delete pXmlDoc;

    return geode;

}

//历史灾害描述
osg::ref_ptr<osg::Node> LandslideInfor::historyDescription(int num)
{

    osg::ref_ptr<osg::Geode> geo=new osg::Geode;
    osg::ref_ptr<osg::Group> pReasonRoot=new osg::Group;
    XMLDoc *pXmlDoc=new XMLDoc();
    vector<string> pVectorlishizaihai;
    pVectorlishizaihai=pXmlDoc->readXml("lishizaihai");
    int pNum=pVectorlishizaihai.size()/4;
    for(int i=0;i<pNum;i++){
        osg::ref_ptr<osgText::Font> font = osgText::readFontFile("fonts/msyh.ttc");
        osg::ref_ptr<osgText::Text> text = new osgText::Text;
        text->setFont(font);
        std::wstring str=string_To_wstring(pVectorlishizaihai[i*4+0]);
        text->setText(str.c_str());
        text->setCharacterSize(80);
        text->setAutoRotateToScreen(true);
//        text->setBackdropType(osgText::Text::OUTLINE);//文件描边
//        text->setBackdropColor(osg::Vec4(1.0, 1.0, 1.0, 1.0));//文字描边的颜色
//        text->setDrawMode(osgText::Text::TEXT|osgText::Text::FILLEDBOUNDINGBOX);
        text->setBackdropType(osgText::Text::OUTLINE);//文件描边
//        text->setBoundingBoxColor(osg::Vec4(0.3,0.6,0.7,1));
        text->setBackdropColor(osg::Vec4(0.3,0.6,0.7,1));
        text->setPosition(osg::Vec3(atof(const_cast<const char *>(pVectorlishizaihai[i*4+1].c_str())), atof(const_cast<const char *>(pVectorlishizaihai[i*4+2].c_str())), atof(const_cast<const char *>(pVectorlishizaihai[i*4+3].c_str()))));    //将string转化为double
        text->setColor(osg::Vec4(1,1,1,1));//字体颜色
        text->getOrCreateStateSet()->setMode(GL_LIGHTING,osg::StateAttribute::OFF|osg::StateAttribute::OVERRIDE);  //设置场景光线,关闭光源
        RenderClass *rc=new RenderClass;
        rc->closeZbuffer(*text);
        geo->addDrawable(text.get());
        pReasonRoot->addChild(geo);
        delete rc;

        if(num==i+1){
            return pReasonRoot;
        }
    }

    return pReasonRoot;
}

//使整个场景下雨
osg::ref_ptr<osg::Node> LandslideInfor::rainEffect()
{
    //调用粒子系统，使整个场景下雨
//    osg::ref_ptr<osgParticle::PrecipitationEffect>pe=new osgParticle::PrecipitationEffect();
//    pe->rain(1.0f);
//    pe->setParticleSize(0.08);


    //指定场景位置下雨
    osg::Matrixd matrixEffect;
    matrixEffect.makeTranslate(osg::Vec3(471777.019f, 3438823.531f, 3500.00f));
    // 设置粒子位置
    osg::ref_ptr<osg::MatrixTransform> trans = new osg::MatrixTransform;
    // 对粒子范围进行了放大
    trans->setMatrix(matrixEffect );
    // 创建雨粒子
    osg::ref_ptr<osgParticle::PrecipitationEffect> pe = new osgParticle::PrecipitationEffect;
    pe->rain(2.0f);
//    pe->setUseFarLineSegments(true);
    // iLevel参数是一个int值，表示雨的级别，一般1-10就够用了
//    pe->setParticleSize(0.015);
    pe->setParticleSize(0.032);
    // 设置颜色
    pe->setParticleColor(osg::Vec4(1, 1, 1, 1));

    return pe;
}

//创建箭头的滑动动画
osg::ref_ptr<osg::AnimationPath> LandslideInfor::createAnimationPath(const osg::Vec3& ptStart,const osg::Vec3 &ptEnd,float timeBegin, float timeEnd){

    //创建一个Path对象
        osg::ref_ptr<osg::AnimationPath> animationPath = new osg::AnimationPath() ;
        //设置动画模式为循环(LOOP)(LOOP:循环，SWING:单摆,NO_LOOPING:不循环)
        animationPath->setLoopMode(osg::AnimationPath::NO_LOOPING) ;


        //插入Path，把关键点与时间压入形成Path
        animationPath->insert(timeBegin,osg::AnimationPath::ControlPoint(ptStart));
        animationPath->insert(timeEnd,osg::AnimationPath::ControlPoint(ptEnd));

        //返回Path
        return animationPath.get() ;

}

//创建一个箭头
osg::ref_ptr<osg::Node> LandslideInfor::CreateArrow(){

//    QString EPath =  QCoreApplication::applicationDirPath();
//    std::string path = EPath.toStdString()+"/Data/images/arrow.png";
//    std::string path = return_ViewTree_Path(NOW_NODENAME).toStdString();
//    path += "/images/arrow.png";

    XMLDoc *pXmlDoc=new XMLDoc();
    std::string path="";
    vector<string> pVectorSingleArrow=pXmlDoc->readXml("SingleArrow");
    if(pVectorSingleArrow.size()!=0){
    path=pVectorSingleArrow[0];
    }

//    osg::ref_ptr<osg::Image> image =osgDB::readImageFile("E:\\Data\\CodeTest\\images\\arrow.png");
     osg::ref_ptr<osg::Image> image =osgDB::readImageFile(path);


       //创建四边形
       osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry();
       osg::ref_ptr<osg::Geode> geode = new osg::Geode();
        if(image.get()==NULL)
        {
            return geode.get();
        }
       //设置顶点
       osg::ref_ptr<osg::Vec3Array> v = new osg::Vec3Array();
       v->push_back(osg::Vec3(0.0f,-0.5f,-0.5f));
       v->push_back(osg::Vec3(0.0f,0.5f,-0.5f));
       v->push_back(osg::Vec3(0.0f,0.5f,0.5f));
       v->push_back(osg::Vec3(0.0f,-0.5f,0.5f));

       geometry->setVertexArray(v.get());

       //设置法线
       osg::ref_ptr<osg::Vec3Array> normal = new osg::Vec3Array();
       normal->push_back(osg::Vec3(1.0f,0.0f,0.0f)^osg::Vec3(0.0f,0.0f,1.0f));
//       normal->push_back(osg::Vec3(0.0f,1.0f,0.0f)^osg::Vec3(0.0f,0.0f,1.0f));

       geometry->setNormalArray(normal.get());
       geometry->setNormalBinding(osg::Geometry::BIND_OVERALL);

       //设置纹理坐标
       osg::ref_ptr<osg::Vec2Array> vt = new osg::Vec2Array();
       vt->push_back(osg::Vec2(0.0f,0.0f));
       vt->push_back(osg::Vec2(1.0f,0.0f));
       vt->push_back(osg::Vec2(1.0f,1.0f));
       vt->push_back(osg::Vec2(0.0f,1.0f));


       geometry->setTexCoordArray(0,vt.get());
       geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS,0,4));

       if(image.get()){
           //属性对象
           osg::ref_ptr<osg::StateSet> stateset = new osg::StateSet();

           //创建一个Texture2D属性对象
           osg::ref_ptr<osg::Texture2D> texture = new osg::Texture2D();

           //关联image
           texture->setImage(image.get());


           //关联Texture2D纹理对象，第三个参数默认为ON
           stateset->setTextureAttributeAndModes(0,texture,osg::StateAttribute::ON);

           //启用混合
           stateset->setMode(GL_BLEND,osg::StateAttribute::ON);
           //关闭光照
           stateset->setMode(GL_LIGHTING,osg::StateAttribute::OFF);


           geometry->setStateSet(stateset.get());
       }


       geode->addDrawable(geometry.get());

       osg::ref_ptr<osg::PositionAttitudeTransform> trans =new osg::PositionAttitudeTransform();
//       trans->setPosition(osg::Vec3(471777.019f, 3438823.531f, 3500.00f));
       trans->setPosition(osg::Vec3(atof(const_cast<const char *>(pVectorSingleArrow[1].c_str())),atof(const_cast<const char *>(pVectorSingleArrow[2].c_str())),atof(const_cast<const char *>(pVectorSingleArrow[3].c_str()))));
       trans->setScale(osg::Vec3(350.0f,150.0f,350.0f));
//       trans->setScale(osg::Vec3(500.0f,500.0f,500.0f));
//       osg::Quat quat(-(osg::PI/3), osg::Vec3(0.0, 1.0, 0.0));
       osg::Quat quat(osg::DegreesToRadians(atof(const_cast<const char *>(pVectorSingleArrow[7].c_str()))), osg::Vec3d(1.0, 0.0, 0.0),
               osg::DegreesToRadians(atof(const_cast<const char *>(pVectorSingleArrow[8].c_str()))), osg::Vec3d(0.0, 1.0, 0.0),
               osg::DegreesToRadians(atof(const_cast<const char *>(pVectorSingleArrow[9].c_str()))), osg::Vec3d(0.0, 0.0, 1.0));
       trans->setAttitude(quat);
       //trans->addChild(billboard.get());
       trans->addChild(geode.get());

       return trans.get();
}

//滑坡箭头展示
osg::ref_ptr<osg::Node> LandslideInfor::arrowDisplay(int num)
{
    RenderClass *rc = new RenderClass;
    osg::ref_ptr<osg::Node> arrow = CreateArrow();
    rc->closeZbuffer(*arrow);
    DrawGeometry *dg=new DrawGeometry();
    osg::ref_ptr<osg::Node> text = dg->Reason();
    rc->closeZbuffer(*text);
    osg::ref_ptr<osg::PositionAttitudeTransform> pat = new osg::PositionAttitudeTransform();
    delete rc;
    osg::Vec3 pos(0.0f, 0.0f, 0.0f);
//    osg::Vec3 posd(400.0f,0.0f,-300.0f);
    XMLDoc *pXmlDoc=new XMLDoc();
    vector<string> pVectorSingleArrow=pXmlDoc->readXml("SingleArrow");
    if(pVectorSingleArrow.size()==0)
    {
        return NULL;
    }
    osg::Vec3 posd(atof(const_cast<const char *>(pVectorSingleArrow[4].c_str())),atof(const_cast<const char *>(pVectorSingleArrow[5].c_str())),atof(const_cast<const char *>(pVectorSingleArrow[6].c_str())));
    osg::ref_ptr<osg::AnimationPath> ap = createAnimationPath(pos,posd,0.0f,0.8f);

    pat->setUpdateCallback(new osg::AnimationPathCallback(ap.get()));
    pat->addChild(arrow);
    delete pXmlDoc;
    if(num==1){
        return pat.get();
    }

    if(num==2){
        return text.get();
    }
}

//滑坡信息展示：滑坡高度、宽度、土方量等
osg::ref_ptr<osg::Group> LandslideInfor::infoDisplay(int num)
{
//    osg::ref_ptr<osg::Group>root1=new osg::Group;
    DrawGeometry *dg=new DrawGeometry();

    return dg->Return_G(num)->asGroup();
//    return root1;
}

//受损情况描述,包括建筑物、河流、道路等
osg::ref_ptr<osg::Group> LandslideInfor::damageDescription(int index)
{
   osg::ref_ptr<osg::Group> newroot=new osg::Group;
   DamageDescription *damdes=new DamageDescription();
   newroot=damdes->newroot(index);
//   newroot->addChild(damdes->CreateDamHUD());
   delete damdes;
   return newroot;
}

//读取线的范围坐标
Point3D LandslideInfor::gdal_read_polylineshp(const char *path)
{
    Point3D pEnvlopePoint;
    GDALAllRegister();
    GDALDataset   *poDS;
    CPLSetConfigOption("SHAPE_ENCODING", "");  //解决中文乱码问题
    //读取shp文件
    poDS = (GDALDataset*)GDALOpenEx(path, GDAL_OF_VECTOR, NULL, NULL, NULL);

    if (poDS == NULL)
    {
        cout << "Open failed.\n%s" << endl;
    }

    int nLayerCnt = poDS->GetLayerCount();
    int nLayerIdx = 0;

    for (; nLayerIdx < nLayerCnt; ++nLayerIdx)
    {
        OGRLayer* curLayer = poDS->GetLayer(nLayerIdx);
        OGRFeature * ftr = curLayer->GetNextFeature();
        while (ftr)
        {
            OGRGeometry * poGeom = ftr->GetGeometryRef();
            switch (wkbFlatten(poGeom->getGeometryType()))
            {
            case wkbLineString:
            {
                OGRLineString* poLS = static_cast<OGRLineString*>(poGeom);
                OGREnvelope3D* poEnvelop3D = new OGREnvelope3D;    //获取该要素的三维范围
                poLS->getEnvelope(poEnvelop3D);
                pEnvlopePoint.X=(poEnvelop3D->MaxX+poEnvelop3D->MinX)/2;
                pEnvlopePoint.Y=(poEnvelop3D->MaxY+poEnvelop3D->MinY)/2;
                pEnvlopePoint.Z=poEnvelop3D->MaxZ;
            }
            break;
            default:
                break;
            }

            ftr = curLayer->GetNextFeature();
        }

        delete curLayer;
    }
    return pEnvlopePoint;
    GDALClose(poDS);  //不注释掉会报错

}


//创建HUD显示受损情况
osg::ref_ptr<osg::Camera> LandslideInfor::CreateInfoHUD(){

    XMLDoc *pXmlDoc=new XMLDoc();
    vector<string> pVectorDamInfo;
    pVectorDamInfo=pXmlDoc->readXml("DamageInfo");
    int num = pVectorDamInfo.size();
    if(num<1){
        return NULL;
    }

    //图例面板背景颜色
      osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
      osg::ref_ptr<osg::Vec4Array>colorArray=new osg::Vec4Array;
      geometry=osg::createTexturedQuadGeometry(osg::Vec3(620.0f,480.0f,0.0f),
                                               osg::Vec3(180.0f,0.0f,0.0f),osg::Vec3(0.0f,40.0*num,0.0f));

      colorArray->push_back(osg::Vec4(0.8,0.8,0.8,0.7f));
      geometry->setColorArray(colorArray.get());
      geometry->setColorBinding(osg::Geometry::BIND_OVERALL);

      //添加背景
      osg::Geode*geode=new osg::Geode();
      geode->addChild(geometry);

      //读取文字
      for(int i=0;i<num;i++){
          osgText::Text *text2=new osgText::Text;
          //设置字体
          text2->setFont("fonts/simhei.ttf");
          //设置文字显示的位置
          text2->setPosition(osg::Vec3(650.0f,580.0-i*25,0.0f));
          text2->setColor(osg::Vec4( 0, 0, 0, 1));
          std::wstring str=string_To_wstring(pVectorDamInfo[i]);
          text2->setText(str.c_str());
          text2->setCharacterSize(12);  //设置字体大小
          geode->addChild(text2); //添加文字

      }

      //设置状态
      osg::StateSet* stateset = geode->getOrCreateStateSet();
      stateset->setMode(GL_LIGHTING,osg::StateAttribute::OFF);//关闭灯光
      stateset->setMode(GL_DEPTH_TEST,osg::StateAttribute::OFF);//关闭深度测试
      //打开GL_BLEND混合模式（以保证Alpha纹理正确）
      stateset->setMode(GL_BLEND,osg::StateAttribute::ON);

      //相机
      osg::Camera* camera = new osg::Camera;
      //设置透视矩阵
      camera->setProjectionMatrix(osg::Matrix::ortho2D(0,800,0,600));//正交投影
      //设置绝对参考坐标系，确保视图矩阵不会被上级节点的变换矩阵影响
      camera->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
      //视图矩阵为默认的
      camera->setViewMatrix(osg::Matrix::identity());
      //设置背景为透明，否则的话可以设置ClearColor
      camera->setClearMask(GL_DEPTH_BUFFER_BIT);
      camera->setAllowEventFocus( false);//不响应事件，始终得不到焦点
      //设置渲染顺序，必须在最后渲染
      camera->setRenderOrder(osg::Camera::POST_RENDER);
      camera->addChild(geode);//将要显示的Geode节点加入到相机
      return camera;
}


osg::ref_ptr<osg::Camera> LandslideInfor::CreateInfoHUD(int number){

    XMLDoc *pXmlDoc=new XMLDoc();
    vector<string> pVectorDamInfo;
    pVectorDamInfo=pXmlDoc->readXml("DamageInfo");
    int num = pVectorDamInfo.size();
    if(num<1){
        return NULL;
    }

    //图例面板背景颜色
//      osg::ref_ptr<osg::Geometry>geometry=new osg::Geometry;
//      osg::ref_ptr<osg::Vec4Array>colorArray=new osg::Vec4Array;
//      geometry=osg::createTexturedQuadGeometry(osg::Vec3(300.0f,180.0f,0.0f),
//                                               osg::Vec3(180.0f,0.0f,0.0f),osg::Vec3(0.0f,20.0,0.0f));

//      colorArray->push_back(osg::Vec4(1,1,1,1));
//      geometry->setColorArray(colorArray.get());
//      geometry->setColorBinding(osg::Geometry::BIND_OVERALL);

//      //添加背景
      osg::Geode*geode=new osg::Geode();
    //      geode->addChild(geometry);

      osg::Vec3 posd(atof(const_cast<const char *>(pVectorDamInfo[num-3].c_str())),atof(const_cast<const char *>(pVectorDamInfo[num-2].c_str())),atof(const_cast<const char *>(pVectorDamInfo[num-1].c_str())));

      //读取文字
      for(int i=0;i<num;i++){

          if(i==number){
          osgText::Text *text2=new osgText::Text;
          //设置字体
          text2->setFont("fonts/simhei.ttf");
          //设置文字显示的位置
//          text2->setPosition(osg::Vec3(300,160+number*40,0.0f));
          text2->setPosition(osg::Vec3(posd.x(),posd.y(),posd.z()+number*100));
          text2->setColor(osg::Vec4(0,0.3,0.6,1));
//          text2->setColor(osg::Vec4(1,0.1,0.1,1));
          std::wstring str=string_To_wstring(pVectorDamInfo[i]);
          text2->setText(str.c_str());
          text2->setCharacterSize(13);  //设置字体大小
          text2->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
          text2->setBoundingBoxColor(osg::Vec4(1,1,1,1));
          geode->addChild(text2); //添加文字
          }

      }

      //设置状态
      osg::StateSet* stateset = geode->getOrCreateStateSet();
      stateset->setMode(GL_LIGHTING,osg::StateAttribute::OFF);//关闭灯光
      stateset->setMode(GL_DEPTH_TEST,osg::StateAttribute::OFF);//关闭深度测试
      //打开GL_BLEND混合模式（以保证Alpha纹理正确）
      stateset->setMode(GL_BLEND,osg::StateAttribute::ON);

      //相机
      osg::Camera* camera = new osg::Camera;
      //设置透视矩阵
      camera->setProjectionMatrix(osg::Matrix::ortho2D(0,800,0,600));//正交投影
      //设置绝对参考坐标系，确保视图矩阵不会被上级节点的变换矩阵影响
      camera->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
      //视图矩阵为默认的
      camera->setViewMatrix(osg::Matrix::identity());
      //设置背景为透明，否则的话可以设置ClearColor
      camera->setClearMask(GL_DEPTH_BUFFER_BIT);
      camera->setAllowEventFocus( false);//不响应事件，始终得不到焦点
      //设置渲染顺序，必须在最后渲染
      camera->setRenderOrder(osg::Camera::POST_RENDER);
      camera->addChild(geode);//将要显示的Geode节点加入到相机
      return camera;
}


osg::ref_ptr<osg::Node> LandslideInfor::CreateInfoPos(int number){

    XMLDoc *pXmlDoc=new XMLDoc();
    vector<string> pVectorDamInfo;
    pVectorDamInfo=pXmlDoc->readXml("DamageInfo");
    int num = pVectorDamInfo.size();
    if(num<1){
        return NULL;
    }


      osg::Geode*geode=new osg::Geode();

      osg::Vec3 posd(atof(const_cast<const char *>(pVectorDamInfo[num-3].c_str())),atof(const_cast<const char *>(pVectorDamInfo[num-2].c_str())),atof(const_cast<const char *>(pVectorDamInfo[num-1].c_str())));

      //读取文字
      for(int i=0;i<num;i++){

          if(i==number){
          osgText::Text *text2=new osgText::Text;
          //设置字体
          text2->setFont("fonts/simhei.ttf");
          //设置文字显示的位置
//          text2->setPosition(osg::Vec3(300,160+number*40,0.0f));
          text2->setPosition(osg::Vec3(posd.x(),posd.y(),posd.z()+number*150));
          text2->setColor(osg::Vec4(0,0.3,0.6,1));
//          text2->setColor(osg::Vec4(1,0.1,0.1,1));
          std::wstring str=string_To_wstring(pVectorDamInfo[i]);
          text2->setText(str.c_str());
          text2->setCharacterSize(35);  //设置字体大小
          text2->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
          text2->setBoundingBoxColor(osg::Vec4(1,1,1,1));
          text2->setAutoRotateToScreen(true);
          text2->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
          RenderClass *rc = new RenderClass();
          rc->closeZbuffer(*text2);
          geode->addChild(text2); //添加文字
          }

      }
      osg::ref_ptr<osg::Group> group = new osg::Group;
        group->addChild(geode);

      return group.get();
}


osg::ref_ptr<osg::Node> LandslideInfor::CreateInfoPos_withline(int number,osg::Vec3 posline){

//    XMLDoc *pXmlDoc=new XMLDoc();
//    vector<string> pVectorDamInfo;
//    pVectorDamInfo=pXmlDoc->readXml("DamageInfo");
//    int num = pVectorDamInfo.size();
//    if(num<1){
//        return NULL;
//    }


      osg::Geode*geode=new osg::Geode();

//      osg::Vec3 posd(atof(const_cast<const char *>(pVectorDamInfo[num-3].c_str())),atof(const_cast<const char *>(pVectorDamInfo[num-2].c_str())),atof(const_cast<const char *>(pVectorDamInfo[num-1].c_str())));
      osg::Vec3 posd(posline.x(),posline.y(),posline.z()+200);
      osg::Vec3 post;
      //读取文字
//      for(int i=0;i<num;i++){


          osgText::Text *text2=new osgText::Text;
          //设置字体
          text2->setFont("fonts/simhei.ttf");
          //设置文字显示的位置
//          text2->setPosition(osg::Vec3(300,160+number*40,0.0f));
//          text2->setPosition(osg::Vec3(posd.x(),posd.y(),posd.z()+number*150));
          text2->setPosition(posd);
          text2->setColor(osg::Vec4(0,0.3,0.6,1));
//          text2->setColor(osg::Vec4(1,0.1,0.1,1));
          std::wstring str=L"约757户房屋受灾";//string_To_wstring("约757户房屋受灾");//About 757 houses were damaged

          text2->setText(str.c_str());
          text2->setCharacterSize(45);  //设置字体大小
//          text2->setDrawMode(osgText::Text::TEXT | osgText::Text::FILLEDBOUNDINGBOX);
//          text2->setBoundingBoxColor(osg::Vec4(1,1,1,1));
          text2->setBackdropType(osgText::Text::OUTLINE);//文件描边
          text2->setBackdropColor(osg::Vec4(1,1,1,1));//文字描边

          text2->setAutoRotateToScreen(true);
          text2->setCharacterSizeMode(osgText::Text::SCREEN_COORDS);
          text2->setAlignment(osgText::Text::CENTER_CENTER);
          RenderClass *rc = new RenderClass();
          rc->closeZbuffer(*text2);
          geode->addChild(text2); //添加文字


//      }
      osg::ref_ptr<osg::Group> group = new osg::Group;
        group->addChild(geode);

        osg::ref_ptr<osg::Geode> geodeline = new osg::Geode;
        osg::ref_ptr<osg::Vec3Array> vecarry1 = new osg::Vec3Array();
        osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry();
        {
        vecarry1->push_back(posline);
        vecarry1->push_back(posd);
        geometry->setVertexArray(vecarry1.get());
        geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, 2));
        }
//        osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth(4.0);
//        geometry->getOrCreateStateSet()->setAttribute(lw,osg::StateAttribute::ON);
//        osg::Material *material = new osg::Material;
//        material->setDiffuse(osg::Material::FRONT,osg::Vec4(0,0,1,1));
//        material->setAmbient(osg::Material::FRONT, osg::Vec4(0,0,1,1));
//        material->setShininess(osg::Material::FRONT, 90.0);
//        geodeline->getOrCreateStateSet()->setAttribute(material);
//        geodeline->addDrawable(geometry.get());
//        rc = new RenderClass();
//        rc->setNodeRender(*geodeline,10);
//        group->addChild(geodeline);
//        delete rc;

      return group.get();
}


//中文string转wstring
wstring LandslideInfor::string_To_wstring(string pStr)
{
    //不能识别转义字符(但是将xml中的换行符修改为&#x000A;即可识别换行符)
    unsigned len = pStr.size() * 2;// 预留字节数
    setlocale(LC_CTYPE, "");     //必须调用此函数
    wchar_t *p = new wchar_t[len];// 申请一段内存存放转换后的字符串
    mbstowcs(p,pStr.c_str(),len);// 转换
    std::wstring str1(p);
    delete[] p;// 释放申请的内存
    return str1;
}
