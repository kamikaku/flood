﻿#ifndef SHAPEMARK_H
#define SHAPEMARK_H

#include <osgDB/ReadFile>
#include <osgViewer/Viewer>
#include <osgText/Text>
#include <osgGA/TrackballManipulator>
#include <osg/ShapeDrawable>
#include <osg/Camera>
#include <osg/Material>
#include <QTextCodec>
#include <osg/Group>
#include <QString>
#include <QObject>
#include <osgText/Text>

#include "gdal.h"
#include "gdal_priv.h"
#include "ogrsf_frmts.h"
#include "gdal_version.h"
#include <list>
#include <iomanip>
#include "globalvar.h"


#include <QtXml/QDomDocument>
#include <QFile>
#include <QTextStream>
#include <QTextCodec>
#include <QDebug>

#include <iostream>


class TextMark{
public:
    float x;
    float y;
    float z;
    std::string text;
    osg::Vec4 color;
    float size;
public:
    TextMark(float X,float Y,float Z,std::string t,osg::Vec4 c,float S);
    TextMark(void);

};


class ShapeMark
{
public:
    std::vector<TextMark> allMarks = NULL;
public:
    void read_text(std::string path);
    osg::ref_ptr<osg::Node> retrun_text();

};

#endif // SHAPEMARK_H
