﻿#ifndef RENDERCLASS_H
#define RENDERCLASS_H
#include <osg/Depth>
#include <osg/Node>

class RenderClass
{
public:
    RenderClass();
    void setNodeRender(osg::Node &node,float sequence);
    void closeZbuffer(osg::Node &node);
};

#endif // RENDERCLASS_H
