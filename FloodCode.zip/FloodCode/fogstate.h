﻿#ifndef FOGSTATE_H
#define FOGSTATE_H

#include <osg/StateSet>
#include <osg/Fog>
#include <osg/StateAttribute>


//设置回调
class FogCallBack :	public osg::StateSet::Callback {
public:
    FogCallBack();
    ~FogCallBack();

    virtual void operator() (osg::StateSet* ss, osg::NodeVisitor*nv)override;
};


//创建烟雾效果类
class FogState
{
public:
    FogState();
    osg::ref_ptr<osg::Fog> createFog();  //创建烟雾
};

#endif // FOGSTATE_H
