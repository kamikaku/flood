﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#pragma execution_character_set("utf-8")


#include <QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QFileDialog>
#include <iostream>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QAction>
#include <QApplication>
#include <QTimer>
#include <QFile>
#include <QFileInfo>
#include <QFileDialog>
#include <QException>
#include <QProgressDialog>
#include <QtCore/QTextCodec>
#include <QDebug>
#include <QProcess>
#include <QTreeView>
#include <QTime>
#include <QVector>
#include <QTextCodec>
#include <QLabel>
#include <QWidget>
#include <QPainter>


#include <thread>
#include <cstdint>
#include <limits>
#include <typeinfo.h>
#include <QStackedWidget>
#include <QGraphicsView>
#include <QDesktopWidget>
#include <QScreen>
#include <QDebug>
#include <QStandardItemModel>
#include <cmath>

#include <osg/Group>
#include <osg/Geode>
#include <osgViewer/Viewer>
#include <osgDB/ReadFile>
#include <osg/ShapeDrawable>
#include <osgDB/ReadFile>
#include <osgDB/WriteFile>
#include <osg/Node>
#include <osg/Geometry>
#include <osg/MatrixTransform>
#include <osgGA/StateSetManipulator>
#include <osgViewer/ViewerEventHandlers>
#include <osgGA/StateSetManipulator>
#include <osgGA/GUIEventHandler>
#include <osgGA/TrackballManipulator>
#include <osgViewer/ViewerEventHandlers>
#include <osg/Shader>
#include <osg/Program>
#include <osgViewer/CompositeViewer>
#include <osg/Uniform>
#include <osg/Notify>
#include <osg/MatrixTransform>
#include <osg/ShapeDrawable>
#include <osg/PositionAttitudeTransform>
#include <osg/Geometry>
#include <osgGA/TrackballManipulator>
#include <osgParticle/ParticleSystem>
#include <osgParticle/Particle>
#include <osgParticle/ModularEmitter>
#include <osgParticle/MultiSegmentPlacer>
#include <osgParticle/ModularProgram>
#include <osgParticle/AccelOperator>
#include <osgParticle/FluidFrictionOperator>
#include <osgParticle/ParticleSystemUpdater>
#include <osgParticle/PrecipitationEffect>
#include <osgParticle/SectorPlacer>
#include <osg/Sequence>
#include <QThread>

#include "Windows.h"

#include "adapterwidget.h"
#include "viewerqt.h"
#include "CAFloodNEW.h"
#include "floodform.h"
#include "cadebrisflow.h"
#include "debrisflow.h"
#include "landslideform.h"
#include "landslideinfor.h"
#include "createscalarbar.h"
#include "blinkingdisplay.h"
#include "fogstate.h"
#include "smoke.h"
#include "filemanagement.h"
#include "choosefiledialog.h"
#include "globalvar.h"
#include "floodfeature.h"
#include "barrierlake.h"
#include "debrisflowfeature.h"
#include "monitor.h"
#include "shapemark.h"
#include "readshpdialog.h"
#include "pickhandle.h"
#include "searchnode.h"
#include "renderclass.h"
#include "floodinfo.h"


#include "gdal.h"
#include "gdal_priv.h"
#include "gdal_version.h"
#include "ogrsf_frmts.h"

#include "xmldoc.h"
#include "getcamerapose.h"

//#define SIMULATION_TIME 100   //**********定义常量，表示滑坡的次数
#define SIMULATION_TIME 101   //**********定义常量，表示滑坡的次数
using namespace std;

extern std::list<FileManage> BindingFiles; //绑定文件的信息集
extern QString NOW_NODENAME;
extern std::vector<float> coord;

static int numViewers=0;  //定义一个变量，用于实时统计视图个数
static vector<osg::Vec3d>eyePoints,centerPoints, upPoints;
//声明类UseEventHandler，由于它是从osgGA::GUIEventHandler派生而来，所以它拥有处理事件的能力，其中这种能力体现在一个虚函数handle上。
//一切的处理都在handle当中。
class UseEventHandler :public::osgGA::GUIEventHandler
{
    osg::Vec3d eye, center, up;
    float viewerDistance = 2.93713e+030;   //这个distance的默认值时根据什么设定的？？？
public:
    //handle函数，其中有两个极其重要的参数，
    //一个是const osgGA::GUIEventAdapter，注意有不少人在写时少写了个const结果就不灵了，
    //因为是虚函数，参数必须与父类中虚函数相应一致。该参数是用来识别各种事件类型的参数。
    //第二个参数也很重要：osgGA::GUIActionAdapter，它是控制显示的参数，其实最重要的是它是Viewer的祖父类，由它可以得到viewer,在操作中有体现。
    virtual bool handle(const osgGA::GUIEventAdapter &ea, osgGA::GUIActionAdapter &aa)
    {
        //将aa强制转换为viewer对象
        osgViewer::Viewer *viewer = dynamic_cast<osgViewer::Viewer*>(&aa);
        if (!viewer)//如果转换失败则直接退出
        {
            return false;
        }
        switch (ea.getEventType())//获取事件的类型，是键盘上的事件，还是鼠标上的事件以及鼠标单击，右击，双击等等。
        {
            case osgGA::GUIEventAdapter::RELEASE:  //鼠标释放
                if (ea.getButton() == osgGA::GUIEventAdapter::LEFT_MOUSE_BUTTON) //表示释放鼠标左键
                {
                    viewer->getCamera()->getViewMatrixAsLookAt(eye, center, up, viewerDistance);
                }
                else if (ea.getButton() == osgGA::GUIEventAdapter::RIGHT_MOUSE_BUTTON)//  表示释放鼠标右键
                {
                    viewer->getCamera()->getViewMatrixAsLookAt(eye, center, up, viewerDistance);
                }
                else if (ea.getButton() == osgGA::GUIEventAdapter::MIDDLE_MOUSE_BUTTON)
                {
                    viewer->getCamera()->getViewMatrixAsLookAt(eye, center, up, viewerDistance);
                }

                eyePoints.erase(eyePoints.begin()+numViewers,eyePoints.end());
                centerPoints.erase(centerPoints.begin()+numViewers,centerPoints.end());
                upPoints.erase(upPoints.begin()+numViewers,upPoints.end());
                eyePoints.push_back(eye);
                centerPoints.push_back(center);
                upPoints.push_back(up);

                numViewers=eyePoints.size();
                cout<<"event:  "<<eyePoints.size()<<",  "<<numViewers<<endl;
                break;

        case osgGA::GUIEventAdapter::KEYDOWN:
          {
              if(ea.getKey()==0xFF51){
                  viewer->getSceneData()->asGroup()->getChild(0)->setNodeMask(0);
                  qDebug()<<"left";

              }
              if(ea.getKey()==0xFF53){
                  viewer->getSceneData()->asGroup()->getChild(0)->setNodeMask(1);
                  qDebug()<<"right";
              }
          }
              break;

            default:
                break;
        }
        return false;
    }
};

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:

    Ui::MainWindow *ui;
    FloodForm *ff;
    DebrisFlow *df;
    LandslideForm *ll;
    LandslideInfor *lf;


signals:
    void Sendagrv(vector<double> pVectorCameraParameters);

public:  //定义成员变量
    osg::ref_ptr<osg::Group> shpNodes;
    int cur_disNum; //当前滑坡演进时刻
    int landslide_pro; //滑坡信息描述前还是描述后

    QTimer *twinktimer;//闪动的计时器
    int twinkindex;//闪动的节点索引
    int twinkNum=1; //闪动次数

    Monitor *mr;  //定义监测站类
    FloodFeature* floodf; //洪水要显示的参数类
    BarrierLake* brLake=NULL; //堰塞湖类
    Debrisflowfeature* debf;

    //水淹分析中的变量
    QTimer *_timer;

    QTimer *timerM;//漫堤
    osg::Vec3 pos_SY;
    osg::Vec3 pos_CY;
    osg::Vec3 width_SY;
    osg::Vec3 height_SY;
    int nodeIndex=0;
    double Alutte=0.0;

    QString myAppPath;//获取exe文件所在文件夹的路径

    QStandardItemModel *model;//定义目录树的model
    ViewerQT *viewer;
    osg::ref_ptr<osg::Group> root;
    osg::ref_ptr<osg::Group> rootflood;
    osg::ref_ptr<osg::Group> rootflood1;
    osg::ref_ptr<osg::Geode> geode;    
    osg::ref_ptr<osg::Group> Scene; // 创建一个场景的group 管理地形与矢量图层
    osg::ref_ptr<osg::Node> terrain;  //用于金沙江整个大场景节点（滑坡+洪水）
    osg::ref_ptr<osg::Node>loadNode; // 用于打开文件时的节点加载
    osg::ref_ptr<osg::Node> terrainflood;  //洪水场景节点
    osg::ref_ptr<osg::Node> terrainf_debrisflow;  //泥石流场景节点
    osg::ref_ptr<osg::Node> landslide;  //滑坡场景节点
    osg::ref_ptr<osg::Node>landslide1;
    osg::ref_ptr<osg::Node>landslide2;
//    QTimer *timer=new QTimer;  //设置时间定时器
    QTimer *timer;  //设置时间定时器
    string saveOutPath;  //用于存放计算结果保存的路径
    string startOutPath;  //开始演进时的文件夹路径，读取存放的二进制文件路径
    string startOutPath2;
    string landslideOutPath;   //滑坡过程文件路径
    QString fileName;  //设置成全局变量，用于打开文件

    osg::ref_ptr<osg::Geode>landGeode;  //滑坡最后时刻节点对象
    osg::ref_ptr<osg::Node>landNode;  //滑坡最后时刻节点对象
    osg::ref_ptr<osg::Geode>labelGeode; //标注节点对象
    osg::ref_ptr<osg::Geode>infoGeode; //符号化信息
    int displayIndex=0;  //用来控制循环滑坡动画脚本事件
    int displayIndex2=0;  //用来控制循环滑坡动画脚本事件
    int displayIndex3=0;  //用来控制循环滑坡动画脚本事件

    QLabel *label;
    QHBoxLayout *hLayout;
    QString curFile; //当前文件路径
    QStackedWidget *stackedWidget;
    QGraphicsView *graphicsView;

    QTreeView *treeView;//目录树


    int fileNum;  //表示用于演示的灾害时空文件个数，主要用于演示结束后终止循环读文件
    int fileNum2;
    int types=0;  //代表灾害种类 1：洪水； 2：泥石流； 3：滑坡；
    string scenePath; //接收场景路径
    string filePath; //接收计算文件路径
    vector<string> calUrl;  //用来接收需要计算使用的文件路径
    int speedInt=1;  //用来表示灾害演进倍数

    bool selectChain=false;  //用来设置是否形成灾害链，默认为不形成灾害链

    //洪水
    CAFlood* m_pFlood;
    DAMINFORMATION dam;
    DEMINFORMATION deminfo;
    CACELL** m_p2DCellArray;
    vector<vector<string>>vdem;// 存放分割后的字符串,DEM文件
    int shallowColor=0;
    int deepColor = 20;
    int displayflood;
    floodInfo *fl;
//    osg::ref_ptr<osg::Group> rootflood;


    //泥石流
    CADebrisFlow *m_pDebrisFlow;  //泥石流计算类
    double C = 0.0;   // 谢才系数
    double BingHamLi = 0.0; //宾汉结构力
    double VisCosity_Coefficiant = 0.0;  //泥石流粘性系数
    double InitialNumber_EachCell = 0.0;   //初始泥流团的个数
    double Total_Time1 = 0.0;                   //总的时间
    double Total_VolumeCon = 0.0;   //总的固体体积浓度
    long DebrisFlow_TotalNum = 0;        //流团总个数
    int  InitialNumber_TotalCell = 0;       //溃口中流团个数
    double VelocityInitial_X = 0.0;  //初始X方向的速度
    double VelocityInitial_Y = 0.0;  //初始Y方向的速度
    double AngelToRadian = 0.0; //将角度转为弧度

    double DebrisFlow_TotalAmount;     //泥石流一次冲出总量
    double InitialMudDepth;    //最大淤积厚度
    double Angle;             //溃口起始角度
    double DebrisFlowDensity;    //泥石流的密度
    double SolidDensity;  //泥石流固体体积浓度
    double FluidVolume_Con;       //泥石流液体体积浓度
    double FlowVolume;   //泥流团的体积
    double WaterDensity;    //水的密度
    double Limit_Con;               //泥石流极限浓度
    double InitialVelocity;     //泥石流初始速度
    double DeltaTime;       //计算时间间 5m对应隔0.2
    double DebrisFlow_Roughness; //0.09;  //泥石流粗糙度系数

    int **initialArray = NULL;
    int initialCellNum = 0;
    DebrisGrid **debGrid = NULL;

    double xx1 = 0.0;
    double yy1 = 0.0;
    double xx2 = 0.0;
    double yy2 = 0.0;
    int sss = 0;
    DebrisFlowCell *DebrisCell;
    GridInfo gridInfo;
    vector<vector<double>>dfdem; // 存放分割后的字符串,DEM文件

    //滑坡
    struct Point
    {
        int line;
        int pixel;
        double h; //高程用于排序
    };

    string land_format=".ive";
    GDALDataset *befor, *body, *deposit, *base, *afterdem;
    GDALDataset* pHuaPotiDEM ; //用于读影像集

    int rasterXSize,rasterYSize;
    int bodyXSize,bodyYSize;
    int lineXSize,lineYSize;
    int depositXSize,depositYSize;
    float *preBufferData;
    float *baseBufferData;
    int  afterrasterXSize, afterrasterYSize;
    float afterDEMNoData;
    float *afterDEMBufferData;

    float *lastBufferData;

    float *bodyBufferData;
    float *lineBufferData;
    float *depositBufferData;
    float *rawData;
    vector<Point> pointVec;
    float volume = 0;
    float bodyArea = 0;  //定义全局变量
    int depositArea = 0;  //定义全局变量
    double startX,startY;
    double middleLineGeoTransform[6], baseGeoTransform[6],depositGeoTransform[6];
    int bodyLineOffset;
    int bodyPixelOffset;
    int depositLineOffset;
    int depositPixelOffset;
    double bodyGeoTransform[6];                     	//获取坐标信息

    osg::ref_ptr<osg::Group> rootlandslide;
    vector<string> pVectorboundery;


public:
    QJsonObject readJSON(QString json);
    void createActions();  //创建主窗体的菜单栏布局
    void loadFile(const QString &fileName);  //加载
    void saveFile(const QString &fileName);  //保存
    DWORD WINAPI Fun(LPVOID lpParamter);
    double gaussRand(double E, double V); //期望为E方差为V的高斯分布随机值,滑坡

    //string2UTF-8
    std::wstring string_To_wstring(string pStr);
    osg::ref_ptr<osg::AnimationPath> cameraAni();



public:
    bool flagRoam=true;  //用于表达灾害演进状态:开始/暂停/继续/停止
    int index_num; //用于读取二进制文件中索引的控制
//    void showPaint();

private:
   QLabel* m_statusLabel;


//public slots:
//   bool eventFilter(QObject *, QEvent *);

private slots:

   //接受从画shp的窗口传过来的group
//    void receiveGroup(osg::ref_ptr<osg::Group> gp);
    void receiveGroup(shapeFormat* sft);

    //打开shp文件
    void OpenShapeFile();
    //清楚数据
    void DeleteAllNode();

    //全溃半溃控制
    void FloodModelA();
    void FloodModelH();
    void BindFilePath(); //绑定文件夹路径事件
    void FloodingAnalysis();//水淹分析
    // 目录树双击事件
    void OnlineTreeViewDoubleClick(const QModelIndex & index);
    void ClickTree(const QModelIndex & index);
    //演进控制
    void startRoam();
    void pauseRoam();
    void continueRoma();
    void stopRoam();
    void restartRoam();
    void speedControl();  //用于快进控制

    void open();  //打开
    void addData();  //加载场景数据
    void preView();  //返回上一视图
        void nextView();  //跳至下一视图
    void save();  //保存
    void saveAs(); //另存为


    void getCameraParmeter();  //获取相机参数

    void displayInfo(); //展示信息

    //===接收传入的演进开始信息


    //===洪水可视化

    void Visualize(); //可视化
    void FloodVis();

    void showCoordinate();//更新坐标值

    void Twink(); //闪动


//    osg::ref_ptr<osgViewer::GraphicsWindowEmbedded> _gw;
protected:
    void closeEvent(QCloseEvent *event);
};

#endif // MAINWINDOW_H
