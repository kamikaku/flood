﻿#ifndef BARRIERLAKE_H
#define BARRIERLAKE_H

#include <iostream>
#include <osg/Node>
#include <osgDB/ReadFile>
#include <osg/Group>
#include <osg/Geometry>
#include <osg/BoundingBox>
#include <osg/NodeVisitor>
#include <osg/ComputeBoundsVisitor>

class BarrierLake
{
public:
    BarrierLake(float widh,float heigh,float Lh);

public:
    osg::Vec3 pos_S;
    float w; //确定整个面的宽
    float h; //确定整个面的长
    float Lake_H; //确定初始位置的高度
    osg::Vec3 dpos;//改变位置的向量
    osg::Vec3 pos_init; //记录最初的位置用于反复播放时的初始化

public:
    void get_Pos(std::string path);
    osg::ref_ptr<osg::Node> Draw_Lake();
    void change_Pos();
    void init_Pos();

};

#endif // BARRIERLAKE_H
